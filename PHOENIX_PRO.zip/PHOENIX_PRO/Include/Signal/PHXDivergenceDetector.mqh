#ifndef __PHX_DIVERGENCE_DETECTOR_MQH__
#define __PHX_DIVERGENCE_DETECTOR_MQH__

#include "PHXSignalTypes.mqh"
#include "PHXDivergenceClassifier.mqh"

//+------------------------------------------------------------------+
//| PHOENIX PRO                                                      |
//| Divergence Detector                                              |
//+------------------------------------------------------------------+
class CPHXDivergenceDetector
{
private:

   CPHXDivergenceClassifier m_classifier;

public:

   CPHXDivergenceDetector();

   bool Detect(
   const SPHXDivergenceMatch &first,
   const SPHXDivergenceMatch &second,
   const double avgRange,
   const double avgPPOChange,
   const double priceFlatThreshold,
   const double ppoFlatThreshold,
   SPHXDivergenceResult &result
) const;

private:

   ENUM_PHX_DIVERGENCE_DIRECTION GetDirection(
   const double delta,
   const double normalizedDelta,
   const double flatThreshold
) const;
};


//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXDivergenceDetector::CPHXDivergenceDetector()
{
}


//+------------------------------------------------------------------+
//| Get Direction                                                    |
//+------------------------------------------------------------------+
ENUM_PHX_DIVERGENCE_DIRECTION
CPHXDivergenceDetector::GetDirection(
   const double delta,
   const double normalizedDelta,
   const double flatThreshold
) const
{
   //--------------------------------------------------
   // Validate Threshold
   //--------------------------------------------------

   if(flatThreshold < 0.0)
      return PHX_DIVERGENCE_DIRECTION_FLAT;

   //--------------------------------------------------
   // Normalized Flat Zone
   //--------------------------------------------------

   if(
      normalizedDelta <=
      flatThreshold
   )
   {
      return PHX_DIVERGENCE_DIRECTION_FLAT;
   }

   //--------------------------------------------------
   // Direction By Raw Delta
   //--------------------------------------------------

   if(delta > 0.0)
      return PHX_DIVERGENCE_DIRECTION_UP;

   if(delta < 0.0)
      return PHX_DIVERGENCE_DIRECTION_DOWN;

   return PHX_DIVERGENCE_DIRECTION_FLAT;
}


//+------------------------------------------------------------------+
//| Detect Divergence                                                |
//+------------------------------------------------------------------+
   bool CPHXDivergenceDetector::Detect(
   const SPHXDivergenceMatch &first,
   const SPHXDivergenceMatch &second,
   const double avgRange,
   const double avgPPOChange,
   const double priceFlatThreshold,
   const double ppoFlatThreshold,
   SPHXDivergenceResult &result
) const
{
   //--------------------------------------------------
   // Reset Output
   //--------------------------------------------------

   result.Reset();

   //--------------------------------------------------
   // Validate Matches
   //--------------------------------------------------

   if(!first.Matched)
      return false;

   if(!second.Matched)
      return false;

   //--------------------------------------------------
   // Validate Price Extreme Types
   //--------------------------------------------------

   if(
      first.Price.Type != PHX_EXTREMUM_HIGH &&
      first.Price.Type != PHX_EXTREMUM_LOW
   )
   {
      return false;
   }

   if(
      second.Price.Type != PHX_EXTREMUM_HIGH &&
      second.Price.Type != PHX_EXTREMUM_LOW
   )
   {
      return false;
   }

   //--------------------------------------------------
   // Both Price Extremes Must Be Same Type
   //--------------------------------------------------

   if(
      first.Price.Type !=
      second.Price.Type
   )
   {
      return false;
   }

   //--------------------------------------------------
   // PPO Extremes Must Match Price Type
   //--------------------------------------------------

   if(
      first.PPO.Type != first.Price.Type ||
      second.PPO.Type != second.Price.Type
   )
   {
      return false;
   }

   //--------------------------------------------------
   // Validate Temporal Order
   //
   // First extreme must really precede second extreme.
   //--------------------------------------------------

   if(
      first.Price.ExtremeTime <= 0 ||
      second.Price.ExtremeTime <= 0
   )
   {
      return false;
   }

   if(
      first.Price.ExtremeTime >=
      second.Price.ExtremeTime
   )
   {
      return false;
   }

   //--------------------------------------------------
   // Prevent Reuse Of Same PPO Extreme
   //--------------------------------------------------

   if(
      first.PPO.ExtremeTime <= 0 ||
      second.PPO.ExtremeTime <= 0
   )
   {
      return false;
   }

   if(
      first.PPO.ExtremeTime ==
      second.PPO.ExtremeTime
   )
   {
      return false;
   }

   //--------------------------------------------------
   // Store Matches
   //--------------------------------------------------

   result.First =
      first;

   result.Second =
      second;

   //--------------------------------------------------
   // Calculate Raw Price Delta
   //
   // P2 - P1
   //--------------------------------------------------

   result.PriceDelta =
      second.Price.ExtremePrice -
      first.Price.ExtremePrice;

   //--------------------------------------------------
   // Calculate Raw PPO Delta
   //
   // O2 - O1
   //--------------------------------------------------

   result.PPODelta =
      second.PPO.Value -
      first.PPO.Value;

   //--------------------------------------------------
   // Normalize Price Delta
   //--------------------------------------------------

   result.PriceDeltaNorm =
   0.0;

   if(avgRange > 0.0)
{
   result.PriceDeltaNorm =
      MathAbs(
         result.PriceDelta
      ) /
      avgRange;
}

   //--------------------------------------------------
// Normalize PPO Delta
//--------------------------------------------------

result.PPODeltaNorm =
   0.0;

if(avgPPOChange > 0.0)
{
   result.PPODeltaNorm =
      MathAbs(
         result.PPODelta
      ) /
      avgPPOChange;
}

   //--------------------------------------------------
// Validate Flat Thresholds
//--------------------------------------------------

if(priceFlatThreshold < 0.0)
   return false;

if(ppoFlatThreshold < 0.0)
   return false;

//--------------------------------------------------
// Determine Normalized Directions
//--------------------------------------------------

result.PriceDirection =
   GetDirection(
      result.PriceDelta,
      result.PriceDeltaNorm,
      priceFlatThreshold
   );

result.PPODirection =
   GetDirection(
      result.PPODelta,
      result.PPODeltaNorm,
      ppoFlatThreshold
   );

   //--------------------------------------------------
   // Classify Divergence
   //--------------------------------------------------

   result.Type =
      m_classifier.Classify(
         first.Price.Type,
         result.PriceDirection,
         result.PPODirection
      );

   //--------------------------------------------------
   // Initial Lifecycle State
   //--------------------------------------------------

   if(
      result.Type == PHX_DIVERGENCE_NONE
   )
   {
      result.Status =
         PHX_DIVERGENCE_STATUS_NONE;
   }
   else
   {
      result.Status =
         PHX_DIVERGENCE_STATUS_DETECTED;
   }

   //--------------------------------------------------
   // Calculation Was Valid
   //--------------------------------------------------

   result.Valid =
      true;

   return true;
}

#endif