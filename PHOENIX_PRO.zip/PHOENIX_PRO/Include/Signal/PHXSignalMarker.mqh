#ifndef __PHX_SIGNAL_MARKER_MQH__
#define __PHX_SIGNAL_MARKER_MQH__


class CPHXSignalMarker
{

private:

   string m_prefix;


public:


   CPHXSignalMarker()
   {
      m_prefix = "PHX_SIGNAL_";
   }



   void DrawBuy(
      datetime time,
      double price
   )
   {

      string name =
         m_prefix +
         "BUY_" +
         IntegerToString(time);
         
      if(ObjectFind(0,name) >= 0)
   return;   

     double markerPrice =
      price - 20 * _Point;
      
      
      ObjectCreate(
         0,
         name,
         OBJ_ARROW,
         0,
         time,
         price
      );


      ObjectSetInteger(
         0,
         name,
         OBJPROP_ARROWCODE,
         233
      );


      ObjectSetInteger(
         0,
         name,
         OBJPROP_COLOR,
         clrLime
      );

   }

   void DrawSell(
      datetime time,
      double price
   )
   {

      string name =
         m_prefix +
         "SELL_" +
         IntegerToString(time);
         
         if(ObjectFind(0,name) >= 0)
   return;

   double markerPrice =
   price + 20 * _Point;

      ObjectCreate(
         0,
         name,
         OBJ_ARROW,
         0,
         time,
         price
      );


      ObjectSetInteger(
         0,
         name,
         OBJPROP_ARROWCODE,
         234
      );


      ObjectSetInteger(
         0,
         name,
         OBJPROP_COLOR,
         clrRed
      );

   }



   void Clear()
   {

      ObjectsDeleteAll(
         0,
         m_prefix
      );

   }

};


#endif