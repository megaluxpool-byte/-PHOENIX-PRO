#ifndef __PHX_TREND_SERVICES_MQH__
#define __PHX_TREND_SERVICES_MQH__

//--------------------------------------------------
// Includes
//--------------------------------------------------
#include "../Indicators/PHXEMA.mqh"
#include "PHXTrendTypes.mqh"
#include "PHXTrendScoreTypes.mqh"
#include "PHXTrendScore.mqh"
#include "IPHXTrendScoreProvider.mqh"
#include "../Diagnostics/PHXTrendScoreLogger.mqh"
//+------------------------------------------------------------------+
//| Trend Services                                                   |
//+------------------------------------------------------------------+
class CPHXTrendServices : public IPHXTrendScoreProvider
{
private:
   //--------------------------------------------------
   // EMA
   //--------------------------------------------------
   CPHXEMA m_fastEMA;
   CPHXEMA m_mediumEMA;
   CPHXEMA m_slowEMA;
   CPHXEMA m_trendEMA;
   //--------------------------------------------------
   // Trend Engine
   //--------------------------------------------------
   CPHXTrendScore m_scoreEngine;
   //--------------------------------------------------
   // Logger
   //--------------------------------------------------
   CPHXTrendScoreLogger m_logger;
   //--------------------------------------------------
   // Trend State
   //--------------------------------------------------
   SPHXTrendState m_state;
   //--------------------------------------------------
   // Trend Score
   //--------------------------------------------------
   SPHXTrendScore m_score;   
   //--------------------------------------------------
   // Trend Snapshot
   //--------------------------------------------------  
   SPHXTrendSnapshot m_snapshot;
   //--------------------------------------------------
   // Initialization
   //--------------------------------------------------

   bool m_initialized;

public:
   CPHXTrendServices();
   ~CPHXTrendServices();  
   bool Calculate(
   const SPHXTrendSnapshot &snapshot
);
   //--------------------------------------------------
   // Life Cycle
   //--------------------------------------------------
   bool Initialize();
   void Shutdown();
   bool Update();
   //--------------------------------------------------
   // State
   //--------------------------------------------------
   bool IsInitialized() const;
   //--------------------------------------------------
   // Getters
   //--------------------------------------------------
   CPHXTrendScore* GetScoreEngine();  
   SPHXTrendState GetState() const;
   SPHXTrendScore GetScore() const;
   ENUM_PHX_TREND GetTrend() const;
   ENUM_PHX_TREND_STRENGTH GetStrength() const;
   int GetTrendStrength() const;
   SPHXTrendSnapshot GetSnapshot() const;
};
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXTrendServices::CPHXTrendServices()
{
   m_state.Reset();
   m_score.Reset();
   m_initialized = false;
}
//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXTrendServices::~CPHXTrendServices()
{
   Shutdown();
}
//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXTrendServices::Initialize()
{
   Shutdown();
   //--------------------------------------------------
   // EMA20
   //--------------------------------------------------
   if(!m_fastEMA.Initialize(20))
      return false;
   //--------------------------------------------------
   // EMA50
   //--------------------------------------------------
   if(!m_mediumEMA.Initialize(50))
      return false;
   //--------------------------------------------------
   // EMA100
   //--------------------------------------------------
   if(!m_slowEMA.Initialize(100))
      return false;
   //--------------------------------------------------
   // EMA200
   //--------------------------------------------------
   if(!m_trendEMA.Initialize(200))
      return false;
   //--------------------------------------------------
   // State
   //--------------------------------------------------
   m_state.Reset();
   m_score.Reset();
   m_initialized = true;
   return true;
}
//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXTrendServices::Shutdown()
{
   m_fastEMA.Shutdown();
   m_mediumEMA.Shutdown();
   m_slowEMA.Shutdown();
   m_trendEMA.Shutdown();
   m_state.Reset();
   m_score.Reset();
   m_initialized = false;
}
//+------------------------------------------------------------------+
//| Calculate Trend Score                                            |
//+------------------------------------------------------------------+
   bool CPHXTrendServices::Calculate(
   const SPHXTrendSnapshot &snapshot
   )
{
   m_snapshot = snapshot;
if(!m_scoreEngine.Calculate(m_snapshot))
{
   return false;
}
m_score = m_scoreEngine.GetScore();
return true;
}
//+------------------------------------------------------------------+
//| Update                                                           |
//+------------------------------------------------------------------+
   bool CPHXTrendServices::Update()
{
   if(!m_initialized)
      return false;
   //--------------------------------------------------
   // Update EMA
   //--------------------------------------------------
   if(!m_fastEMA.Update())
      return false;
   if(!m_mediumEMA.Update())
      return false;
   if(!m_slowEMA.Update())
      return false;
   if(!m_trendEMA.Update())
      return false;
   //--------------------------------------------------
   // Calculate Trend Score
   //--------------------------------------------------
   if(!m_scoreEngine.Calculate(m_snapshot))
{
   return false;
}
   //--------------------------------------------------
   // Store Score
   //--------------------------------------------------
   m_score = m_scoreEngine.GetScore();
   //--------------------------------------------------
   // Fill Trend State
   //--------------------------------------------------
   m_state.emaScore   = m_score.EMA.Total;
   m_state.totalScore = m_score.Total;
   m_state.time       = TimeCurrent();
   m_state.valid      = true;
   //--------------------------------------------------
   // Log
   //--------------------------------------------------
   m_logger.Log(m_score);
   return true;
}
//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXTrendServices::IsInitialized() const
{
   return m_initialized;
}
//+------------------------------------------------------------------+
//| Get State                                                        |
//+------------------------------------------------------------------+
SPHXTrendState CPHXTrendServices::GetState() const
{
   return m_state;
}
//+------------------------------------------------------------------+
//| Get Score                                                        |
//+------------------------------------------------------------------+
SPHXTrendScore CPHXTrendServices::GetScore() const
{
   return m_score;
}
//+------------------------------------------------------------------+
//| Get Trend                                                        |
//+------------------------------------------------------------------+
ENUM_PHX_TREND CPHXTrendServices::GetTrend() const
{
   return m_state.trend;
}
//+------------------------------------------------------------------+
//| Get Strength                                                     |
//+------------------------------------------------------------------+
ENUM_PHX_TREND_STRENGTH CPHXTrendServices::GetStrength() const
{
   return m_state.strength;
}
//+------------------------------------------------------------------+
//| Get Trend Strength Score                                         |
//+------------------------------------------------------------------+
int CPHXTrendServices::GetTrendStrength() const
{
   return m_state.totalScore;
}
//+------------------------------------------------------------------+
//| Get Trend Score Engine                                           |
//+------------------------------------------------------------------+

CPHXTrendScore* CPHXTrendServices::GetScoreEngine()
{
   return &m_scoreEngine;
}
//+------------------------------------------------------------------+
//| Get Trend Snapshot                                               |
//+------------------------------------------------------------------+

SPHXTrendSnapshot CPHXTrendServices::GetSnapshot() const
{
   return m_snapshot;
}

#endif // __PHX_TREND_SERVICES_MQH__