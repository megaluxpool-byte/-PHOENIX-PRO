#ifndef __PHX_TREND_TYPES_MQH__
#define __PHX_TREND_TYPES_MQH__

//+------------------------------------------------------------------+
//| Trend Direction                                                  |
//+------------------------------------------------------------------+
enum ENUM_PHX_TREND
{
   PHX_TREND_UNKNOWN = 0,
   PHX_TREND_FLAT,
   PHX_TREND_UP,
   PHX_TREND_DOWN,
   PHX_TREND_STRONG_UP,
   PHX_TREND_STRONG_DOWN
};
//+------------------------------------------------------------------+
//| Trend Strength                                                   |
//+------------------------------------------------------------------+
enum ENUM_PHX_TREND_STRENGTH
{
   PHX_TREND_WEAK = 0,
   PHX_TREND_MEDIUM,
   PHX_TREND_STRONG
};
//+------------------------------------------------------------------+
//| Trend State                                                      |
//+------------------------------------------------------------------+
struct SPHXTrendState
{
   ENUM_PHX_TREND            trend;
   ENUM_PHX_TREND_STRENGTH   strength;

   int                       totalScore;   
   int                       emaScore;
   int                       atrScore;
   int                       rsiScore;
   int                       volumeScore;   
   int                       marketScore;
   bool                      emaFan;
   bool                      emaSlope;
   bool                      emaCompression;
   bool                      valid;
   datetime                  time;  

   void Reset()
{
   trend           = PHX_TREND_UNKNOWN;
   strength        = PHX_TREND_WEAK;
   totalScore      = 0;
   //--------------------------------------------------
   // Component Scores
   //--------------------------------------------------
   emaScore        = 0;
   atrScore        = 0;
   rsiScore        = 0;
   volumeScore     = 0;
   marketScore     = 0;
   //--------------------------------------------------
   // EMA Flags
   //--------------------------------------------------
   emaFan          = false;
   emaSlope        = false;
   emaCompression  = false;
   //--------------------------------------------------
   // State
   //--------------------------------------------------
   valid           = false;
   time            = 0;
  } 
};
//+------------------------------------------------------------------+
//| Trend Configuration                                              |
//+------------------------------------------------------------------+
struct SPHXTrendConfig
{
   int FastEMA;
   int MediumEMA;
   int SlowEMA;
   int TrendEMA;
   int StrongTrendScore;
   int MediumTrendScore;
   void Reset()
   {
      FastEMA          = 20;
      MediumEMA        = 50;
      SlowEMA          = 100;
      TrendEMA         = 200;

      StrongTrendScore = 8;
      MediumTrendScore = 5;
   }
};

#endif // __PHX_TREND_TYPES_MQH__