#ifndef PHX_SIGNAL_VALIDATION_PROVIDER_MQH
#define PHX_SIGNAL_VALIDATION_PROVIDER_MQH


#include "PHXSignalTypes.mqh"
#include "../Core/PHXStatisticsTypes.mqh"


class IPHXSignalValidationProvider
{

public:

   virtual ~IPHXSignalValidationProvider()
   {
   }


   virtual bool Calculate(
      SPHXSignal &signal
   ) = 0;


   virtual ENUM_PHX_SIGNAL_RESULT BuyResult() const = 0;


   virtual ENUM_PHX_SIGNAL_RESULT SellResult() const = 0;


};


#endif // PHX_SIGNAL_VALIDATION_PROVIDER_MQH