#ifndef __PHX_D1_TREND_CONTEXT_MQH__
#define __PHX_D1_TREND_CONTEXT_MQH__

//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXPriceStructure.mqh"

//+------------------------------------------------------------------+
//| D1 Trend Context                                                 |
//+------------------------------------------------------------------+
class CPHXD1TrendContext
{
private:

   //--------------------------------------------------
   // Independent D1 Price Structure
   //--------------------------------------------------

   CPHXPriceStructure
      m_structure;

   //--------------------------------------------------
   // Current D1 Context
   //--------------------------------------------------
   SPHXD1TrendContext
      m_context;
   //--------------------------------------------------
   // Readiness
   //--------------------------------------------------
   bool
      m_ready;
   //--------------------------------------------------
   // D1 Replay Parameters
   //--------------------------------------------------
   int
      m_historyBars;
   int
      m_avgRangePeriod;
   //--------------------------------------------------
   // Live D1 State
   //--------------------------------------------------
   datetime
      m_lastProcessedD1BarTime;     
   //--------------------------------------------------
   // Internal Helpers
   //--------------------------------------------------
   bool CalculateAvgRange(
      const MqlRates &rates[],
      const int currentIndex,
      double &avgRange
   ) const; 
   //--------------------------------------------------
   // D1 Structure Classification
   //--------------------------------------------------

   bool UpdateStructureClassification();
   //--------------------------------------------------
   // D1 Trend State Classification
   //--------------------------------------------------

   bool UpdateTrendState();   

public:

   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------
   CPHXD1TrendContext();
   //--------------------------------------------------
   // Reset
   //--------------------------------------------------
   void Reset();
   //--------------------------------------------------
   // Build Historical D1 Structure
   //--------------------------------------------------
   bool Build(
      const int historyBars,
      const int avgRangePeriod
   );
   //--------------------------------------------------
   // Live D1 Update
   //--------------------------------------------------
   bool Update();
   //--------------------------------------------------
   // Accessors
   //--------------------------------------------------

   bool IsReady() const;

   SPHXD1TrendContext GetContext() const;

   CPHXPriceStructure* GetStructure();
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXD1TrendContext::CPHXD1TrendContext()
{
   Reset();
}

//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXD1TrendContext::Reset()
{
   //--------------------------------------------------
   // D1 Structure
   //--------------------------------------------------

   m_structure.Reset();

   //--------------------------------------------------
   // D1 Context
   //--------------------------------------------------

   m_context.Reset();

   //--------------------------------------------------
   // Readiness
   //--------------------------------------------------

   m_ready =
      false;
   //--------------------------------------------------
   // Replay Parameters
   //--------------------------------------------------

   m_historyBars =
      0;

   m_avgRangePeriod =
      0; 
   //--------------------------------------------------
   // Live D1 State
   //--------------------------------------------------

   m_lastProcessedD1BarTime =
      0;      
}

//+------------------------------------------------------------------+
//| Calculate Causal D1 Average Range                                |
//+------------------------------------------------------------------+
bool CPHXD1TrendContext::CalculateAvgRange(
   const MqlRates &rates[],
   const int currentIndex,
   double &avgRange
) const
{
   avgRange =
      0.0;

   if(m_avgRangePeriod <= 0)
      return false;

   if(currentIndex < 0)
      return false;

   int firstIndex =
      currentIndex -
      m_avgRangePeriod +
      1;

   //--------------------------------------------------
   // Warm-up period is not an error
   //--------------------------------------------------

   if(firstIndex < 0)
      return false;

   double sum =
      0.0;

   for(
      int i = firstIndex;
      i <= currentIndex;
      i++
   )
   {
      double range =
         rates[i].high -
         rates[i].low;

      if(range < 0.0)
         return false;

      sum +=
         range;
   }

   avgRange =
      sum /
      (double)m_avgRangePeriod;

   return (avgRange > 0.0);
}
//+------------------------------------------------------------------+
//| Update D1 Structure Classification                               |
//+------------------------------------------------------------------+
bool CPHXD1TrendContext::UpdateStructureClassification()
{
   //--------------------------------------------------
   // Read Confirmed D1 Extremes From Price Structure
   //--------------------------------------------------

   SPHXPriceExtreme previousHigh =
      m_structure.GetPreviousConfirmedHigh();

   SPHXPriceExtreme lastHigh =
      m_structure.GetLastConfirmedHigh();

   SPHXPriceExtreme previousLow =
      m_structure.GetPreviousConfirmedLow();

   SPHXPriceExtreme lastLow =
      m_structure.GetLastConfirmedLow();

   //--------------------------------------------------
   // Store D1 Structural Extremes
   //--------------------------------------------------

   m_context.PreviousConfirmedHigh =
      previousHigh;

   m_context.LastConfirmedHigh =
      lastHigh;

   m_context.PreviousConfirmedLow =
      previousLow;

   m_context.LastConfirmedLow =
      lastLow;

   //--------------------------------------------------
   // Validate High Structure
   //--------------------------------------------------

   bool highStructureReady =
      (
         previousHigh.Type ==
         PHX_EXTREMUM_HIGH
         &&
         lastHigh.Type ==
         PHX_EXTREMUM_HIGH
         &&
         previousHigh.ExtremeTime > 0
         &&
         lastHigh.ExtremeTime > 0
         &&
         previousHigh.ExtremeTime <
         lastHigh.ExtremeTime
      );

   //--------------------------------------------------
   // Validate Low Structure
   //--------------------------------------------------

   bool lowStructureReady =
      (
         previousLow.Type ==
         PHX_EXTREMUM_LOW
         &&
         lastLow.Type ==
         PHX_EXTREMUM_LOW
         &&
         previousLow.ExtremeTime > 0
         &&
         lastLow.ExtremeTime > 0
         &&
         previousLow.ExtremeTime <
         lastLow.ExtremeTime
      );

   //--------------------------------------------------
   // Not Enough Confirmed D1 Structure Yet
   //--------------------------------------------------

   if(
      !highStructureReady ||
      !lowStructureReady
   )
   {
      Print(
         "PHX D1 Trend Context: ",
         "HH/HL/LH/LL structure not ready"
      );

      return true;
   }

   //--------------------------------------------------
   // Classify Highs
   //--------------------------------------------------

   string highClass =
      "EQUAL_HIGH";

   if(
      lastHigh.ExtremePrice >
      previousHigh.ExtremePrice
   )
   {
      highClass =
         "HH";
   }
   else
   if(
      lastHigh.ExtremePrice <
      previousHigh.ExtremePrice
   )
   {
      highClass =
         "LH";
   }

   //--------------------------------------------------
   // Classify Lows
   //--------------------------------------------------

   string lowClass =
      "EQUAL_LOW";

   if(
      lastLow.ExtremePrice >
      previousLow.ExtremePrice
   )
   {
      lowClass =
         "HL";
   }
   else
   if(
      lastLow.ExtremePrice <
      previousLow.ExtremePrice
   )
   {
      lowClass =
         "LL";
   }

   //--------------------------------------------------
   // Diagnostics
   //--------------------------------------------------

   Print(
      "PHX D1 STRUCTURE: ",
      "High=",
      highClass,
      " PrevHigh=",
      DoubleToString(
         previousHigh.ExtremePrice,
         _Digits
      ),
      " LastHigh=",
      DoubleToString(
         lastHigh.ExtremePrice,
         _Digits
      ),
      " Low=",
      lowClass,
      " PrevLow=",
      DoubleToString(
         previousLow.ExtremePrice,
         _Digits
      ),
      " LastLow=",
      DoubleToString(
         lastLow.ExtremePrice,
         _Digits
      )
   );

   return true;
}
//+------------------------------------------------------------------+
//| Update D1 Trend State                                            |
//+------------------------------------------------------------------+
bool CPHXD1TrendContext::UpdateTrendState()
{
   //--------------------------------------------------
   // Read Confirmed D1 Structure
   //--------------------------------------------------

   SPHXPriceExtreme previousHigh =
      m_context.PreviousConfirmedHigh;

   SPHXPriceExtreme lastHigh =
      m_context.LastConfirmedHigh;

   SPHXPriceExtreme previousLow =
      m_context.PreviousConfirmedLow;

   SPHXPriceExtreme lastLow =
      m_context.LastConfirmedLow;

   //--------------------------------------------------
   // Validate Structural Pairs
   //--------------------------------------------------

   bool highStructureReady =
      (
         previousHigh.Type ==
         PHX_EXTREMUM_HIGH
         &&
         lastHigh.Type ==
         PHX_EXTREMUM_HIGH
         &&
         previousHigh.ExtremeTime > 0
         &&
         lastHigh.ExtremeTime > 0
         &&
         previousHigh.ExtremeTime <
         lastHigh.ExtremeTime
      );

   bool lowStructureReady =
      (
         previousLow.Type ==
         PHX_EXTREMUM_LOW
         &&
         lastLow.Type ==
         PHX_EXTREMUM_LOW
         &&
         previousLow.ExtremeTime > 0
         &&
         lastLow.ExtremeTime > 0
         &&
         previousLow.ExtremeTime <
         lastLow.ExtremeTime
      );

   //--------------------------------------------------
   // Until Both Structural Pairs Exist,
   // Trend Cannot Be Classified
   //--------------------------------------------------

   if(
      !highStructureReady ||
      !lowStructureReady
   )
   {
      return true;
   }

   //--------------------------------------------------
   // Current Structural Relations
   //--------------------------------------------------

   bool higherHigh =
      (
         lastHigh.ExtremePrice >
         previousHigh.ExtremePrice
      );

   bool lowerHigh =
      (
         lastHigh.ExtremePrice <
         previousHigh.ExtremePrice
      );

   bool higherLow =
      (
         lastLow.ExtremePrice >
         previousLow.ExtremePrice
      );

   bool lowerLow =
      (
         lastLow.ExtremePrice <
         previousLow.ExtremePrice
      );

   //--------------------------------------------------
   // Current State Before This Structural Event
   //--------------------------------------------------

   ENUM_PHX_D1_TREND_STATE oldState =
      m_context.CurrentTrend;

   ENUM_PHX_D1_TREND_STATE newState =
      oldState;

   //--------------------------------------------------
   // UNKNOWN
   //--------------------------------------------------

   if(
      oldState ==
      PHX_D1_TREND_UNKNOWN
   )
   {
      if(
         higherHigh &&
         higherLow
      )
      {
         newState =
            PHX_D1_TREND_BULLISH;
      }
      else
      if(
         lowerHigh &&
         lowerLow
      )
      {
         newState =
            PHX_D1_TREND_BEARISH;
      }
   }

   //--------------------------------------------------
   // BULLISH
   //
   // Structural break begins only after confirmed LL.
   //--------------------------------------------------

   else
   if(
      oldState ==
      PHX_D1_TREND_BULLISH
   )
   {
      if(lowerLow)
      {
         newState =
            PHX_D1_TREND_TRANSITION_DOWN;

         m_context.StructureBreakDetected =
            true;

         m_context.StructureBreakBar =
            lastLow.ConfirmationBar;

         m_context.StructureBreakTime =
            lastLow.ExtremeTime;
      }
   }

   //--------------------------------------------------
   // TRANSITION DOWN
   //
   // LL followed by LH confirms BEARISH.
   //
   // Full HH + HL recovery cancels transition.
   //--------------------------------------------------

   else
   if(
      oldState ==
      PHX_D1_TREND_TRANSITION_DOWN
   )
   {
      if(
         lowerHigh &&
         lowerLow
      )
      {
         newState =
            PHX_D1_TREND_BEARISH;

         m_context.TrendChangeConfirmed =
            true;

         m_context.TrendChangeBar =
            lastHigh.ConfirmationBar;

         m_context.TrendChangeTime =
            lastHigh.ExtremeTime;
      }
      else
      if(
         higherHigh &&
         higherLow
      )
      {
         newState =
            PHX_D1_TREND_BULLISH;

         m_context.StructureBreakDetected =
            false;

         m_context.StructureBreakBar =
            -1;

         m_context.StructureBreakTime =
            0;
      }
   }

   //--------------------------------------------------
   // BEARISH
   //
   // Structural break begins only after confirmed HH.
   //--------------------------------------------------

   else
   if(
      oldState ==
      PHX_D1_TREND_BEARISH
   )
   {
      if(higherHigh)
      {
         newState =
            PHX_D1_TREND_TRANSITION_UP;

         m_context.StructureBreakDetected =
            true;

         m_context.StructureBreakBar =
            lastHigh.ConfirmationBar;

         m_context.StructureBreakTime =
            lastHigh.ExtremeTime;
      }
   }

   //--------------------------------------------------
   // TRANSITION UP
   //
   // HH followed by HL confirms BULLISH.
   //
   // Full LH + LL recovery cancels transition.
   //--------------------------------------------------

   else
   if(
      oldState ==
      PHX_D1_TREND_TRANSITION_UP
   )
   {
      if(
         higherHigh &&
         higherLow
      )
      {
         newState =
            PHX_D1_TREND_BULLISH;

         m_context.TrendChangeConfirmed =
            true;

         m_context.TrendChangeBar =
            lastLow.ConfirmationBar;

         m_context.TrendChangeTime =
            lastLow.ExtremeTime;
      }
      else
      if(
         lowerHigh &&
         lowerLow
      )
      {
         newState =
            PHX_D1_TREND_BEARISH;

         m_context.StructureBreakDetected =
            false;

         m_context.StructureBreakBar =
            -1;

         m_context.StructureBreakTime =
            0;
      }
   }

   //--------------------------------------------------
   // Store State Change Only
   //--------------------------------------------------

   if(newState != oldState)
   {
      m_context.PreviousTrend =
         oldState;

      m_context.CurrentTrend =
         newState;

      m_context.TrendAgeBars =
         0;

      Print(
         "PHX D1 TREND CHANGE: ",
         "Previous=",
         (int)oldState,
         " Current=",
         (int)newState,
         " HH=",
         higherHigh,
         " LH=",
         lowerHigh,
         " HL=",
         higherLow,
         " LL=",
         lowerLow
      );
   }

   return true;
}
//+------------------------------------------------------------------+
//| Build Historical D1 Structure                                   |
//+------------------------------------------------------------------+
bool CPHXD1TrendContext::Build(
   const int historyBars,
   const int avgRangePeriod
)
{
   //--------------------------------------------------
   // Reset Previous State
   //--------------------------------------------------

   Reset();

   //--------------------------------------------------
   // Validate Parameters
   //--------------------------------------------------

   if(historyBars <= 0)
      return false;

   if(avgRangePeriod <= 0)
      return false;

   if(historyBars < avgRangePeriod)
      return false;

   m_historyBars =
      historyBars;

   m_avgRangePeriod =
      avgRangePeriod;

   //--------------------------------------------------
   // Load Completed D1 Bars Only
   //--------------------------------------------------

   MqlRates rates[];

   ArraySetAsSeries(
      rates,
      false
   );

   int copied =
      CopyRates(
         _Symbol,
         PERIOD_D1,
         1,
         m_historyBars,
         rates
      );

   //--------------------------------------------------
   // Full 30-D1 History Is Mandatory
   //--------------------------------------------------

   if(copied != m_historyBars)
   {
      Print(
         "PHX D1 Trend Context NOT READY: ",
         "Requested=",
         m_historyBars,
         " Copied=",
         copied
      );

      return false;
   }

   if(ArraySize(rates) != m_historyBars)
      return false;

   //--------------------------------------------------
   // Chronological Replay
   //--------------------------------------------------

   for(
      int i = 0;
      i < m_historyBars;
      i++
   )
   {
      //------------------------------------------------
      // Calculate Historical D1 AvgRange
      //------------------------------------------------

      double avgRange =
         0.0;

      //------------------------------------------------
      // Causal Warm-up
      //------------------------------------------------

      if(
         !CalculateAvgRange(
            rates,
            i,
            avgRange
         )
      )
      {
         continue;
      }

      //------------------------------------------------
      // Feed Current Historical AvgRange
      //------------------------------------------------

      if(
         !m_structure.SetAvgRange(
            avgRange
         )
      )
      {
         return false;
      }

      //------------------------------------------------
      // Snapshot Confirmed Extremes BEFORE D1 Bar
      //------------------------------------------------

      SPHXPriceExtreme highBefore =
         m_structure.GetLastConfirmedHigh();

      SPHXPriceExtreme lowBefore =
         m_structure.GetLastConfirmedLow();

      //------------------------------------------------
      // Process Completed Historical D1 Bar
      //------------------------------------------------

      if(
         !m_structure.ProcessClosedBar(
            i,
            rates[i]
         )
      )
      {
         return false;
      }

      //------------------------------------------------
      // Read Confirmed Extremes AFTER D1 Bar
      //------------------------------------------------

      SPHXPriceExtreme highAfter =
         m_structure.GetLastConfirmedHigh();

      SPHXPriceExtreme lowAfter =
         m_structure.GetLastConfirmedLow();

      //------------------------------------------------
      // Detect New Confirmed HIGH
      //------------------------------------------------

      bool newConfirmedHigh =
         (
            highAfter.Type ==
            PHX_EXTREMUM_HIGH
            &&
            highAfter.ExtremeTime > 0
            &&
            (
               highBefore.Type !=
               PHX_EXTREMUM_HIGH
               ||
               highBefore.ExtremeTime !=
               highAfter.ExtremeTime
            )
         );

      //------------------------------------------------
      // Detect New Confirmed LOW
      //------------------------------------------------

      bool newConfirmedLow =
         (
            lowAfter.Type ==
            PHX_EXTREMUM_LOW
            &&
            lowAfter.ExtremeTime > 0
            &&
            (
               lowBefore.Type !=
               PHX_EXTREMUM_LOW
               ||
               lowBefore.ExtremeTime !=
               lowAfter.ExtremeTime
            )
         );

      //------------------------------------------------
      // Update D1 Context Only On Structural Event
      //------------------------------------------------

      if(
         newConfirmedHigh ||
         newConfirmedLow
      )
      {
         if(!UpdateStructureClassification())
         {
            Print(
               "PHX D1 Trend Context ERROR: ",
               "Structure classification failed"
            );

            return false;
         }

         if(!UpdateTrendState())
         {
            Print(
               "PHX D1 Trend Context ERROR: ",
               "Trend state update failed"
            );

            return false;
         }
      }
   }   
   //--------------------------------------------------
   // Validate Resulting Structure
   //--------------------------------------------------
   if(!m_structure.IsAvgRangeReady())
   {
      Print(
         "PHX D1 Trend Context NOT READY: ",
         "AvgRange unavailable"
      );

      return false;
   } 
   //--------------------------------------------------
   // Remember Last Historical D1 Bar
   //--------------------------------------------------

   m_lastProcessedD1BarTime =
      rates[m_historyBars - 1].time;
   //--------------------------------------------------
   // Replay Completed
   //--------------------------------------------------
   m_ready =
      true;

   Print(
      "PHX D1 Trend Context READY: ",
      "HistoryBars=",
      m_historyBars,
      " AvgRangePeriod=",
      m_avgRangePeriod,
      " AvgRange=",
      DoubleToString(
         m_structure.GetAvgRange(),
         _Digits
      )
   );

   return true;
}

//+------------------------------------------------------------------+
//| Update Live D1 Trend Context                                     |
//+------------------------------------------------------------------+
bool CPHXD1TrendContext::Update()
{
   //--------------------------------------------------
   // Validate State
   //--------------------------------------------------

   if(!m_ready)
      return false;

   if(m_lastProcessedD1BarTime <= 0)
      return false;

   if(m_avgRangePeriod <= 0)
      return false;

   //--------------------------------------------------
   // Latest CLOSED D1 Bar
   //--------------------------------------------------

   datetime latestClosedD1Time =
      iTime(
         _Symbol,
         PERIOD_D1,
         1
      );

   if(latestClosedD1Time <= 0)
      return false;

   //--------------------------------------------------
   // Nothing New
   //--------------------------------------------------

   if(
      latestClosedD1Time <=
      m_lastProcessedD1BarTime
   )
   {
      return true;
   }

   //--------------------------------------------------
   // Load All Missing CLOSED D1 Bars
   //--------------------------------------------------

   MqlRates missingRates[];

   ArraySetAsSeries(
      missingRates,
      false
   );

   datetime firstMissingTime =
      m_lastProcessedD1BarTime + 1;

   int copied =
      CopyRates(
         _Symbol,
         PERIOD_D1,
         firstMissingTime,
         latestClosedD1Time,
         missingRates
      );

   if(copied <= 0)
      return false;

   //--------------------------------------------------
   // Process Missing D1 Bars Oldest -> Newest
   //--------------------------------------------------

   for(
      int i = 0;
      i < copied;
      i++
   )
   {
      //------------------------------------------------
      // Safety: Already Processed
      //------------------------------------------------

      if(
         missingRates[i].time <=
         m_lastProcessedD1BarTime
      )
      {
         continue;
      }

      //------------------------------------------------
      // Exact Shift Of Current Historical/Live D1 Bar
      //------------------------------------------------

      int currentShift =
         iBarShift(
            _Symbol,
            PERIOD_D1,
            missingRates[i].time,
            true
         );

      if(currentShift <= 0)
         return false;

      //------------------------------------------------
      // Load Causal AvgRange Window
      //------------------------------------------------

      MqlRates rangeRates[];

      ArraySetAsSeries(
         rangeRates,
         false
      );

      int rangeCopied =
         CopyRates(
            _Symbol,
            PERIOD_D1,
            currentShift,
            m_avgRangePeriod,
            rangeRates
         );

      if(rangeCopied != m_avgRangePeriod)
         return false;

      //------------------------------------------------
      // Calculate AvgRange
      //
      // CopyRates by shift returns the required closed
      // historical window. Average is calculated here
      // without using current unfinished D1.
      //------------------------------------------------

      double rangeSum =
         0.0;

      for(
         int r = 0;
         r < m_avgRangePeriod;
         r++
      )
      {
         double candleRange =
            rangeRates[r].high -
            rangeRates[r].low;

         if(candleRange < 0.0)
            return false;

         rangeSum +=
            candleRange;
      }

      double avgRange =
         rangeSum /
         (double)m_avgRangePeriod;

      if(avgRange <= 0.0)
         return false;

      //------------------------------------------------
      // Feed Current D1 AvgRange
      //------------------------------------------------

      if(
         !m_structure.SetAvgRange(
            avgRange
         )
      )
      {
         return false;
      }

      //------------------------------------------------
      // Snapshot Confirmed Extremes BEFORE D1 Bar
      //------------------------------------------------

      SPHXPriceExtreme highBefore =
         m_structure.GetLastConfirmedHigh();

      SPHXPriceExtreme lowBefore =
         m_structure.GetLastConfirmedLow();

      //------------------------------------------------
      // Process New CLOSED D1 Bar
      //
      // We use its actual shift as diagnostic bar id.
      // Structural matching itself relies on time/price.
      //------------------------------------------------

      if(
         !m_structure.ProcessClosedBar(
            currentShift,
            missingRates[i]
         )
      )
      {
         return false;
      }

      //------------------------------------------------
      // Confirmed Extremes AFTER D1 Bar
      //------------------------------------------------

      SPHXPriceExtreme highAfter =
         m_structure.GetLastConfirmedHigh();

      SPHXPriceExtreme lowAfter =
         m_structure.GetLastConfirmedLow();

      bool newConfirmedHigh =
         (
            highAfter.Type ==
            PHX_EXTREMUM_HIGH
            &&
            highAfter.ExtremeTime > 0
            &&
            (
               highBefore.Type !=
               PHX_EXTREMUM_HIGH
               ||
               highBefore.ExtremeTime !=
               highAfter.ExtremeTime
            )
         );

      bool newConfirmedLow =
         (
            lowAfter.Type ==
            PHX_EXTREMUM_LOW
            &&
            lowAfter.ExtremeTime > 0
            &&
            (
               lowBefore.Type !=
               PHX_EXTREMUM_LOW
               ||
               lowBefore.ExtremeTime !=
               lowAfter.ExtremeTime
            )
         );

      //------------------------------------------------
      // Update D1 State Only On Structural Event
      //------------------------------------------------

      if(
         newConfirmedHigh ||
         newConfirmedLow
      )
      {
         if(!UpdateStructureClassification())
            return false;

         if(!UpdateTrendState())
            return false;
      }

      //------------------------------------------------
      // Mark This D1 Bar As Processed
      //------------------------------------------------

      m_lastProcessedD1BarTime =
         missingRates[i].time;
   }

   return true;
}

//+------------------------------------------------------------------+
//| Is Ready                                                         |
//+------------------------------------------------------------------+
bool CPHXD1TrendContext::IsReady() const
{
   return m_ready;
}

//+------------------------------------------------------------------+
//| Get Context                                                      |
//+------------------------------------------------------------------+
SPHXD1TrendContext
CPHXD1TrendContext::GetContext() const
{
   return m_context;
}

//+------------------------------------------------------------------+
//| Get D1 Price Structure                                           |
//+------------------------------------------------------------------+
CPHXPriceStructure*
CPHXD1TrendContext::GetStructure()
{
   return &m_structure;
}

#endif // __PHX_D1_TREND_CONTEXT_MQH__