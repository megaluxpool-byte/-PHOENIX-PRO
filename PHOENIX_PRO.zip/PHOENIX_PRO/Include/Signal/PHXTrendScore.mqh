//+------------------------------------------------------------------+
//|                  PHXTrendScore.mqh                               |
//|                 PHOENIX PRO Trading Framework                    |
//|                                                                  |
//| Description:                                                     |
//|   Root container for trend score                                 |
//+------------------------------------------------------------------+

#ifndef PHX_TREND_SCORE_MQH
#define PHX_TREND_SCORE_MQH

//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXTrendScoreTypes.mqh"
#include "IPHXTrendScoreProvider.mqh"
#include "../Statistics/PHXTrendStatisticsTypes.mqh"


//+------------------------------------------------------------------+
//| Trend Score Engine                                               |
//+------------------------------------------------------------------+
class CPHXTrendScore :
   public IPHXTrendScoreProvider
{

private:

   //--------------------------------------------------
   // Score
   //--------------------------------------------------

   SPHXTrendScore m_score;


public:

   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------

   CPHXTrendScore();


   //--------------------------------------------------
   // Reset
   //--------------------------------------------------

   void Reset();


   //--------------------------------------------------
   // Calculate
   //--------------------------------------------------
   bool Calculate(
   const SPHXTrendSnapshot &snapshot
); 

   SPHXTrendScore GetScore() const override;
   
   SPHXTrendSnapshot GetSnapshot() const override;


   virtual bool Calculate(
      SPHXTrendScore &score
   );


   //--------------------------------------------------
   // Get Score
   //--------------------------------------------------

   virtual bool GetScore(
      SPHXTrendScore &score
   ) const;


private:

   //--------------------------------------------------
   // EMA Score
   //--------------------------------------------------

   void CalculateEMA(
      const SPHXTrendSnapshot &snapshot
   );


   //--------------------------------------------------
   // ATR Score
   //--------------------------------------------------

   void CalculateATR(
      const SPHXTrendSnapshot &snapshot
   );


   //--------------------------------------------------
   // RSI Score
   //--------------------------------------------------

   void CalculateRSI(
      const SPHXTrendSnapshot &snapshot
   );


   //--------------------------------------------------
   // Volume Score
   //--------------------------------------------------

   void CalculateVolume(
      const SPHXTrendSnapshot &snapshot
   );
   
   //--------------------------------------------------
   // ADX Score
   //--------------------------------------------------
    
   void CalculateADX(
   const SPHXTrendSnapshot &snapshot
   );

   //--------------------------------------------------
   // Market Score
   //--------------------------------------------------

   void CalculateMarket(
      const SPHXTrendSnapshot &snapshot
   );


};


//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+

CPHXTrendScore::CPHXTrendScore()
{
   Reset();
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+

void CPHXTrendScore::Reset()
{
   m_score.Reset();
}


//+------------------------------------------------------------------+
//| Calculate                                                        |
//+------------------------------------------------------------------+

bool CPHXTrendScore::Calculate(
   const SPHXTrendSnapshot &snapshot
)
{

   m_score.Reset();


   //--------------------------------------------------
   // EMA
   //--------------------------------------------------

   CalculateEMA(snapshot);
   
   //--------------------------------------------------
   // ATR
   //--------------------------------------------------

   CalculateATR(snapshot);
   
   //--------------------------------------------------
   // RSI
   //--------------------------------------------------

   CalculateRSI(snapshot);
   
   //--------------------------------------------------
   // Volume
   //--------------------------------------------------

   CalculateVolume(snapshot);
   
   //--------------------------------------------------
   // ADX
   //--------------------------------------------------
   
   CalculateADX(snapshot);
   
   //--------------------------------------------------
   // Market
   //--------------------------------------------------
   
   CalculateMarket(snapshot); 
   
   //--------------------------------------------------
   // Total Trend Score
   //--------------------------------------------------

   //--------------------------------------------------
   // Total Trend Direction Score
   //--------------------------------------------------

   m_score.Total =
   m_score.EMA.Total +
   m_score.RSI.Total +
   m_score.ADX.Total;
   
//--------------------------------------------------
// Debug
//--------------------------------------------------

   return true;

}

//+------------------------------------------------------------------+
//| Get Score                                                        |
//+------------------------------------------------------------------+

bool CPHXTrendScore::GetScore(
   SPHXTrendScore &score
) const
{
   score = m_score;

   return true;
}


//+------------------------------------------------------------------+
//| Calculate EMA Score                                              |
//+------------------------------------------------------------------+

void CPHXTrendScore::CalculateEMA(
   const SPHXTrendSnapshot &snapshot
)
{

   m_score.EMA.Reset();


   //--------------------------------------------------
   // EMA Fan
   //--------------------------------------------------

   if(
      snapshot.EMA20 > snapshot.EMA50 &&
      snapshot.EMA50 > snapshot.EMA100 &&
      snapshot.EMA100 > snapshot.EMA200
   )
   {
      m_score.EMA.Fan = 1;
   }
   else
   if(
      snapshot.EMA20 < snapshot.EMA50 &&
      snapshot.EMA50 < snapshot.EMA100 &&
      snapshot.EMA100 < snapshot.EMA200
   )
   {
      m_score.EMA.Fan = -1;
   }


   //--------------------------------------------------
   // Distance
   //--------------------------------------------------

   double distance =
      MathAbs(snapshot.EMA20 - snapshot.EMA200);


   if(distance > 0)
      m_score.EMA.Distance = 1;



   //--------------------------------------------------
   // Total
   //--------------------------------------------------

      m_score.EMA.Total =
      m_score.EMA.Fan +
      m_score.EMA.Distance;

}


//+------------------------------------------------------------------+
//| Calculate ATR Score                                              |
//+------------------------------------------------------------------+

void CPHXTrendScore::CalculateATR(
   const SPHXTrendSnapshot &snapshot
)
{

   m_score.ATR.Reset();


   //--------------------------------------------------
   // ATR Energy
   //--------------------------------------------------

   if(snapshot.ATR > 0)
   {
      m_score.ATR.Energy = 1;
   }


   //--------------------------------------------------
   // ATR Momentum
   //--------------------------------------------------

   if(snapshot.ATR > 0)
   {
      m_score.ATR.Momentum = 1;
   }


   //--------------------------------------------------
   // Total
   //--------------------------------------------------

   m_score.ATR.Total =
      m_score.ATR.Energy +
      m_score.ATR.Momentum;

}


//+------------------------------------------------------------------+
//| Calculate RSI Score                                              |
//+------------------------------------------------------------------+

void CPHXTrendScore::CalculateRSI(
   const SPHXTrendSnapshot &snapshot
)
{

   m_score.RSI.Reset();


   //--------------------------------------------------
   // RSI Direction
   //--------------------------------------------------

   if(snapshot.RSI > 50)
   {
      m_score.RSI.Direction = 1;
   }
   else
   if(snapshot.RSI < 50)
   {
      m_score.RSI.Direction = -1;
   }


   //--------------------------------------------------
   // RSI Strength
   //--------------------------------------------------

   if(snapshot.RSI > 60)
   {
      m_score.RSI.Strength = 1;
   }
   else
   if(snapshot.RSI < 40)
   {
      m_score.RSI.Strength = -1;
   }


   //--------------------------------------------------
   // Total
   //--------------------------------------------------

   m_score.RSI.Total =
      m_score.RSI.Direction +
      m_score.RSI.Strength;

}


//+------------------------------------------------------------------+
//| Calculate Volume Score                                           |
//+------------------------------------------------------------------+

void CPHXTrendScore::CalculateVolume(
   const SPHXTrendSnapshot &snapshot
)
{

   m_score.Volume.Reset();


   //--------------------------------------------------
   // Volume Above Average
   //--------------------------------------------------

   if(snapshot.Volume > snapshot.AverageVolume)
   {
      m_score.Volume.AboveAverage = 1;
   }


   //--------------------------------------------------
   // Volume Growth
   //--------------------------------------------------

   if(snapshot.Volume > 0)
   {
      m_score.Volume.Growth = 1;
   }


   //--------------------------------------------------
   // Total
   //--------------------------------------------------

   m_score.Volume.Total =
      m_score.Volume.AboveAverage +
      m_score.Volume.Growth;

}

//+------------------------------------------------------------------+
//| Calculate ADX Score                                              |
//+------------------------------------------------------------------+

void CPHXTrendScore::CalculateADX(
   const SPHXTrendSnapshot &snapshot
)
{

   m_score.ADX.Reset();


   //--------------------------------------------------
   // ADX Strength
   //--------------------------------------------------

   if(snapshot.ADX >= 25.0)
   {
      m_score.ADX.Strength = 2;
   }
   else
   if(snapshot.ADX >= 15.0)
   {
      m_score.ADX.Strength = 1;
   }


   //--------------------------------------------------
   // Direction
   //--------------------------------------------------

   if(snapshot.PlusDI > snapshot.MinusDI)
   {
      m_score.ADX.Direction = 1;
   }
   else
   if(snapshot.MinusDI > snapshot.PlusDI)
   {
      m_score.ADX.Direction = -1;
   }


   //--------------------------------------------------
   // Trend Quality
   //--------------------------------------------------

   double separation =
      MathAbs(
         snapshot.PlusDI -
         snapshot.MinusDI
      );


   if(separation > 15.0)
   {
      m_score.ADX.TrendQuality = 2;
   }
   else
   if(separation > 5.0)
   {
      m_score.ADX.TrendQuality = 1;
   }


   //--------------------------------------------------
   // Total
   //--------------------------------------------------

   if(m_score.ADX.Direction > 0)
   {
      m_score.ADX.Total =
         m_score.ADX.Strength +
         m_score.ADX.TrendQuality;
   }
   else
   if(m_score.ADX.Direction < 0)
   {
      m_score.ADX.Total =
        -(
         m_score.ADX.Strength +
         m_score.ADX.TrendQuality
         );
   }
   else
   {
      m_score.ADX.Total = 0;
   }
 //--------------------------------------------------
   // ADX Diagnostics
   //--------------------------------------------------

}
//+------------------------------------------------------------------+
//| Calculate Market Score                                           |
//+------------------------------------------------------------------+

void CPHXTrendScore::CalculateMarket(
   const SPHXTrendSnapshot &snapshot
)
{

   m_score.Market.Reset();


   //--------------------------------------------------
   // Spread
   //--------------------------------------------------

   if(snapshot.Spread > 0)
   {
      m_score.Market.Spread = 1;
   }


   //--------------------------------------------------
   // Session
   //--------------------------------------------------

   if(snapshot.SessionOpen)
   {
      m_score.Market.Session = 1;
   }


   //--------------------------------------------------
   // Liquidity
   //--------------------------------------------------

   if(snapshot.HighLiquidity)
   {
      m_score.Market.Liquidity = 1;
   }


   //--------------------------------------------------
   // Total
   //--------------------------------------------------

   m_score.Market.Total =
      m_score.Market.Spread +
      m_score.Market.Session +
      m_score.Market.Liquidity;

}

   //+------------------------------------------------------------------+
   //| Get Score                                                        |
   //+------------------------------------------------------------------+

   SPHXTrendScore CPHXTrendScore::GetScore() const
{
   return m_score;
}
   //+------------------------------------------------------------------+
   //| Get Snapshot                                                     |
   //+------------------------------------------------------------------+

   SPHXTrendSnapshot CPHXTrendScore::GetSnapshot() const
{
   SPHXTrendSnapshot snapshot;

   snapshot.Reset();

   return snapshot;
}


#endif // PHX_TREND_SCORE_MQH