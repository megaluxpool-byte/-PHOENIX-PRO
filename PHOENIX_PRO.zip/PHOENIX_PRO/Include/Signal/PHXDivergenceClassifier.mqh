#ifndef __PHX_DIVERGENCE_CLASSIFIER_MQH__
#define __PHX_DIVERGENCE_CLASSIFIER_MQH__

#include "PHXSignalTypes.mqh"

//+------------------------------------------------------------------+
//| PHOENIX PRO                                                      |
//| Divergence Classifier                                            |
//+------------------------------------------------------------------+
class CPHXDivergenceClassifier
{
public:

   CPHXDivergenceClassifier();

   ENUM_PHX_DIVERGENCE_TYPE Classify(
      const ENUM_PHX_EXTREMUM_TYPE extremumType,
      const ENUM_PHX_DIVERGENCE_DIRECTION priceDirection,
      const ENUM_PHX_DIVERGENCE_DIRECTION ppoDirection
   ) const;
};


//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXDivergenceClassifier::CPHXDivergenceClassifier()
{
}


//+------------------------------------------------------------------+
//| Classify Divergence                                              |
//+------------------------------------------------------------------+
ENUM_PHX_DIVERGENCE_TYPE CPHXDivergenceClassifier::Classify(
   const ENUM_PHX_EXTREMUM_TYPE extremumType,
   const ENUM_PHX_DIVERGENCE_DIRECTION priceDirection,
   const ENUM_PHX_DIVERGENCE_DIRECTION ppoDirection
) const
{
   //--------------------------------------------------
   // Validate Extremum Type
   //--------------------------------------------------

   if(
      extremumType != PHX_EXTREMUM_HIGH &&
      extremumType != PHX_EXTREMUM_LOW
   )
   {
      return PHX_DIVERGENCE_NONE;
   }

   //--------------------------------------------------
   // Both Flat
   //--------------------------------------------------

   if(
      priceDirection == PHX_DIVERGENCE_DIRECTION_FLAT &&
      ppoDirection == PHX_DIVERGENCE_DIRECTION_FLAT
   )
   {
      return PHX_DIVERGENCE_NONE;
   }

   //--------------------------------------------------
   // Borderline
   //
   // One side is FLAT.
   // Research only, not full divergence.
   //--------------------------------------------------

   if(
      priceDirection == PHX_DIVERGENCE_DIRECTION_FLAT ||
      ppoDirection == PHX_DIVERGENCE_DIRECTION_FLAT
   )
   {
      if(extremumType == PHX_EXTREMUM_HIGH)
         return PHX_DIVERGENCE_BORDERLINE_BEARISH;

      if(extremumType == PHX_EXTREMUM_LOW)
         return PHX_DIVERGENCE_BORDERLINE_BULLISH;

      return PHX_DIVERGENCE_NONE;
   }

   //--------------------------------------------------
   // Same Direction
   //
   // No divergence.
   //--------------------------------------------------

   if(priceDirection == ppoDirection)
      return PHX_DIVERGENCE_NONE;

   //--------------------------------------------------
   // HIGH Pair
   //--------------------------------------------------

   if(extremumType == PHX_EXTREMUM_HIGH)
   {
      //------------------------------------------------
      // Price Higher High
      // PPO Lower High
      //------------------------------------------------

      if(
         priceDirection == PHX_DIVERGENCE_DIRECTION_UP &&
         ppoDirection == PHX_DIVERGENCE_DIRECTION_DOWN
      )
      {
         return PHX_DIVERGENCE_REGULAR_BEARISH;
      }

      //------------------------------------------------
      // Price Lower High
      // PPO Higher High
      //------------------------------------------------

      if(
         priceDirection == PHX_DIVERGENCE_DIRECTION_DOWN &&
         ppoDirection == PHX_DIVERGENCE_DIRECTION_UP
      )
      {
         return PHX_DIVERGENCE_HIDDEN_BEARISH;
      }

      return PHX_DIVERGENCE_NONE;
   }

   //--------------------------------------------------
   // LOW Pair
   //--------------------------------------------------

   if(extremumType == PHX_EXTREMUM_LOW)
   {
      //------------------------------------------------
      // Price Lower Low
      // PPO Higher Low
      //------------------------------------------------

      if(
         priceDirection == PHX_DIVERGENCE_DIRECTION_DOWN &&
         ppoDirection == PHX_DIVERGENCE_DIRECTION_UP
      )
      {
         return PHX_DIVERGENCE_REGULAR_BULLISH;
      }

      //------------------------------------------------
      // Price Higher Low
      // PPO Lower Low
      //------------------------------------------------

      if(
         priceDirection == PHX_DIVERGENCE_DIRECTION_UP &&
         ppoDirection == PHX_DIVERGENCE_DIRECTION_DOWN
      )
      {
         return PHX_DIVERGENCE_HIDDEN_BULLISH;
      }

      return PHX_DIVERGENCE_NONE;
   }

   return PHX_DIVERGENCE_NONE;
}

#endif