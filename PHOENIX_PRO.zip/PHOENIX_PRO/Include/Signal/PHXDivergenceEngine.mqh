#ifndef __PHX_DIVERGENCE_ENGINE_MQH__
#define __PHX_DIVERGENCE_ENGINE_MQH__

#include "PHXSignalTypes.mqh"
#include "PHXDivergenceMatcher.mqh"
#include "PHXDivergenceDetector.mqh"
#include "Divergence/PHXDivergenceStatistics.mqh"
#include "../Indicators/PHXPPO.mqh"

//+------------------------------------------------------------------+
//| PHOENIX PRO                                                      |
//| Divergence Engine                                                |
//+------------------------------------------------------------------+
class CPHXDivergenceEngine
{
private:

   CPHXDivergenceMatcher  m_matcher;
   CPHXDivergenceDetector m_detector;
   //--------------------------------------------------
   // Research Statistics
   //--------------------------------------------------
   CPHXDivergenceStatistics m_statistics;
public:

   CPHXDivergenceEngine();
   bool AnalyzePair(
      CPHXPPO *ppo,
      const SPHXPriceExtreme &firstPriceExtreme,
      const SPHXPriceExtreme &secondPriceExtreme,
      const int toleranceBars,
      const int localDepthBars,
      const int ppoChangePeriod,
      const double avgRange,
      const double priceFlatThreshold,
      const double ppoFlatThreshold,
      SPHXDivergenceResult &result
   );
//--------------------------------------------------
// Research Statistics Access
//--------------------------------------------------

void AddDetected()
{
   m_statistics.AddDetected();
}


void AddWaiting()
{
   m_statistics.AddWaiting();
}


void AddConfirmed()
{
   m_statistics.AddConfirmed();
}


void AddInvalidated()
{
   m_statistics.AddInvalidated();
}


void AddSuperseded()
{
   m_statistics.AddSuperseded();
}

void PrintStatistics()
{
   m_statistics.PrintReport();
}
};
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXDivergenceEngine::CPHXDivergenceEngine()
{

}
//+------------------------------------------------------------------+
//| Analyze Price Extreme Pair                                       |
//+------------------------------------------------------------------+
bool CPHXDivergenceEngine::AnalyzePair(
   CPHXPPO *ppo,
   const SPHXPriceExtreme &firstPriceExtreme,
   const SPHXPriceExtreme &secondPriceExtreme,
   const int toleranceBars,
   const int localDepthBars,
   const int ppoChangePeriod,
   const double avgRange,
   const double priceFlatThreshold,
   const double ppoFlatThreshold,
   SPHXDivergenceResult &result
)
{
   //--------------------------------------------------
   // Reset Output
   //--------------------------------------------------
   result.Reset();
   //--------------------------------------------------
   // Validate PPO
   //--------------------------------------------------
   if(ppo == NULL)
      return false;

   if(!(*ppo).IsInitialized())
      return false;
   //--------------------------------------------------
   // Validate Price Extremes
   //--------------------------------------------------
   if(
      firstPriceExtreme.Type != PHX_EXTREMUM_HIGH &&
      firstPriceExtreme.Type != PHX_EXTREMUM_LOW
   )
   {
      return false;
   }
   if(
      secondPriceExtreme.Type != PHX_EXTREMUM_HIGH &&
      secondPriceExtreme.Type != PHX_EXTREMUM_LOW
   )
   {
      return false;
   }
   if(
      firstPriceExtreme.Type !=
      secondPriceExtreme.Type
   )
   {
      return false;
   }
   if(
      firstPriceExtreme.ExtremeTime <= 0 ||
      secondPriceExtreme.ExtremeTime <= 0
   )
   {
      return false;
   }
   if(
      firstPriceExtreme.ExtremeTime >=
      secondPriceExtreme.ExtremeTime
   )
   {
      return false;
   }
   //--------------------------------------------------
   // Validate Parameters
   //--------------------------------------------------
   if(toleranceBars < 0)
      return false;

   if(localDepthBars <= 0)
      return false;

   if(ppoChangePeriod <= 0)
      return false;

   if(avgRange <= 0.0)
      return false;

   if(priceFlatThreshold < 0.0)
      return false;

   if(ppoFlatThreshold < 0.0)
      return false;
   //--------------------------------------------------
   // Match First Price Extreme To PPO
   //--------------------------------------------------
   SPHXDivergenceMatch firstMatch;
   firstMatch.Reset();
   if(
      !m_matcher.FindMatch(
         ppo,
         firstPriceExtreme,
         toleranceBars,
         localDepthBars,
         0,
         firstMatch
      )
   )
   {
      return false;
   }
   //--------------------------------------------------
   // No PPO Match Is Not A Technical Error
   //--------------------------------------------------
   if(!firstMatch.Matched)
   {
      result.Valid =
         true;
      result.Type =
         PHX_DIVERGENCE_NONE;
      result.Status =
         PHX_DIVERGENCE_STATUS_NONE;
      return true;
   }
   //--------------------------------------------------
   // Statistics
   // First PPO match accepted
   //--------------------------------------------------
   m_statistics.AddMatchAccepted();
   //--------------------------------------------------
   // Match Second Price Extreme To PPO
   //
   // First PPO extreme is excluded explicitly.
   //--------------------------------------------------
   SPHXDivergenceMatch secondMatch;
   secondMatch.Reset();
   if(
      !m_matcher.FindMatch(
         ppo,
         secondPriceExtreme,
         toleranceBars,
         localDepthBars,
         firstMatch.PPO.ExtremeTime,
         secondMatch
      )
   )
   {
      return false;
   }
   //--------------------------------------------------
   // No PPO Match Is Not A Technical Error
   //--------------------------------------------------
   if(!secondMatch.Matched)
   {
      result.Valid =
         true;
      result.Type =
         PHX_DIVERGENCE_NONE;
      result.Status =
         PHX_DIVERGENCE_STATUS_NONE;
      return true;
   }
   //--------------------------------------------------
   // Statistics
   // Second PPO match accepted
   //--------------------------------------------------
   m_statistics.AddMatchAccepted();
   //--------------------------------------------------
   // Determine Reference PPO Shift
   //
   // Use second price extreme as current pair context.
   //--------------------------------------------------
   int secondPriceShift =
      -1;
   if(
      !(*ppo).GetShiftByTime(
         secondPriceExtreme.ExtremeTime,
         secondPriceShift
      )
   )
   {
      return false;
   }
   //--------------------------------------------------
   // Calculate Average PPO Change
   //--------------------------------------------------
   double avgPPOChange =
      0.0;
   if(
      !(*ppo).GetAverageChange(
         secondPriceShift,
         ppoChangePeriod,
         avgPPOChange
      )
   )
   {
      return false;
   }
   //--------------------------------------------------
   // Detect And Classify Divergence
   //--------------------------------------------------
   if(
      !m_detector.Detect(
         firstMatch,
         secondMatch,
         avgRange,
         avgPPOChange,
         priceFlatThreshold,
         ppoFlatThreshold,
         result
      )
   )
   {
      return false;
   }
   //--------------------------------------------------
   // Statistics
   // Divergence candidate created
   //--------------------------------------------------

   m_statistics.AddCandidate();
   return true;
}


#endif