#ifndef __PHX_EMA_ANALYZER_MQH__
#define __PHX_EMA_ANALYZER_MQH__

//--------------------------------------------------
#include "PHXTrendTypes.mqh"

//+------------------------------------------------------------------+
//| EMA Analyzer                                                     |
//+------------------------------------------------------------------+
class CPHXEMAAnalyzer
{

private:

   SPHXTrendConfig m_config;

   double m_fastEMA;
   double m_mediumEMA;
   double m_slowEMA;
   double m_trendEMA;

public:

   CPHXEMAAnalyzer()
   {
      m_config.Reset();

      Reset();
   }

   ~CPHXEMAAnalyzer()
   {

   }

public:

   void Reset()
   {
      m_fastEMA   = 0.0;
      m_mediumEMA = 0.0;
      m_slowEMA   = 0.0;
      m_trendEMA  = 0.0;
   }

   void SetConfig(
      const SPHXTrendConfig &config
   )
   {
      m_config = config;
   }

   bool Update()
   {

      m_fastEMA =
         iMA(
            _Symbol,
            PERIOD_CURRENT,
            m_config.FastEMA,
            0,
            MODE_EMA,
            PRICE_CLOSE
         );

      m_mediumEMA =
         iMA(
            _Symbol,
            PERIOD_CURRENT,
            m_config.MediumEMA,
            0,
            MODE_EMA,
            PRICE_CLOSE
         );

      m_slowEMA =
         iMA(
            _Symbol,
            PERIOD_CURRENT,
            m_config.SlowEMA,
            0,
            MODE_EMA,
            PRICE_CLOSE
         );

      m_trendEMA =
         iMA(
            _Symbol,
            PERIOD_CURRENT,
            m_config.TrendEMA,
            0,
            MODE_EMA,
            PRICE_CLOSE
         );

      return true;
   }

public:

   double FastEMA() const
   {
      return m_fastEMA;
   }

   double MediumEMA() const
   {
      return m_mediumEMA;
   }

   double SlowEMA() const
   {
      return m_slowEMA;
   }

   double TrendEMA() const
   {
      return m_trendEMA;
   }

};

#endif // __PHX_EMA_ANALYZER_MQH__