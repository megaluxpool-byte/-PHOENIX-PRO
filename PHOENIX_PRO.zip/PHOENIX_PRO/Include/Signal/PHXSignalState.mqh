#ifndef __PHX_SIGNAL_STATE_MQH__
#define __PHX_SIGNAL_STATE_MQH__

//--------------------------------------------------
// Includes
//--------------------------------------------------
#include "PHXSignalTypes.mqh"
//+------------------------------------------------------------------+
//| Signal State                                                     |
//+------------------------------------------------------------------+
class CPHXSignalState
{
private:
   //--------------------------------------------------
   // Last signal
   //--------------------------------------------------
   ENUM_PHX_SIGNAL m_lastSignal;
   //--------------------------------------------------
   // Signal time
   //--------------------------------------------------
   datetime m_lastSignalTime;
   //--------------------------------------------------
   // Signal price
   //--------------------------------------------------
   double m_lastSignalPrice;
   //--------------------------------------------------
   // Bar time
   //--------------------------------------------------
   datetime m_lastBarTime;

public:
   CPHXSignalState();
   ~CPHXSignalState();
public:
   void Reset();
   bool IsNewSignal(
      const SPHXSignal &signal
   );
   void Update(
      const SPHXSignal &signal
   );
   ENUM_PHX_SIGNAL GetLastSignal() const;
   datetime GetLastSignalTime() const;
   double GetLastSignalPrice() const;
};
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXSignalState::CPHXSignalState()
{
   Reset();
}
//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXSignalState::~CPHXSignalState()
{

}
//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXSignalState::Reset()
{
   m_lastSignal =
      PHX_SIGNAL_NONE;
   m_lastSignalTime =
      0;
   m_lastSignalPrice =
      0.0;
   m_lastBarTime =
      0;
}
//+------------------------------------------------------------------+
//| Is New Signal                                                    |
//+------------------------------------------------------------------+
bool CPHXSignalState::IsNewSignal(
   const SPHXSignal &signal
)
{
   //--------------------------------------------------
   // No signal
   //--------------------------------------------------
   if(signal.signal == PHX_SIGNAL_NONE)
      return false;
   //--------------------------------------------------
   // Direction changed
   //--------------------------------------------------
   if(signal.signal != m_lastSignal)
      return true;
   //--------------------------------------------------
   // New bar
   //--------------------------------------------------
   datetime currentBar =
      iTime(
         _Symbol,
         PERIOD_CURRENT,
         0
      );
   if(currentBar != m_lastBarTime)
      return true;
   return false;
}
//+------------------------------------------------------------------+
//| Update                                                           |
//+------------------------------------------------------------------+
void CPHXSignalState::Update(
   const SPHXSignal &state
)
{
   m_lastSignal =
      state.signal;
   m_lastSignalTime =
      state.time;
   m_lastSignalPrice =
      state.price;
   m_lastBarTime =
      iTime(
         _Symbol,
         PERIOD_CURRENT,
         0
      );
}
//+------------------------------------------------------------------+
//| Get Last Signal                                                  |
//+------------------------------------------------------------------+
ENUM_PHX_SIGNAL CPHXSignalState::GetLastSignal() const
{
   return m_lastSignal;
}
//+------------------------------------------------------------------+
//| Get Time                                                         |
//+------------------------------------------------------------------+
datetime CPHXSignalState::GetLastSignalTime() const
{
   return m_lastSignalTime;
}
//+------------------------------------------------------------------+
//| Get Price                                                        |
//+------------------------------------------------------------------+
double CPHXSignalState::GetLastSignalPrice() const
{
   return m_lastSignalPrice;
}

#endif // __PHX_SIGNAL_STATE_MQH__