#ifndef __PHX_PRICE_STRUCTURE_MQH__
#define __PHX_PRICE_STRUCTURE_MQH__

//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXSignalTypes.mqh"

//+------------------------------------------------------------------+
//| Price Structure                                                  |
//+------------------------------------------------------------------+
class CPHXPriceStructure
{
private:

   //--------------------------------------------------
   // State
   //--------------------------------------------------

   ENUM_PHX_PRICE_STRUCTURE_STATE m_state;

   //--------------------------------------------------
   // Current Candidate
   //--------------------------------------------------

   SPHXPriceExtreme m_candidate;
//--------------------------------------------------
// Initial Structure Candidates
//--------------------------------------------------

SPHXPriceExtreme m_initialHighCandidate;
SPHXPriceExtreme m_initialLowCandidate;
   //--------------------------------------------------
   // Confirmed Extremes
   //--------------------------------------------------

   SPHXPriceExtreme m_previousConfirmedHigh;
   SPHXPriceExtreme m_lastConfirmedHigh;

   SPHXPriceExtreme m_previousConfirmedLow;
SPHXPriceExtreme m_lastConfirmedLow;

//--------------------------------------------------
// Intermediate Extremes For Same-Type Pairs
//--------------------------------------------------

SPHXPriceExtreme m_intermediateLowForHighPair;
SPHXPriceExtreme m_intermediateHighForLowPair;

SPHXCompletedSwing m_lastCompletedSwing;
   //--------------------------------------------------
   // Adaptive Structure Metrics
   //--------------------------------------------------

   double m_avgRange;
   double m_typicalSwing;
   double m_structureReversalRangeRatio;
   //--------------------------------------------------
   // Completed Swing Bootstrap
   //--------------------------------------------------

   int    m_completedSwingCount;
   double m_completedSwingAmplitudeSum;
   int    m_typicalSwingBootstrapCount;
   double m_typicalSwingAlpha;

   //--------------------------------------------------
   // Readiness
   //--------------------------------------------------

   bool m_avgRangeReady;
   bool m_priceStructureReady;
   bool m_typicalSwingReady;

public:

   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------

   CPHXPriceStructure();

   //--------------------------------------------------
   // Reset
   //--------------------------------------------------

   void Reset();
//--------------------------------------------------
// Closed Bar Processing
//--------------------------------------------------

bool ProcessClosedBar(
   const int bar,
   const MqlRates &rate
);
   //--------------------------------------------------
   // State
   //--------------------------------------------------

   ENUM_PHX_PRICE_STRUCTURE_STATE GetState() const;

//--------------------------------------------------
// Current Candidate
//--------------------------------------------------

bool SetCandidateHigh(
   const int bar,
   const datetime time,
   const double price
);

bool SetCandidateLow(
   const int bar,
   const datetime time,
   const double price
);

bool UpdateCandidateReversal(
   const datetime currentTime,
   const double currentHigh,
   const double currentLow
);

bool ConfirmCandidate(
   const int confirmationBar
);

SPHXPriceExtreme GetCandidate() const;
//--------------------------------------------------
// Initial Structure Candidates
//--------------------------------------------------

bool UpdateInitialCandidates(
   const int bar,
   const datetime time,
   const double high,
   const double low
);
bool UpdateInitialCandidateReversals(
   const datetime currentTime,
   const double currentHigh,
   const double currentLow
);
   //--------------------------------------------------
   // Confirmed Extremes
   //--------------------------------------------------

   SPHXPriceExtreme GetPreviousConfirmedHigh() const;
   SPHXPriceExtreme GetLastConfirmedHigh() const;

   SPHXPriceExtreme GetPreviousConfirmedLow() const;
   SPHXPriceExtreme GetLastConfirmedLow() const;
   
   SPHXPriceExtreme GetIntermediateLowForHighPair() const;
   SPHXPriceExtreme GetIntermediateHighForLowPair() const;

   //--------------------------------------------------
   // Completed Swing
   //--------------------------------------------------

   SPHXCompletedSwing GetLastCompletedSwing() const;
   
   
   //--------------------------------------------------
   // Adaptive Structure Metrics
   //--------------------------------------------------

   bool CalculateAvgRange(
   const MqlRates &rates[],
   const int count
); 
   bool SetAvgRange(
      const double value
   );
   double GetAvgRange() const;
   double GetTypicalSwing() const;
   
   bool SetStructureReversalRangeRatio(
   const double value
);

   double GetStructureReversalRangeRatio() const;
   
   bool SetTypicalSwingBootstrapCount(
   const int value
);

   int GetTypicalSwingBootstrapCount() const;
   
   bool SetTypicalSwingAlpha(
   const double value
);

   double GetTypicalSwingAlpha() const;

   //--------------------------------------------------
   // Readiness
   //--------------------------------------------------

   bool IsAvgRangeReady() const;
   bool IsPriceStructureReady() const;
   bool IsTypicalSwingReady() const;
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXPriceStructure::CPHXPriceStructure()
{
   Reset();
}

//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXPriceStructure::Reset()
{
   //--------------------------------------------------
   // State
   //--------------------------------------------------

   m_state = PHX_PRICE_STRUCTURE_UNINITIALIZED;

   //--------------------------------------------------
   // Current Candidate
   //--------------------------------------------------

   m_candidate.Reset();
   //--------------------------------------------------
   // Initial Structure Candidates
   //--------------------------------------------------

   m_initialHighCandidate.Reset();
   m_initialLowCandidate.Reset();

   //--------------------------------------------------
   // Confirmed Extremes
   //--------------------------------------------------

   m_previousConfirmedHigh.Reset();
   m_lastConfirmedHigh.Reset();

   m_previousConfirmedLow.Reset();
m_lastConfirmedLow.Reset();

m_intermediateLowForHighPair.Reset();
m_intermediateHighForLowPair.Reset();

m_lastCompletedSwing.Reset();
   //--------------------------------------------------
   // Adaptive Structure Metrics
   //--------------------------------------------------

   m_avgRange     = 0.0;
   m_typicalSwing = 0.0;
   m_structureReversalRangeRatio = 1.0;
   //--------------------------------------------------
   // Completed Swing Bootstrap
   //--------------------------------------------------

   m_completedSwingCount        = 0;
   m_completedSwingAmplitudeSum = 0.0;
   m_typicalSwingBootstrapCount = 3;
   m_typicalSwingAlpha = 0.20;
   //--------------------------------------------------
   // Readiness
   //--------------------------------------------------

   m_avgRangeReady        = false;
   m_priceStructureReady  = false;
   m_typicalSwingReady    = false;
}
//+------------------------------------------------------------------+
//| Process Closed Bar                                               |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::ProcessClosedBar(
   const int bar,
   const MqlRates &rate
)
{
   //--------------------------------------------------
   // Validation
   //--------------------------------------------------

   if(bar < 0)
      return false;

   if(rate.time <= 0)
      return false;

   if(rate.high <= 0.0 || rate.low <= 0.0)
      return false;

   if(rate.high < rate.low)
      return false;

   //--------------------------------------------------
   // Uninitialized Structure
   //--------------------------------------------------

  if(m_state == PHX_PRICE_STRUCTURE_UNINITIALIZED)
{
   //--------------------------------------------------
   // Update Initial High / Low Candidates
   //--------------------------------------------------

   if(
      !UpdateInitialCandidates(
         bar,
         rate.time,
         rate.high,
         rate.low
      )
   )
   {
      return false;
   }

   //--------------------------------------------------
   // Measure Reversal From Initial Candidates
   //--------------------------------------------------

   if(
      !UpdateInitialCandidateReversals(
         rate.time,
         rate.high,
         rate.low
      )
   )
   {
      return false;
   }

   //--------------------------------------------------
   // Check Initial High Confirmation
   //--------------------------------------------------

   bool highReady =
      (
         m_initialHighCandidate.Type ==
            PHX_EXTREMUM_HIGH &&
         m_avgRangeReady &&
         m_structureReversalRangeRatio > 0.0 &&
         m_initialHighCandidate.ReversalRangeRatio >=
            m_structureReversalRangeRatio &&
         rate.time >
            m_initialHighCandidate.ExtremeTime
      );

   //--------------------------------------------------
   // Check Initial Low Confirmation
   //--------------------------------------------------

   bool lowReady =
      (
         m_initialLowCandidate.Type ==
            PHX_EXTREMUM_LOW &&
         m_avgRangeReady &&
         m_structureReversalRangeRatio > 0.0 &&
         m_initialLowCandidate.ReversalRangeRatio >=
            m_structureReversalRangeRatio &&
         rate.time >
            m_initialLowCandidate.ExtremeTime
      );

   //--------------------------------------------------
   // No Confirmed Initial Extreme Yet
   //--------------------------------------------------

   if(!highReady && !lowReady)
      return true;

   //--------------------------------------------------
   // Both Became Ready On Same Closed Bar
   //
   // OHLC does not tell us the intrabar order.
   // Use only the candidate whose extreme occurred
   // earlier in the closed-bar sequence.
   //--------------------------------------------------

   if(highReady && lowReady)
   {
      if(
         m_initialHighCandidate.ExtremeTime ==
         m_initialLowCandidate.ExtremeTime
      )
      {
         //--------------------------------------------------
         // Ambiguous same-bar origin.
         // Do not invent market chronology.
         //--------------------------------------------------

         return true;
      }

      if(
         m_initialHighCandidate.ExtremeTime <
         m_initialLowCandidate.ExtremeTime
      )
      {
         lowReady = false;
      }
      else
      {
         highReady = false;
      }
   }

   //--------------------------------------------------
   // Confirm Initial High
   //--------------------------------------------------

   if(highReady)
   {
      m_initialHighCandidate.ConfirmationBar =
         bar;

      m_lastConfirmedHigh =
         m_initialHighCandidate;

      m_state =
         PHX_PRICE_STRUCTURE_SEARCH_LOW;

      //--------------------------------------------------
      // Initial bootstrap candidates are no longer used
      //--------------------------------------------------

      m_initialHighCandidate.Reset();
      m_initialLowCandidate.Reset();
      m_candidate.Reset();

      return true;
   }

   //--------------------------------------------------
   // Confirm Initial Low
   //--------------------------------------------------

   if(lowReady)
   {
      m_initialLowCandidate.ConfirmationBar =
         bar;

      m_lastConfirmedLow =
         m_initialLowCandidate;

      m_state =
         PHX_PRICE_STRUCTURE_SEARCH_HIGH;

      //--------------------------------------------------
      // Initial bootstrap candidates are no longer used
      //--------------------------------------------------

      m_initialHighCandidate.Reset();
      m_initialLowCandidate.Reset();
      m_candidate.Reset();

      return true;
   }

   return true;
}

   //--------------------------------------------------
   // Search High
   //--------------------------------------------------

   if(m_state == PHX_PRICE_STRUCTURE_SEARCH_HIGH)
{
   //--------------------------------------------------
   // Update High Candidate First
   //--------------------------------------------------

   SetCandidateHigh(
      bar,
      rate.time,
      rate.high
   );

   //--------------------------------------------------
   // Measure Reversal From Current Candidate
   //--------------------------------------------------

   if(
      !UpdateCandidateReversal(
         rate.time,
         rate.high,
         rate.low
      )
   )
   {
      return false;
   }

   //--------------------------------------------------
   // Confirm High Candidate
   //--------------------------------------------------

   if(
      m_candidate.Type == PHX_EXTREMUM_HIGH &&
      m_avgRangeReady &&
      m_structureReversalRangeRatio > 0.0 &&
      m_candidate.ReversalRangeRatio >=
         m_structureReversalRangeRatio
   )
   {
      return ConfirmCandidate(
         bar
      );
   }

   return true;
}
      //--------------------------------------------------
      // Search Low
      //--------------------------------------------------
if(m_state == PHX_PRICE_STRUCTURE_SEARCH_LOW)
{
   //--------------------------------------------------
   // Update Low Candidate First
   //--------------------------------------------------

   SetCandidateLow(
      bar,
      rate.time,
      rate.low
   );

   //--------------------------------------------------
   // Measure Reversal From Current Candidate
   //--------------------------------------------------

   if(
      !UpdateCandidateReversal(
         rate.time,
         rate.high,
         rate.low
      )
   )
   {
      return false;
   }

   //--------------------------------------------------
   // Confirm Low Candidate
   //--------------------------------------------------

   if(
      m_candidate.Type == PHX_EXTREMUM_LOW &&
      m_avgRangeReady &&
      m_structureReversalRangeRatio > 0.0 &&
      m_candidate.ReversalRangeRatio >=
         m_structureReversalRangeRatio
   )
   {
      return ConfirmCandidate(
         bar
      );
   }

   return true;
}

   //--------------------------------------------------
   // Unknown State
   //--------------------------------------------------

   return false;
}
//+------------------------------------------------------------------+
//| Get State                                                        |
//+------------------------------------------------------------------+
ENUM_PHX_PRICE_STRUCTURE_STATE
CPHXPriceStructure::GetState() const
{
   return m_state;
}
//+------------------------------------------------------------------+
//| Set Candidate High                                               |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::SetCandidateHigh(
   const int bar,
   const datetime time,
   const double price
)
{
   //--------------------------------------------------
   // Validation
   //--------------------------------------------------

   if(bar < 0 || time <= 0 || price <= 0.0)
      return false;

   //--------------------------------------------------
   // Existing High Candidate
   //--------------------------------------------------

   if(m_candidate.Type == PHX_EXTREMUM_HIGH)
   {
      if(price <= m_candidate.ExtremePrice)
         return false;
   }

   //--------------------------------------------------
   // Set / Move Candidate
   //--------------------------------------------------

   m_candidate.Reset();

   m_candidate.Type         = PHX_EXTREMUM_HIGH;
   m_candidate.ExtremeBar   = bar;
   m_candidate.ExtremeTime  = time;
   m_candidate.ExtremePrice = price;

   return true;
}
//+------------------------------------------------------------------+
//| Set Candidate Low                                                |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::SetCandidateLow(
   const int bar,
   const datetime time,
   const double price
)
{
   //--------------------------------------------------
   // Validation
   //--------------------------------------------------

   if(bar < 0 || time <= 0 || price <= 0.0)
      return false;

   //--------------------------------------------------
   // Existing Low Candidate
   //--------------------------------------------------

   if(m_candidate.Type == PHX_EXTREMUM_LOW)
   {
      if(price >= m_candidate.ExtremePrice)
         return false;
   }

   //--------------------------------------------------
   // Set / Move Candidate
   //--------------------------------------------------

   m_candidate.Reset();

   m_candidate.Type         = PHX_EXTREMUM_LOW;
   m_candidate.ExtremeBar   = bar;
   m_candidate.ExtremeTime  = time;
   m_candidate.ExtremePrice = price;

   return true;
}
//+------------------------------------------------------------------+
//| Update Candidate Reversal                                        |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::UpdateCandidateReversal(
   const datetime currentTime,
   const double currentHigh,
   const double currentLow
)
{
   //--------------------------------------------------
   // Validation
   //--------------------------------------------------

   if(currentHigh <= 0.0 || currentLow <= 0.0)
      return false;

   if(currentHigh < currentLow)
      return false;

   if(m_candidate.Type == PHX_EXTREMUM_NONE)
      return false;
   
   //--------------------------------------------------
   // Reversal Must Occur After Extreme Bar
   //--------------------------------------------------

   if(currentTime <= m_candidate.ExtremeTime)
{
   m_candidate.ReversalAmplitude  = 0.0;
   m_candidate.ReversalRangeRatio = 0.0;
   m_candidate.ReversalSwingRatio = 0.0;

   return true;
}

   //--------------------------------------------------
   // Reversal Amplitude
   //--------------------------------------------------

   double reversalAmplitude = 0.0;

   if(m_candidate.Type == PHX_EXTREMUM_HIGH)
   {
      reversalAmplitude =
         m_candidate.ExtremePrice -
         currentLow;
   }
   else
   if(m_candidate.Type == PHX_EXTREMUM_LOW)
   {
      reversalAmplitude =
         currentHigh -
         m_candidate.ExtremePrice;
   }

   //--------------------------------------------------
   // Protection
   //--------------------------------------------------

   if(reversalAmplitude < 0.0)
      reversalAmplitude = 0.0;

   //--------------------------------------------------
   // Store Raw Reversal
   //--------------------------------------------------

   m_candidate.ReversalAmplitude =
      reversalAmplitude;

   //--------------------------------------------------
   // AvgRange Normalization
   //--------------------------------------------------

   m_candidate.ReversalRangeRatio = 0.0;

   if(
      m_avgRangeReady &&
      m_avgRange > 0.0
   )
   {
      m_candidate.ReversalRangeRatio =
         reversalAmplitude /
         m_avgRange;
   }

   //--------------------------------------------------
   // TypicalSwing Normalization
   //--------------------------------------------------

   m_candidate.ReversalSwingRatio = 0.0;

   if(
      m_typicalSwingReady &&
      m_typicalSwing > 0.0
   )
   {
      m_candidate.ReversalSwingRatio =
         reversalAmplitude /
         m_typicalSwing;
   }

   return true;
}
//+------------------------------------------------------------------+
//| Confirm Candidate                                                |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::ConfirmCandidate(
   const int confirmationBar
)
{
   //--------------------------------------------------
   // Validation
   //--------------------------------------------------

   if(confirmationBar < 0)
      return false;

   if(m_candidate.Type == PHX_EXTREMUM_NONE)
      return false;

   //--------------------------------------------------
   // Preserve Previous Opposite Extreme
   //--------------------------------------------------

   SPHXPriceExtreme previousOpposite;
   previousOpposite.Reset();

   if(m_candidate.Type == PHX_EXTREMUM_HIGH)
   {
      previousOpposite =
         m_lastConfirmedLow;
   }
   else
   if(m_candidate.Type == PHX_EXTREMUM_LOW)
   {
      previousOpposite =
         m_lastConfirmedHigh;
   }
   else
   {
      return false;
   }

   //--------------------------------------------------
   // Confirm High
   //--------------------------------------------------

   if(m_candidate.Type == PHX_EXTREMUM_HIGH)
   {
      m_candidate.ConfirmationBar =
         confirmationBar;
//--------------------------------------------------
// Preserve Previous Confirmed High
//--------------------------------------------------

if(
   m_lastConfirmedHigh.Type ==
      PHX_EXTREMUM_HIGH
)
{
   m_previousConfirmedHigh =
      m_lastConfirmedHigh;

   //--------------------------------------------------
   // Preserve Low Between Previous And New High
   //
   // H1 -> L1 -> H2
   //--------------------------------------------------

   if(
      m_lastConfirmedLow.Type ==
         PHX_EXTREMUM_LOW &&
      m_lastConfirmedLow.ExtremeTime >
         m_previousConfirmedHigh.ExtremeTime &&
      m_lastConfirmedLow.ExtremeTime <
         m_candidate.ExtremeTime
   )
   {
      m_intermediateLowForHighPair =
         m_lastConfirmedLow;
   }
   else
   {
      m_intermediateLowForHighPair.Reset();
   }
}

//--------------------------------------------------
// Store New Confirmed High
//--------------------------------------------------

m_lastConfirmedHigh =
   m_candidate;
      m_state =
         PHX_PRICE_STRUCTURE_SEARCH_LOW;
   }

   //--------------------------------------------------
   // Confirm Low
   //--------------------------------------------------

   else
   if(m_candidate.Type == PHX_EXTREMUM_LOW)
   {
      m_candidate.ConfirmationBar =
         confirmationBar;

 //--------------------------------------------------
// Preserve Previous Confirmed Low
//--------------------------------------------------

if(
   m_lastConfirmedLow.Type ==
      PHX_EXTREMUM_LOW
)
{
   m_previousConfirmedLow =
      m_lastConfirmedLow;

   //--------------------------------------------------
   // Preserve High Between Previous And New Low
   //
   // L1 -> H1 -> L2
   //--------------------------------------------------

   if(
      m_lastConfirmedHigh.Type ==
         PHX_EXTREMUM_HIGH &&
      m_lastConfirmedHigh.ExtremeTime >
         m_previousConfirmedLow.ExtremeTime &&
      m_lastConfirmedHigh.ExtremeTime <
         m_candidate.ExtremeTime
   )
   {
      m_intermediateHighForLowPair =
         m_lastConfirmedHigh;
   }
   else
   {
      m_intermediateHighForLowPair.Reset();
   }
}

//--------------------------------------------------
// Store New Confirmed Low
//--------------------------------------------------

m_lastConfirmedLow =
   m_candidate;

      m_state =
         PHX_PRICE_STRUCTURE_SEARCH_HIGH;
   }

   //--------------------------------------------------
   // Completed Swing
   //--------------------------------------------------

   if(previousOpposite.Type != PHX_EXTREMUM_NONE)
   {
      m_lastCompletedSwing.Reset();

      m_lastCompletedSwing.StartType =
         previousOpposite.Type;

      m_lastCompletedSwing.EndType =
         m_candidate.Type;

      m_lastCompletedSwing.StartBar =
         previousOpposite.ExtremeBar;

      m_lastCompletedSwing.EndBar =
         m_candidate.ExtremeBar;

      m_lastCompletedSwing.StartTime =
         previousOpposite.ExtremeTime;

      m_lastCompletedSwing.EndTime =
         m_candidate.ExtremeTime;

      m_lastCompletedSwing.StartPrice =
         previousOpposite.ExtremePrice;

      m_lastCompletedSwing.EndPrice =
         m_candidate.ExtremePrice;

      //--------------------------------------------------
      // Swing Amplitude
      //--------------------------------------------------

      m_lastCompletedSwing.Amplitude =
         MathAbs(
            m_lastCompletedSwing.EndPrice -
            m_lastCompletedSwing.StartPrice
         );
      //--------------------------------------------------
      // Completed Swing Bootstrap
      //--------------------------------------------------
   if(m_lastCompletedSwing.Amplitude > 0.0)
{
   //--------------------------------------------------
   // Accumulate Completed Swing
   //--------------------------------------------------

   m_completedSwingCount++;

   m_completedSwingAmplitudeSum +=
      m_lastCompletedSwing.Amplitude;

   //--------------------------------------------------
   // Bootstrap Typical Swing
   //
   // TypicalSwing is created only from real
   // completed structural swings.
   //--------------------------------------------------

   //--------------------------------------------------
// Bootstrap Typical Swing
//--------------------------------------------------

if(
   !m_typicalSwingReady &&
   m_typicalSwingBootstrapCount > 0 &&
   m_completedSwingCount >=
      m_typicalSwingBootstrapCount
)
{
   m_typicalSwing =
      m_completedSwingAmplitudeSum /
      (double)m_completedSwingCount;

   m_typicalSwingReady =
      (m_typicalSwing > 0.0);
}
//--------------------------------------------------
// Adaptive Typical Swing
//--------------------------------------------------
else
if(
   m_typicalSwingReady &&
   m_typicalSwingAlpha > 0.0 &&
   m_typicalSwingAlpha <= 1.0
)
{
   m_typicalSwing =
      m_typicalSwingAlpha *
      m_lastCompletedSwing.Amplitude +
      (1.0 - m_typicalSwingAlpha) *
      m_typicalSwing;
}
}
      //--------------------------------------------------
      // Swing Duration
      //--------------------------------------------------

      m_lastCompletedSwing.DurationBars =
         MathAbs(
            m_lastCompletedSwing.EndBar -
            m_lastCompletedSwing.StartBar
         );

      //--------------------------------------------------
      // AvgRange Normalization
      //--------------------------------------------------

      m_lastCompletedSwing.AmplitudeRangeRatio =
         0.0;

      if(
         m_avgRangeReady &&
         m_avgRange > 0.0
      )
      {
         m_lastCompletedSwing.AmplitudeRangeRatio =
            m_lastCompletedSwing.Amplitude /
            m_avgRange;
      }

      //--------------------------------------------------
      // TypicalSwing Normalization
      //--------------------------------------------------

      m_lastCompletedSwing.AmplitudeSwingRatio =
         0.0;

      if(
         m_typicalSwingReady &&
         m_typicalSwing > 0.0
      )
      {
         m_lastCompletedSwing.AmplitudeSwingRatio =
            m_lastCompletedSwing.Amplitude /
            m_typicalSwing;
      }
   }

   //--------------------------------------------------
   // Structure Readiness
   //--------------------------------------------------

   if(
      m_lastConfirmedHigh.Type == PHX_EXTREMUM_HIGH &&
      m_lastConfirmedLow.Type  == PHX_EXTREMUM_LOW
   )
   {
      m_priceStructureReady = true;
   }

   //--------------------------------------------------
   // Candidate Completed
   //--------------------------------------------------

   m_candidate.Reset();

   return true;
}
//+------------------------------------------------------------------+
//| Update Initial Structure Candidates                              |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::UpdateInitialCandidates(
   const int bar,
   const datetime time,
   const double high,
   const double low
)
{

   //--------------------------------------------------
   // Validation
   //--------------------------------------------------

   if(bar < 0 || time <= 0)
      return false;

   if(high <= 0.0 || low <= 0.0)
      return false;

   if(high < low)
      return false;

   //--------------------------------------------------
   // Initial High Candidate
   //--------------------------------------------------

   if(
      m_initialHighCandidate.Type == PHX_EXTREMUM_NONE ||
      high > m_initialHighCandidate.ExtremePrice
   )
   {
      m_initialHighCandidate.Reset();

      m_initialHighCandidate.Type =
         PHX_EXTREMUM_HIGH;

      m_initialHighCandidate.ExtremeBar =
         bar;

      m_initialHighCandidate.ExtremeTime =
         time;

      m_initialHighCandidate.ExtremePrice =
         high;
   }

   //--------------------------------------------------
   // Initial Low Candidate
   //--------------------------------------------------

   if(
      m_initialLowCandidate.Type == PHX_EXTREMUM_NONE ||
      low < m_initialLowCandidate.ExtremePrice
   )
   {
      m_initialLowCandidate.Reset();

      m_initialLowCandidate.Type =
         PHX_EXTREMUM_LOW;

      m_initialLowCandidate.ExtremeBar =
         bar;

      m_initialLowCandidate.ExtremeTime =
         time;

      m_initialLowCandidate.ExtremePrice =
         low;
   }

   return true;
}
//+------------------------------------------------------------------+
//| Update Initial Candidate Reversals                               |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::UpdateInitialCandidateReversals(
   const datetime currentTime,
   const double currentHigh,
   const double currentLow
)
{
   //--------------------------------------------------
   // Validation
   //--------------------------------------------------

   if(currentHigh <= 0.0 || currentLow <= 0.0)
      return false;

   if(currentHigh < currentLow)
      return false;

   //--------------------------------------------------
   // Initial High Candidate Reversal
   //--------------------------------------------------

   if(m_initialHighCandidate.Type == PHX_EXTREMUM_HIGH)
{
   double reversalAmplitude = 0.0;

   if(currentTime > m_initialHighCandidate.ExtremeTime)
   {
      reversalAmplitude =
         m_initialHighCandidate.ExtremePrice -
         currentLow;
   }

      if(reversalAmplitude < 0.0)
         reversalAmplitude = 0.0;

      m_initialHighCandidate.ReversalAmplitude =
         reversalAmplitude;

      m_initialHighCandidate.ReversalRangeRatio =
         0.0;

      if(
         m_avgRangeReady &&
         m_avgRange > 0.0
      )
      {
         m_initialHighCandidate.ReversalRangeRatio =
            reversalAmplitude /
            m_avgRange;
      }

      m_initialHighCandidate.ReversalSwingRatio =
         0.0;

      if(
         m_typicalSwingReady &&
         m_typicalSwing > 0.0
      )
      {
         m_initialHighCandidate.ReversalSwingRatio =
            reversalAmplitude /
            m_typicalSwing;
      }
   }

   //--------------------------------------------------
   // Initial Low Candidate Reversal
   //--------------------------------------------------

   if(m_initialLowCandidate.Type == PHX_EXTREMUM_LOW)
{
   double reversalAmplitude = 0.0;

   if(currentTime > m_initialLowCandidate.ExtremeTime)
   {
      reversalAmplitude =
         currentHigh -
         m_initialLowCandidate.ExtremePrice;
   }

      if(reversalAmplitude < 0.0)
         reversalAmplitude = 0.0;

      m_initialLowCandidate.ReversalAmplitude =
         reversalAmplitude;

      m_initialLowCandidate.ReversalRangeRatio =
         0.0;

      if(
         m_avgRangeReady &&
         m_avgRange > 0.0
      )
      {
         m_initialLowCandidate.ReversalRangeRatio =
            reversalAmplitude /
            m_avgRange;
      }

      m_initialLowCandidate.ReversalSwingRatio =
         0.0;

      if(
         m_typicalSwingReady &&
         m_typicalSwing > 0.0
      )
      {
         m_initialLowCandidate.ReversalSwingRatio =
            reversalAmplitude /
            m_typicalSwing;
      }
   }

   return true;
}

//+------------------------------------------------------------------+
//| Get Candidate                                                    |
//+------------------------------------------------------------------+
SPHXPriceExtreme
CPHXPriceStructure::GetCandidate() const
{
   return m_candidate;
}
//+------------------------------------------------------------------+
//| Get Previous Confirmed High                                      |
//+------------------------------------------------------------------+
SPHXPriceExtreme CPHXPriceStructure::GetPreviousConfirmedHigh() const
{
   return m_previousConfirmedHigh;
}
//+------------------------------------------------------------------+
//| Get Last Confirmed High                                          |
//+------------------------------------------------------------------+
SPHXPriceExtreme
CPHXPriceStructure::GetLastConfirmedHigh() const
{
   return m_lastConfirmedHigh;
}
//+------------------------------------------------------------------+
//| Get Previous Confirmed Low                                       |
//+------------------------------------------------------------------+
SPHXPriceExtreme CPHXPriceStructure::GetPreviousConfirmedLow() const
{
   return m_previousConfirmedLow;
}
//+------------------------------------------------------------------+
//| Get Last Confirmed Low                                           |
//+------------------------------------------------------------------+
SPHXPriceExtreme
CPHXPriceStructure::GetLastConfirmedLow() const
{
   return m_lastConfirmedLow;
}
//+------------------------------------------------------------------+
//| Get Intermediate Low For High Pair                               |
//+------------------------------------------------------------------+
SPHXPriceExtreme CPHXPriceStructure::GetIntermediateLowForHighPair() const
{
   return m_intermediateLowForHighPair;
}

//+------------------------------------------------------------------+
//| Get Intermediate High For Low Pair                               |
//+------------------------------------------------------------------+
SPHXPriceExtreme CPHXPriceStructure::GetIntermediateHighForLowPair() const
{
   return m_intermediateHighForLowPair;
}

//+------------------------------------------------------------------+
//| Get Last Completed Swing                                         |
//+------------------------------------------------------------------+
SPHXCompletedSwing
CPHXPriceStructure::GetLastCompletedSwing() const
{
   return m_lastCompletedSwing;
}
//+------------------------------------------------------------------+
//| Calculate Average Range                                          |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::CalculateAvgRange(
   const MqlRates &rates[],
   const int count
)
{
   //--------------------------------------------------
   // Validation
   //--------------------------------------------------

   if(count <= 0)
   {
      m_avgRange      = 0.0;
      m_avgRangeReady = false;

      return false;
   }

   int available =
      ArraySize(rates);

   if(available <= 0)
   {
      m_avgRange      = 0.0;
      m_avgRangeReady = false;

      return false;
   }

   int barsToUse =
      MathMin(
         count,
         available
      );

   //--------------------------------------------------
   // Range Accumulation
   //--------------------------------------------------

   double rangeSum = 0.0;
   int    validBars = 0;

   for(int i = 0; i < barsToUse; i++)
   {
      double range =
         rates[i].high -
         rates[i].low;

      if(range <= 0.0)
         continue;

      rangeSum += range;
      validBars++;
   }

   //--------------------------------------------------
   // Result
   //--------------------------------------------------

   if(validBars <= 0)
   {
      m_avgRange      = 0.0;
      m_avgRangeReady = false;

      return false;
   }

   m_avgRange =
      rangeSum /
      (double)validBars;

   m_avgRangeReady =
      (m_avgRange > 0.0);

   return m_avgRangeReady;
}
//+------------------------------------------------------------------+
//| Set Average Range                                                |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::SetAvgRange(
   const double value
)
{
   //---------------------------------------------------------------
   // Validation
   //---------------------------------------------------------------

   if(value <= 0.0)
   {
      m_avgRange =
         0.0;

      m_avgRangeReady =
         false;

      return false;
   }

   //---------------------------------------------------------------
   // Store Causal Rolling Value
   //---------------------------------------------------------------

   m_avgRange =
      value;

   m_avgRangeReady =
      true;

   return true;
}
//+------------------------------------------------------------------+
//| Set Structure Reversal Range Ratio                               |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::SetStructureReversalRangeRatio(
   const double value
)
{
   if(value <= 0.0)
      return false;

   m_structureReversalRangeRatio =
      value;

   return true;
}

//+------------------------------------------------------------------+
//| Get Structure Reversal Range Ratio                               |
//+------------------------------------------------------------------+
double CPHXPriceStructure::GetStructureReversalRangeRatio() const
{
   return m_structureReversalRangeRatio;
}
//+------------------------------------------------------------------+
//| Set Typical Swing Bootstrap Count                                |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::SetTypicalSwingBootstrapCount(
   const int value
)
{
   if(value <= 0)
      return false;

   m_typicalSwingBootstrapCount =
      value;

   return true;
}

//+------------------------------------------------------------------+
//| Get Typical Swing Bootstrap Count                                |
//+------------------------------------------------------------------+
int CPHXPriceStructure::GetTypicalSwingBootstrapCount() const
{
   return m_typicalSwingBootstrapCount;
}
//+------------------------------------------------------------------+
//| Set Typical Swing Alpha                                          |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::SetTypicalSwingAlpha(
   const double value
)
{
   if(value <= 0.0 || value > 1.0)
      return false;

   m_typicalSwingAlpha =
      value;

   return true;
}

//+------------------------------------------------------------------+
//| Get Typical Swing Alpha                                          |
//+------------------------------------------------------------------+
double CPHXPriceStructure::GetTypicalSwingAlpha() const
{
   return m_typicalSwingAlpha;
}
//+------------------------------------------------------------------+
//| Get Average Range                                                |
//+------------------------------------------------------------------+
double CPHXPriceStructure::GetAvgRange() const
{
   return m_avgRange;
}

//+------------------------------------------------------------------+
//| Get Typical Swing                                                |
//+------------------------------------------------------------------+
double CPHXPriceStructure::GetTypicalSwing() const
{
   return m_typicalSwing;
}

//+------------------------------------------------------------------+
//| Is Average Range Ready                                           |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::IsAvgRangeReady() const
{
   return m_avgRangeReady;
}

//+------------------------------------------------------------------+
//| Is Price Structure Ready                                         |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::IsPriceStructureReady() const
{
   return m_priceStructureReady;
}

//+------------------------------------------------------------------+
//| Is Typical Swing Ready                                           |
//+------------------------------------------------------------------+
bool CPHXPriceStructure::IsTypicalSwingReady() const
{
   return m_typicalSwingReady;
}

#endif // __PHX_PRICE_STRUCTURE_MQH__