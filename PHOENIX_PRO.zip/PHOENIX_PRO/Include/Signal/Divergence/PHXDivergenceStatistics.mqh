//+------------------------------------------------------------------+
//| PHXDivergenceStatistics.mqh                                      |
//| PHOENIX PRO Research Layer                                      |
//| Divergence Pipeline Statistics                                  |
//+------------------------------------------------------------------+

#ifndef PHX_DIVERGENCE_STATISTICS_MQH
#define PHX_DIVERGENCE_STATISTICS_MQH


//+------------------------------------------------------------------+
//| Divergence Statistics                                            |
//+------------------------------------------------------------------+
class CPHXDivergenceStatistics
{

private:

   //--------------------------------------------------
   // Price Structure
   //--------------------------------------------------

   int m_priceHighCount;
   int m_priceLowCount;


   //--------------------------------------------------
   // PPO Structure
   //--------------------------------------------------

   int m_ppoHighCount;
   int m_ppoLowCount;


   //--------------------------------------------------
   // Matcher
   //--------------------------------------------------

   int m_matchAccepted;
   int m_matchRejected;


   //--------------------------------------------------
   // Detector
   //--------------------------------------------------

   int m_candidates;


   //--------------------------------------------------
   // Lifecycle
   //--------------------------------------------------

   int m_detected;
   int m_waiting;

   int m_confirmed;

   int m_invalidated;

   int m_superseded;


public:

   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------

   CPHXDivergenceStatistics()
   {
      Reset();
   }


   //--------------------------------------------------
   // Reset
   //--------------------------------------------------

   void Reset()
   {

      m_priceHighCount = 0;
      m_priceLowCount  = 0;


      m_ppoHighCount = 0;
      m_ppoLowCount  = 0;


      m_matchAccepted = 0;
      m_matchRejected = 0;


      m_candidates = 0;


      m_detected = 0;
      m_waiting  = 0;

      m_confirmed  = 0;

      m_invalidated = 0;

      m_superseded = 0;

   }


   //--------------------------------------------------
   // Price Structure
   //--------------------------------------------------

   void AddPriceHigh()
   {
      m_priceHighCount++;
   }


   void AddPriceLow()
   {
      m_priceLowCount++;
   }


   //--------------------------------------------------
   // PPO Structure
   //--------------------------------------------------

   void AddPPOHigh()
   {
      m_ppoHighCount++;
   }


   void AddPPOLow()
   {
      m_ppoLowCount++;
   }


   //--------------------------------------------------
   // Matcher
   //--------------------------------------------------

   void AddMatchAccepted()
   {
      m_matchAccepted++;
   }


   void AddMatchRejected()
   {
      m_matchRejected++;
   }


   //--------------------------------------------------
   // Detector
   //--------------------------------------------------

   void AddCandidate()
   {
      m_candidates++;
   }


   //--------------------------------------------------
   // Lifecycle
   //--------------------------------------------------

   void AddDetected()
   {
      m_detected++;
   }


   void AddWaiting()
   {
      m_waiting++;
   }


   void AddConfirmed()
   {
      m_confirmed++;
   }


   void AddInvalidated()
   {
      m_invalidated++;
   }


   void AddSuperseded()
   {
      m_superseded++;
   }


   //--------------------------------------------------
   // Report
   //--------------------------------------------------

   void PrintReport()
   {

      Print(
         "=========================================="
      );

      Print(
         "PHX DIVERGENCE STATISTICS REPORT"
      );


      Print(
         "PRICE STRUCTURE: ",
         "High=",
         IntegerToString(
            m_priceHighCount
         ),
         " Low=",
         IntegerToString(
            m_priceLowCount
         )
      );


      Print(
         "PPO STRUCTURE: ",
         "High=",
         IntegerToString(
            m_ppoHighCount
         ),
         " Low=",
         IntegerToString(
            m_ppoLowCount
         )
      );


      Print(
         "MATCHER: ",
         "Accepted=",
         IntegerToString(
            m_matchAccepted
         ),
         " Rejected=",
         IntegerToString(
            m_matchRejected
         )
      );


      Print(
         "DETECTOR: ",
         "Candidates=",
         IntegerToString(
            m_candidates
         )
      );


      Print(
         "LIFECYCLE: ",
         "Detected=",
         IntegerToString(
            m_detected
         ),
         " Waiting=",
         IntegerToString(
            m_waiting
         ),
         " Confirmed=",
         IntegerToString(
            m_confirmed
         ),
         " Invalidated=",
         IntegerToString(
            m_invalidated
         ),
         " Superseded=",
         IntegerToString(
            m_superseded
         )
      );


      Print(
         "=========================================="
      );

   }

};


#endif