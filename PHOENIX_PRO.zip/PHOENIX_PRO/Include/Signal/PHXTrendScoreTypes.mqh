#ifndef PHX_TREND_SCORE_TYPES_MQH
#define PHX_TREND_SCORE_TYPES_MQH

//+------------------------------------------------------------------+
//| ADX Score                                                        |
//+------------------------------------------------------------------+
struct SPHXADXScore
{
   int Strength;
   int Direction;
   int TrendQuality;
   int Total;
   void Reset()
   {
      Strength    = 0;
      Direction   = 0;
      TrendQuality = 0;
      Total       = 0;
   }
};
//+------------------------------------------------------------------+
//| EMA Score                                                        |
//+------------------------------------------------------------------+
struct SPHXEMAScore
{
   int Fan;
   int Slope;
   int Distance;
   int Compression;
   int Total;
   void Reset()
   {
      Fan         = 0;
      Slope       = 0;
      Distance    = 0;
      Compression = 0;
      Total       = 0;
   }
};

//+------------------------------------------------------------------+
//| ATR Score                                                        |
//+------------------------------------------------------------------+
struct SPHXATRScore
{
   int Energy;
   int Momentum;
   int Total;
   void Reset()
   {
      Energy   = 0;
      Momentum = 0;
      Total    = 0;
   }
};
//+------------------------------------------------------------------+
//| RSI Score                                                        |
//+------------------------------------------------------------------+
struct SPHXRSIScore
{
   int Direction;
   int Strength;
   int Total;

   void Reset()
   {
      Direction = 0;
      Strength  = 0;
      Total     = 0;
   }
};
//+------------------------------------------------------------------+
//| Volume Score                                                     |
//+------------------------------------------------------------------+
struct SPHXVolumeScore
{
   int AboveAverage;
   int Growth;
   int Total;
   void Reset()
   {
      AboveAverage = 0;
      Growth       = 0;
      Total        = 0;
   }
};
//+------------------------------------------------------------------+
//| Market Score                                                     |
//+------------------------------------------------------------------+
struct SPHXMarketScore
{
   int Spread;
   int Session;
   int Liquidity;
   int Total;
   void Reset()
   {
      Spread    = 0;
      Session   = 0;
      Liquidity = 0;

      Total     = 0;
   }
};
//+------------------------------------------------------------------+
//| Total Trend Score                                                |
//+------------------------------------------------------------------+
struct SPHXTrendScore
{
   SPHXEMAScore    EMA;
   SPHXATRScore    ATR;
   SPHXRSIScore    RSI;
   SPHXVolumeScore Volume;  
   SPHXADXScore ADX;
   SPHXMarketScore Market;
  
   int Total;
   void Reset()
   {
      EMA.Reset();
      ATR.Reset();
      RSI.Reset();
      Volume.Reset();
      Market.Reset();    
      ADX.Reset();
     
      Total = 0;
   }
};

//+------------------------------------------------------------------+
//| Trend Signal                                                     |
//+------------------------------------------------------------------+


#endif // PHX_TREND_SCORE_TYPES_MQH