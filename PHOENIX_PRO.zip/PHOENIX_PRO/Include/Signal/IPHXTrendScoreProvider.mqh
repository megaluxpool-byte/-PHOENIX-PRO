#ifndef PHX_TREND_SCORE_PROVIDER_MQH
#define PHX_TREND_SCORE_PROVIDER_MQH


#include "PHXTrendScoreTypes.mqh"
#include "../Statistics/PHXTrendStatisticsTypes.mqh"

//+------------------------------------------------------------------+
//| Trend Score Provider Interface                                   |
//+------------------------------------------------------------------+

class IPHXTrendScoreProvider
{

public:

   virtual ~IPHXTrendScoreProvider()
   {
   }


public:

   //--------------------------------------------------
   // Calculate Trend Score
   //--------------------------------------------------

   virtual bool Calculate(
      const SPHXTrendSnapshot &snapshot
   ) = 0;


   //--------------------------------------------------
   // Get Current Score
   //--------------------------------------------------

   virtual SPHXTrendScore GetScore() const = 0;


//--------------------------------------------------
// Get Current Snapshot
//--------------------------------------------------

   virtual SPHXTrendSnapshot GetSnapshot() const = 0;
   
};

#endif // PHX_TREND_SCORE_PROVIDER_MQH