#ifndef __PHX_SIGNAL_HISTORY_MQH__
#define __PHX_SIGNAL_HISTORY_MQH__


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXSignalTypes.mqh"


//--------------------------------------------------
// Constants
//--------------------------------------------------

#define PHX_SIGNAL_HISTORY_SIZE 100



//+------------------------------------------------------------------+
//| Signal History                                                   |
//+------------------------------------------------------------------+
class CPHXSignalHistory
{

private:

   //--------------------------------------------------
   // Signal buffer
   //--------------------------------------------------

   SPHXSignalRecord m_records[PHX_SIGNAL_HISTORY_SIZE];


   //--------------------------------------------------
   // Current count
   //--------------------------------------------------

   int m_count;



public:

   CPHXSignalHistory();

   ~CPHXSignalHistory();



public:

   //--------------------------------------------------
   // Reset
   //--------------------------------------------------

   void Reset();



   //--------------------------------------------------
   // Add record
   //--------------------------------------------------

   bool Add(
      const SPHXSignalRecord &record
   );



   //--------------------------------------------------
   // Get count
   //--------------------------------------------------

   int Count() const;



   //--------------------------------------------------
   // Get record
   //--------------------------------------------------

   bool Get(
      int index,
      SPHXSignalRecord &record
   ) const;


};



//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+

CPHXSignalHistory::CPHXSignalHistory()
{
   Reset();
}



//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+

CPHXSignalHistory::~CPHXSignalHistory()
{

}



//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+

void CPHXSignalHistory::Reset()
{

   m_count = 0;


   for(int i = 0; i < PHX_SIGNAL_HISTORY_SIZE; i++)
   {
      m_records[i].Reset();
   }

}



//+------------------------------------------------------------------+
//| Add                                                              |
//+------------------------------------------------------------------+

bool CPHXSignalHistory::Add(
   const SPHXSignalRecord &record
)
{

   if(m_count >= PHX_SIGNAL_HISTORY_SIZE)
      return false;


   m_records[m_count] = record;


   m_count++;


   return true;

}



//+------------------------------------------------------------------+
//| Count                                                            |
//+------------------------------------------------------------------+

int CPHXSignalHistory::Count() const
{
   return m_count;
}



//+------------------------------------------------------------------+
//| Get                                                              |
//+------------------------------------------------------------------+

bool CPHXSignalHistory::Get(
   int index,
   SPHXSignalRecord &record
) const
{

   if(index < 0 ||
      index >= m_count)
   {
      return false;
   }


   record = m_records[index];


   return true;

}



#endif // __PHX_SIGNAL_HISTORY_MQH__