#ifndef __PHX_DIVERGENCE_MATCHER_MQH__
#define __PHX_DIVERGENCE_MATCHER_MQH__

#include "PHXSignalTypes.mqh"
#include "../Indicators/PHXPPO.mqh"

//+------------------------------------------------------------------+
//| PHOENIX PRO                                                      |
//| Price Extreme <-> PPO Extreme Matcher                            |
//+------------------------------------------------------------------+
class CPHXDivergenceMatcher
{
public:

   CPHXDivergenceMatcher();

   bool FindMatch(
      CPHXPPO *ppo,
      const SPHXPriceExtreme &priceExtreme,
      const int toleranceBars,
      const int localDepthBars,
      const datetime excludedPPOTime,
      SPHXDivergenceMatch &match
   ) const;
};


//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXDivergenceMatcher::CPHXDivergenceMatcher()
{
}


//+------------------------------------------------------------------+
//| Find Price Extreme <-> PPO Extreme Match                         |
//+------------------------------------------------------------------+
bool CPHXDivergenceMatcher::FindMatch(
   CPHXPPO *ppo,
   const SPHXPriceExtreme &priceExtreme,
   const int toleranceBars,
   const int localDepthBars,
   const datetime excludedPPOTime,
   SPHXDivergenceMatch &match
) const
{
   //--------------------------------------------------
   // Reset Output
   //--------------------------------------------------

   match.Reset();

   //--------------------------------------------------
   // Validate PPO
   //--------------------------------------------------

   if(ppo == NULL)
      return false;

   if(!(*ppo).IsInitialized())
      return false;

   //--------------------------------------------------
   // Validate Price Extreme
   //--------------------------------------------------

   if(
      priceExtreme.Type != PHX_EXTREMUM_HIGH &&
      priceExtreme.Type != PHX_EXTREMUM_LOW
   )
   {
      return false;
   }

   if(priceExtreme.ExtremeTime <= 0)
      return false;

   //--------------------------------------------------
   // Validate Parameters
   //--------------------------------------------------

   if(toleranceBars < 0)
      return false;

   if(localDepthBars <= 0)
      return false;

   //--------------------------------------------------
   // Convert Price Extreme Time -> PPO Shift
   //--------------------------------------------------

   int priceShift = -1;

   if(
      !(*ppo).GetShiftByTime(
         priceExtreme.ExtremeTime,
         priceShift
      )
   )
   {
      return false;
   }

   //--------------------------------------------------
   // Candidate PPO Shift Range
   //
   // Smaller shift = newer bar
   // Larger shift  = older bar
   //--------------------------------------------------

   int newestCandidateShift =
      priceShift -
      toleranceBars;

   int minimumCandidateShift =
      1 +
      localDepthBars;

   if(
      newestCandidateShift <
      minimumCandidateShift
   )
   {
      newestCandidateShift =
         minimumCandidateShift;
   }

   int oldestCandidateShift =
      priceShift +
      toleranceBars;

   if(
      newestCandidateShift >
      oldestCandidateShift
   )
   {
      return true;
   }

   //--------------------------------------------------
   // Extend Buffer For Local Geometry
   //--------------------------------------------------

   int fetchStartShift =
      newestCandidateShift -
      localDepthBars;

   int fetchEndShift =
      oldestCandidateShift +
      localDepthBars;

   if(fetchStartShift <= 0)
      return false;

   int fetchCount =
      fetchEndShift -
      fetchStartShift +
      1;

   if(fetchCount <= 0)
      return false;

   //--------------------------------------------------
   // Read PPO Window
   //--------------------------------------------------

   double values[];

   if(
      !(*ppo).GetValues(
         fetchStartShift,
         fetchCount,
         values
      )
   )
   {
      return false;
   }

   //--------------------------------------------------
   // Best Candidate State
   //--------------------------------------------------

   bool bestFound =
      false;

   int bestShift =
      -1;

   int bestDistance =
      0;

   double bestValue =
      0.0;

   double bestProminence =
      0.0;

   datetime bestTime =
      0;

   //--------------------------------------------------
   // Search Local PPO Extremes
   //--------------------------------------------------

   for(
      int candidateShift = newestCandidateShift;
      candidateShift <= oldestCandidateShift;
      candidateShift++
   )
   {
      //------------------------------------------------
      // CopyBuffer stores oldest value first.
      //
      // fetchEndShift = oldest bar in buffer.
      //------------------------------------------------

      int index =
         fetchEndShift -
         candidateShift;

      if(
         index < 0 ||
         index >= ArraySize(values)
      )
      {
         continue;
      }

      //------------------------------------------------
      // Candidate Time
      //------------------------------------------------

      datetime candidateTime =
         iTime(
            (*ppo).GetSymbol(),
            (*ppo).GetTimeframe(),
            candidateShift
         );

      if(candidateTime <= 0)
         continue;

      //------------------------------------------------
      // Do Not Reuse Excluded PPO Extreme
      //------------------------------------------------

      if(
         excludedPPOTime > 0 &&
         candidateTime == excludedPPOTime
      )
      {
         continue;
      }

      //------------------------------------------------
      // Validate Same-Type PPO Extreme
      //------------------------------------------------

      bool isLocalExtreme =
         false;

      double prominence =
         0.0;

      if(
         priceExtreme.Type ==
         PHX_EXTREMUM_HIGH
      )
      {
         isLocalExtreme =
            (*ppo).IsLocalHigh(
               values,
               index,
               localDepthBars
            );

         if(!isLocalExtreme)
            continue;

         if(
            !(*ppo).GetHighProminence(
               values,
               index,
               localDepthBars,
               prominence
            )
         )
         {
            continue;
         }
      }
      else
      {
         isLocalExtreme =
            (*ppo).IsLocalLow(
               values,
               index,
               localDepthBars
            );

         if(!isLocalExtreme)
            continue;

         if(
            !(*ppo).GetLowProminence(
               values,
               index,
               localDepthBars,
               prominence
            )
         )
         {
            continue;
         }
      }

      //------------------------------------------------
      // Temporal Distance
      //------------------------------------------------

      int distance =
         MathAbs(
            candidateShift -
            priceShift
         );

      //------------------------------------------------
      // Primary Rule:
      // nearest PPO extreme wins
      //------------------------------------------------

      bool betterCandidate =
         false;

      if(!bestFound)
      {
         betterCandidate =
            true;
      }
      else
      if(distance < bestDistance)
      {
         betterCandidate =
            true;
      }
      else
      if(
         distance == bestDistance &&
         prominence > bestProminence
      )
      {
         //------------------------------------------------
         // Tie only:
         // stronger prominence wins
         //------------------------------------------------

         betterCandidate =
            true;
      }

      if(!betterCandidate)
         continue;

      //------------------------------------------------
      // Store Best Candidate
      //------------------------------------------------

      bestFound =
         true;

      bestShift =
         candidateShift;

      bestDistance =
         distance;

      bestValue =
         values[index];

      bestProminence =
         prominence;

      bestTime =
         candidateTime;
   }

   //--------------------------------------------------
   // No PPO Extreme Inside Allowed Window
   //--------------------------------------------------

   if(!bestFound)
      return true;

   //--------------------------------------------------
   // Build Match
   //--------------------------------------------------

   match.Price =
      priceExtreme;

   match.PPO.Reset();

   match.PPO.Type =
      priceExtreme.Type;

   match.PPO.ExtremeBar =
      bestShift;

   match.PPO.ExtremeTime =
      bestTime;

   match.PPO.Value =
      bestValue;

   match.PPO.Prominence =
      bestProminence;

   //--------------------------------------------------
   // Signed Match Offset
   //
   // PPO earlier than Price  -> negative
   // PPO later than Price    -> positive
   //--------------------------------------------------

   match.MatchOffsetBars =
      priceShift -
      bestShift;

   match.Matched =
      true;

   return true;
}

#endif