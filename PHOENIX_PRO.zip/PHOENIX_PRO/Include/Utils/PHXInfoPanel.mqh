#ifndef __PHX_INFO_PANEL_MQH__
#define __PHX_INFO_PANEL_MQH__

//--------------------------------------------------
// Canvas
//--------------------------------------------------
#include <Canvas\Canvas.mqh>

//+------------------------------------------------------------------+
//| PHOENIX PRO Info Panel                                           |
//|                                                                  |
//| Display only.                                                     |
//| No trading calculations.                                         |
//| No trading decisions.                                            |
//+------------------------------------------------------------------+
class CPHXInfoPanel
{
private:

   //--------------------------------------------------
   // State
   //--------------------------------------------------
   bool   m_initialized;
   bool   m_canvasCreated;

   string m_prefix;
   string m_canvasName;

   //--------------------------------------------------
   // Canvas
   //--------------------------------------------------
   CCanvas m_canvas;

   //--------------------------------------------------
   // Geometry
   //--------------------------------------------------
   int m_x;
   int m_y;
   int m_width;
   int m_height;

   //--------------------------------------------------
   // Object names
   //--------------------------------------------------
   string m_title;

   string m_labelD1ATR;
   string m_valueD1ATR;

   string m_labelEnergy;
   string m_valueEnergy;

   string m_labelRSI;
   string m_valueRSI;

   string m_labelADX;
   string m_valueADX;

   string m_labelTrend;
   string m_valueTrend;

   string m_labelScore;
   string m_valueScore;

   string m_labelSignal;
   string m_valueSignal;


private:

   //--------------------------------------------------
   // Canvas
   //--------------------------------------------------
   bool CreateBackground();
   void DrawBackground();

   //--------------------------------------------------
   // Create Label
   //--------------------------------------------------
   bool CreateLabel(
      string name,
      string text,
      int x,
      int y,
      int fontSize,
      color textColor
   );

   //--------------------------------------------------
   // Set Text
   //--------------------------------------------------
   void SetText(
      string name,
      string text
   );

   //--------------------------------------------------
   // Set Color
   //--------------------------------------------------
   void SetColor(
      string name,
      color textColor
   );


public:

   //--------------------------------------------------
   // Constructor / Destructor
   //--------------------------------------------------
   CPHXInfoPanel();
   ~CPHXInfoPanel();

   //--------------------------------------------------
   // Lifecycle
   //--------------------------------------------------
   bool Initialize();
   void Shutdown();

   bool IsInitialized() const;

   //--------------------------------------------------
   // Update
   //--------------------------------------------------
   void Update(
      double dailyATR,
      double energyLeftPercent,
      double rsi,
      double adx,
      string trend,
      int score,
      string signal
   );
};


//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXInfoPanel::CPHXInfoPanel()
{
   //--------------------------------------------------
   // State
   //--------------------------------------------------
   m_initialized   = false;
   m_canvasCreated = false;

   //--------------------------------------------------
   // Prefix
   //--------------------------------------------------
   m_prefix =
      "PHX_INFO_PANEL_";

   //--------------------------------------------------
   // Canvas name
   //--------------------------------------------------
   m_canvasName =
      m_prefix + "CANVAS";

   //--------------------------------------------------
   // Compact panel geometry
   //--------------------------------------------------
   m_x      = 8;
   m_y      = 12;

   m_width  = 165;
   m_height = 150;

   //--------------------------------------------------
   // Object names
   //--------------------------------------------------
   m_title =
      m_prefix + "TITLE";

   m_labelD1ATR =
      m_prefix + "LABEL_D1ATR";

   m_valueD1ATR =
      m_prefix + "VALUE_D1ATR";

   m_labelEnergy =
      m_prefix + "LABEL_ENERGY";

   m_valueEnergy =
      m_prefix + "VALUE_ENERGY";

   m_labelRSI =
      m_prefix + "LABEL_RSI";

   m_valueRSI =
      m_prefix + "VALUE_RSI";

   m_labelADX =
      m_prefix + "LABEL_ADX";

   m_valueADX =
      m_prefix + "VALUE_ADX";

   m_labelTrend =
      m_prefix + "LABEL_TREND";

   m_valueTrend =
      m_prefix + "VALUE_TREND";

   m_labelScore =
      m_prefix + "LABEL_SCORE";

   m_valueScore =
      m_prefix + "VALUE_SCORE";

   m_labelSignal =
      m_prefix + "LABEL_SIGNAL";

   m_valueSignal =
      m_prefix + "VALUE_SIGNAL";
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXInfoPanel::~CPHXInfoPanel()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Create Canvas Background                                         |
//+------------------------------------------------------------------+
bool CPHXInfoPanel::CreateBackground()
{
   //--------------------------------------------------
   // Remove stale object if it exists
   //--------------------------------------------------
   if(ObjectFind(
         0,
         m_canvasName
      ) >= 0)
   {
      ObjectDelete(
         0,
         m_canvasName
      );
   }

   //--------------------------------------------------
   // Create bitmap resource
   //
   // Initial coordinates are temporary.
   // Corner and anchor are configured immediately
   // after creation.
   //--------------------------------------------------
   if(!m_canvas.CreateBitmapLabel(
         0,
         0,
         m_canvasName,
         0,
         0,
         m_width,
         m_height,
         COLOR_FORMAT_XRGB_NOALPHA
      ))
   {
      Print(
         "PHX InfoPanel ERROR: Canvas creation failed"
      );

      return false;
   }

   m_canvasCreated = true;

   //--------------------------------------------------
   // Anchor canvas to lower-left chart corner
   //--------------------------------------------------
   ObjectSetInteger(
      0,
      m_canvasName,
      OBJPROP_CORNER,
      CORNER_LEFT_LOWER
   );

   ObjectSetInteger(
      0,
      m_canvasName,
      OBJPROP_ANCHOR,
      ANCHOR_LEFT_LOWER
   );

   //--------------------------------------------------
   // Position
   //--------------------------------------------------
   ObjectSetInteger(
      0,
      m_canvasName,
      OBJPROP_XDISTANCE,
      m_x
   );

   ObjectSetInteger(
      0,
      m_canvasName,
      OBJPROP_YDISTANCE,
      m_y
   );

   //--------------------------------------------------
   // Foreground
   //--------------------------------------------------
   ObjectSetInteger(
      0,
      m_canvasName,
      OBJPROP_BACK,
      false
   );

   //--------------------------------------------------
   // Do not allow user selection
   //--------------------------------------------------
   ObjectSetInteger(
      0,
      m_canvasName,
      OBJPROP_SELECTABLE,
      false
   );

   ObjectSetInteger(
      0,
      m_canvasName,
      OBJPROP_SELECTED,
      false
   );

   ObjectSetInteger(
      0,
      m_canvasName,
      OBJPROP_HIDDEN,
      true
   );

   //--------------------------------------------------
   // Draw solid panel
   //--------------------------------------------------
   DrawBackground();

   return true;
}


//+------------------------------------------------------------------+
//| Draw Canvas Background                                           |
//+------------------------------------------------------------------+
void CPHXInfoPanel::DrawBackground()
{
   if(!m_canvasCreated)
      return;

   //--------------------------------------------------
   // Solid dark body
   //
   // XRGB_NOALPHA:
   // panel is intentionally fully opaque.
   //--------------------------------------------------
   m_canvas.FillRectangle(
      0,
      0,
      m_width - 1,
      m_height - 1,
      ColorToARGB(
         C'18,18,18',
         255
      )
   );

   //--------------------------------------------------
   // Outer border
   //--------------------------------------------------
   m_canvas.Rectangle(
      0,
      0,
      m_width - 1,
      m_height - 1,
      ColorToARGB(
         C'75,75,75',
         255
      )
   );

   //--------------------------------------------------
   // Separator below title
   //--------------------------------------------------
   m_canvas.Line(
      10,
      25,
      m_width - 11,
      25,
      ColorToARGB(
         C'85,85,85',
         255
      )
   );

   //--------------------------------------------------
   // Separator above Signal
   //--------------------------------------------------
   m_canvas.Line(
      10,
      125,
      m_width - 11,
      125,
      ColorToARGB(
         C'85,85,85',
         255
      )
   );

   //--------------------------------------------------
   // Display
   //--------------------------------------------------
   m_canvas.Update();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXInfoPanel::Initialize()
{
   if(m_initialized)
      return true;

   //--------------------------------------------------
   // Clean possible old PHX objects
   //--------------------------------------------------
   ObjectsDeleteAll(
      0,
      m_prefix
   );

   //--------------------------------------------------
   // Canvas Background
   //--------------------------------------------------
   if(!CreateBackground())
   {
      Shutdown();
      return false;
   }

   //--------------------------------------------------
   // Title
   //--------------------------------------------------
   if(!CreateLabel(
         m_title,
         "PHOENIX PRO",
         12,
         136,
         8,
         C'255,180,0'
      ))
   {
      Shutdown();
      return false;
   }

   //--------------------------------------------------
   // D1 ATR
   //--------------------------------------------------
   if(!CreateLabel(
         m_labelD1ATR,
         "D1 ATR:",
         12,
         111,
         7,
         clrWhite
      ))
   {
      Shutdown();
      return false;
   }

   if(!CreateLabel(
         m_valueD1ATR,
         "--",
         102,
         111,
         7,
         clrWhite
      ))
   {
      Shutdown();
      return false;
   }

   //--------------------------------------------------
   // Energy Left
   //--------------------------------------------------
   if(!CreateLabel(
         m_labelEnergy,
         "Energy Left:",
         12,
         96,
         7,
         clrWhite
      ))
   {
      Shutdown();
      return false;
   }

   if(!CreateLabel(
         m_valueEnergy,
         "--",
         102,
         96,
         7,
         clrWhite
      ))
   {
      Shutdown();
      return false;
   }

   //--------------------------------------------------
   // RSI
   //--------------------------------------------------
   if(!CreateLabel(
         m_labelRSI,
         "RSI:",
         12,
         78,
         7,
         clrWhite
      ))
   {
      Shutdown();
      return false;
   }

   if(!CreateLabel(
         m_valueRSI,
         "--",
         102,
         78,
         7,
         clrWhite
      ))
   {
      Shutdown();
      return false;
   }

   //--------------------------------------------------
   // ADX
   //--------------------------------------------------
   if(!CreateLabel(
         m_labelADX,
         "ADX:",
         12,
         63,
         7,
         clrWhite
      ))
   {
      Shutdown();
      return false;
   }

   if(!CreateLabel(
         m_valueADX,
         "--",
         102,
         63,
         7,
         clrWhite
      ))
   {
      Shutdown();
      return false;
   }

   //--------------------------------------------------
   // Trend
   //--------------------------------------------------
   if(!CreateLabel(
         m_labelTrend,
         "Trend:",
         12,
         48,
         7,
         clrWhite
      ))
   {
      Shutdown();
      return false;
   }

   if(!CreateLabel(
         m_valueTrend,
         "--",
         102,
         48,
         7,
         clrSilver
      ))
   {
      Shutdown();
      return false;
   }

   //--------------------------------------------------
   // Score
   //--------------------------------------------------
   if(!CreateLabel(
         m_labelScore,
         "Score:",
         12,
         33,
         7,
         clrWhite
      ))
   {
      Shutdown();
      return false;
   }

   if(!CreateLabel(
         m_valueScore,
         "--",
         102,
         33,
         7,
         clrWhite
      ))
   {
      Shutdown();
      return false;
   }

   //--------------------------------------------------
   // Signal
   //--------------------------------------------------
   if(!CreateLabel(
         m_labelSignal,
         "Signal:",
         12,
         10,
         7,
         clrWhite
      ))
   {
      Shutdown();
      return false;
   }

   if(!CreateLabel(
         m_valueSignal,
         "NONE",
         92,
         10,
         7,
         clrSilver
      ))
   {
      Shutdown();
      return false;
   }

   //--------------------------------------------------
   // Ready
   //--------------------------------------------------
   m_initialized = true;

   ChartRedraw();

   Print(
      "PHX InfoPanel: initialized with Canvas background"
   );

   return true;
}


//+------------------------------------------------------------------+
//| Create Label                                                     |
//+------------------------------------------------------------------+
bool CPHXInfoPanel::CreateLabel(
   string name,
   string text,
   int x,
   int y,
   int fontSize,
   color textColor
)
{
   //--------------------------------------------------
   // Remove stale label
   //--------------------------------------------------
   if(ObjectFind(
         0,
         name
      ) >= 0)
   {
      ObjectDelete(
         0,
         name
      );
   }

   //--------------------------------------------------
   // Create
   //--------------------------------------------------
   if(!ObjectCreate(
         0,
         name,
         OBJ_LABEL,
         0,
         0,
         0
      ))
   {
      Print(
         "PHX InfoPanel ERROR: label creation failed ",
         name
      );

      return false;
   }

   //--------------------------------------------------
   // Lower-left attachment
   //--------------------------------------------------
   ObjectSetInteger(
      0,
      name,
      OBJPROP_CORNER,
      CORNER_LEFT_LOWER
   );

   ObjectSetInteger(
      0,
      name,
      OBJPROP_ANCHOR,
      ANCHOR_LEFT_LOWER
   );

   //--------------------------------------------------
   // Position inside panel
   //--------------------------------------------------
   ObjectSetInteger(
      0,
      name,
      OBJPROP_XDISTANCE,
      m_x + x
   );

   ObjectSetInteger(
      0,
      name,
      OBJPROP_YDISTANCE,
      m_y + y
   );

   //--------------------------------------------------
   // Text properties
   //--------------------------------------------------
   ObjectSetInteger(
      0,
      name,
      OBJPROP_FONTSIZE,
      fontSize
   );

   ObjectSetInteger(
      0,
      name,
      OBJPROP_COLOR,
      textColor
   );

   ObjectSetString(
      0,
      name,
      OBJPROP_FONT,
      "Arial"
   );

   ObjectSetString(
      0,
      name,
      OBJPROP_TEXT,
      text
   );

   //--------------------------------------------------
   // Foreground
   //--------------------------------------------------
   ObjectSetInteger(
      0,
      name,
      OBJPROP_BACK,
      false
   );

   //--------------------------------------------------
   // No manual movement
   //--------------------------------------------------
   ObjectSetInteger(
      0,
      name,
      OBJPROP_SELECTABLE,
      false
   );

   ObjectSetInteger(
      0,
      name,
      OBJPROP_SELECTED,
      false
   );

   ObjectSetInteger(
      0,
      name,
      OBJPROP_HIDDEN,
      true
   );

   return true;
}


//+------------------------------------------------------------------+
//| Set Text                                                         |
//+------------------------------------------------------------------+
void CPHXInfoPanel::SetText(
   string name,
   string text
)
{
   if(ObjectFind(
         0,
         name
      ) < 0)
   {
      return;
   }

   ObjectSetString(
      0,
      name,
      OBJPROP_TEXT,
      text
   );
}


//+------------------------------------------------------------------+
//| Set Color                                                        |
//+------------------------------------------------------------------+
void CPHXInfoPanel::SetColor(
   string name,
   color textColor
)
{
   if(ObjectFind(
         0,
         name
      ) < 0)
   {
      return;
   }

   ObjectSetInteger(
      0,
      name,
      OBJPROP_COLOR,
      textColor
   );
}


//+------------------------------------------------------------------+
//| Update                                                           |
//+------------------------------------------------------------------+
void CPHXInfoPanel::Update(
   double dailyATR,
   double energyLeftPercent,
   double rsi,
   double adx,
   string trend,
   int score,
   string signal
)
{
   if(!m_initialized)
      return;

   //--------------------------------------------------
   // D1 ATR
   //--------------------------------------------------
   SetText(
      m_valueD1ATR,
      DoubleToString(
         dailyATR,
         _Digits
      )
   );

   //--------------------------------------------------
   // Energy Left
   //--------------------------------------------------
   SetText(
      m_valueEnergy,
      DoubleToString(
         energyLeftPercent,
         2
      )
      +
      "%"
   );

   if(energyLeftPercent < 30.0)
   {
      SetColor(
         m_valueEnergy,
         clrRed
      );
   }
   else
   if(energyLeftPercent < 50.0)
   {
      SetColor(
         m_valueEnergy,
         clrOrange
      );
   }
   else
   {
      SetColor(
         m_valueEnergy,
         clrLime
      );
   }

   //--------------------------------------------------
   // RSI
   //--------------------------------------------------
   SetText(
      m_valueRSI,
      DoubleToString(
         rsi,
         2
      )
   );

   //--------------------------------------------------
   // ADX
   //--------------------------------------------------
   SetText(
      m_valueADX,
      DoubleToString(
         adx,
         2
      )
   );

   //--------------------------------------------------
   // Trend
   //--------------------------------------------------
   SetText(
      m_valueTrend,
      trend
   );

   if(
      trend == "BULLISH" ||
      trend == "BUY"
   )
   {
      SetColor(
         m_valueTrend,
         clrLime
      );
   }
   else
   if(
      trend == "BEARISH" ||
      trend == "SELL"
   )
   {
      SetColor(
         m_valueTrend,
         clrRed
      );
   }
   else
   {
      SetColor(
         m_valueTrend,
         clrSilver
      );
   }

   //--------------------------------------------------
   // Score
   //--------------------------------------------------
   SetText(
      m_valueScore,
      IntegerToString(
         score
      )
   );

   if(score > 0)
   {
      SetColor(
         m_valueScore,
         clrLime
      );
   }
   else
   if(score < 0)
   {
      SetColor(
         m_valueScore,
         clrRed
      );
   }
   else
   {
      SetColor(
         m_valueScore,
         clrSilver
      );
   }

   //--------------------------------------------------
   // Signal
   //--------------------------------------------------
   SetText(
      m_valueSignal,
      signal
   );

   if(signal == "BUY")
   {
      SetColor(
         m_valueSignal,
         clrLime
      );
   }
   else
   if(signal == "SELL")
   {
      SetColor(
         m_valueSignal,
         clrRed
      );
   }
   else
   {
      SetColor(
         m_valueSignal,
         clrSilver
      );
   }

   //--------------------------------------------------
   // Redraw panel
   //--------------------------------------------------
   ChartRedraw();
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXInfoPanel::Shutdown()
{
   //--------------------------------------------------
   // Destroy Canvas
   //--------------------------------------------------
   if(m_canvasCreated)
   {
      m_canvas.Destroy();

      m_canvasCreated = false;
   }

   //--------------------------------------------------
   // Remove all PHX panel labels
   //--------------------------------------------------
   ObjectsDeleteAll(
      0,
      m_prefix
   );

   //--------------------------------------------------
   // Reset
   //--------------------------------------------------
   m_initialized = false;

   ChartRedraw();
}


//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXInfoPanel::IsInitialized() const
{
   return m_initialized;
}


#endif // __PHX_INFO_PANEL_MQH__