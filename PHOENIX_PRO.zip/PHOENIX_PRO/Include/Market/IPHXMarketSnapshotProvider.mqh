#ifndef PHX_MARKET_SNAPSHOT_PROVIDER_INTERFACE_MQH
#define PHX_MARKET_SNAPSHOT_PROVIDER_INTERFACE_MQH


//+------------------------------------------------------------------+
//| Market Snapshot Provider Interface                                |
//+------------------------------------------------------------------+
class IPHXMarketSnapshotProvider
{

public:

   //--------------------------------------------------
   // Destructor
   //--------------------------------------------------

   virtual ~IPHXMarketSnapshotProvider()
   {
   }


public:

   //--------------------------------------------------
   // OHLC
   //--------------------------------------------------

   virtual double Open() const = 0;

   virtual double High() const = 0;

   virtual double Low() const = 0;

   virtual double Close() const = 0;


   //--------------------------------------------------
   // Market Index
   //--------------------------------------------------

   virtual long BarIndex() const = 0;

   virtual long TickIndex() const = 0;

};


#endif // PHX_MARKET_SNAPSHOT_PROVIDER_INTERFACE_MQH