#ifndef PHX_MARKET_STATE_PROVIDER_MQH
#define PHX_MARKET_STATE_PROVIDER_MQH


#include "IPHXMarketStateProvider.mqh"


//+------------------------------------------------------------------+
//| Market State Provider                                            |
//+------------------------------------------------------------------+
class CPHXMarketStateProvider :
      public IPHXMarketStateProvider
{

private:

   string m_symbol;


   int m_spread;


   bool m_sessionOpen;


   bool m_highLiquidity;


   bool m_valid;


public:

   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------

   CPHXMarketStateProvider();


   //--------------------------------------------------
   // Initialize
   //--------------------------------------------------

   bool Initialize(
      string symbol
   );


   //--------------------------------------------------
   // Refresh
   //--------------------------------------------------

   bool Refresh();


public:

   //--------------------------------------------------
   // State
   //--------------------------------------------------

   virtual int Spread() const;

   virtual bool SessionOpen() const;

   virtual bool HighLiquidity() const;


};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXMarketStateProvider::CPHXMarketStateProvider()
{

   m_symbol = "";

   m_spread = 0;

   m_sessionOpen = false;

   m_highLiquidity = false;

   m_valid = false;

}

//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXMarketStateProvider::Initialize(
   string symbol
)
{

   if(symbol == "")
      return false;


   m_symbol = symbol;


   return true;

}

//+------------------------------------------------------------------+
//| Refresh Market State                                             |
//+------------------------------------------------------------------+
bool CPHXMarketStateProvider::Refresh()
{

   if(m_symbol == "")
      return false;



   //--------------------------------------------------
   // Spread
   //--------------------------------------------------

   m_spread =
      (int)SymbolInfoInteger(
         m_symbol,
         SYMBOL_SPREAD
      );



   //--------------------------------------------------
   // Trading Session
   //--------------------------------------------------

   datetime currentTime =
      TimeTradeServer();


   MqlDateTime dt;

   TimeToStruct(
      currentTime,
      dt
   );


   // Понедельник - пятница
   m_sessionOpen =
      (
         dt.day_of_week >= 1 &&
         dt.day_of_week <= 5
      );



   //--------------------------------------------------
   // Liquidity
   //--------------------------------------------------

   m_highLiquidity =
      (
         m_sessionOpen &&
         m_spread > 0
      );



   m_valid = true;


   return true;

}

//+------------------------------------------------------------------+
//| Spread                                                           |
//+------------------------------------------------------------------+
int CPHXMarketStateProvider::Spread() const
{

   if(!m_valid)
      return 0;


   return m_spread;

}


//+------------------------------------------------------------------+
//| Session Open                                                     |
//+------------------------------------------------------------------+
bool CPHXMarketStateProvider::SessionOpen() const
{

   if(!m_valid)
      return false;


   return m_sessionOpen;

}


//+------------------------------------------------------------------+
//| High Liquidity                                                   |
//+------------------------------------------------------------------+
bool CPHXMarketStateProvider::HighLiquidity() const
{

   if(!m_valid)
      return false;


   return m_highLiquidity;

}


#endif // PHX_MARKET_STATE_PROVIDER_MQH