#ifndef PHX_FUTURE_PROJECTION_PROVIDER_INTERFACE_MQH
#define PHX_FUTURE_PROJECTION_PROVIDER_INTERFACE_MQH


//+------------------------------------------------------------------+
//| Future Projection Provider Interface                             |
//+------------------------------------------------------------------+
class IPHXFutureProjectionProvider
{

public:

   virtual ~IPHXFutureProjectionProvider()
   {
   }


public:

   //--------------------------------------------------
   // Future Close Projection
   //--------------------------------------------------

   virtual double FutureClose5() const = 0;

   virtual double FutureClose10() const = 0;

   virtual double FutureClose20() const = 0;


};


#endif // PHX_FUTURE_PROJECTION_PROVIDER_INTERFACE_MQH