#ifndef PHX_FUTURE_PROJECTION_PROVIDER_MQH
#define PHX_FUTURE_PROJECTION_PROVIDER_MQH


#include "IPHXFutureProjectionProvider.mqh"


//+------------------------------------------------------------------+
//| Future Projection Provider                                       |
//+------------------------------------------------------------------+
class CPHXFutureProjectionProvider :
      public IPHXFutureProjectionProvider
{

private:

   string m_symbol;

   ENUM_TIMEFRAMES m_timeframe;


   double m_futureClose5;

   double m_futureClose10;

   double m_futureClose20;


   bool m_valid;


public:

   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------

   CPHXFutureProjectionProvider();


   //--------------------------------------------------
   // Initialize
   //--------------------------------------------------

   bool Initialize(
      string symbol,
      ENUM_TIMEFRAMES timeframe
   );


   //--------------------------------------------------
   // Refresh
   //--------------------------------------------------

   bool Refresh();


public:

   //--------------------------------------------------
   // Future Close
   //--------------------------------------------------

   virtual double FutureClose5() const;

   virtual double FutureClose10() const;

   virtual double FutureClose20() const;


};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXFutureProjectionProvider::CPHXFutureProjectionProvider()
{

   m_symbol = "";

   m_timeframe = PERIOD_CURRENT;


   m_futureClose5 = 0;

   m_futureClose10 = 0;

   m_futureClose20 = 0;


   m_valid = false;

}

//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXFutureProjectionProvider::Initialize(
   string symbol,
   ENUM_TIMEFRAMES timeframe
)
{

   if(symbol == "")
      return false;


   m_symbol = symbol;

   m_timeframe = timeframe;


   return true;

}

//+------------------------------------------------------------------+
//| Refresh Future Projection                                        |
//+------------------------------------------------------------------+
bool CPHXFutureProjectionProvider::Refresh()
{

   if(m_symbol == "")
      return false;


   MqlRates rates[25];


   int copied =
      CopyRates(
         m_symbol,
         m_timeframe,
         0,
         25,
         rates
      );


   if(copied < 21)
      return false;



   //--------------------------------------------------
   // Future Close
   //--------------------------------------------------

   m_futureClose5 =
      rates[5].close;


   m_futureClose10 =
      rates[10].close;


   m_futureClose20 =
      rates[20].close;



   m_valid = true;


   return true;

}

//+------------------------------------------------------------------+
//| Future Close 5                                                   |
//+------------------------------------------------------------------+
double CPHXFutureProjectionProvider::FutureClose5() const
{

   if(!m_valid)
      return 0;


   return m_futureClose5;

}


//+------------------------------------------------------------------+
//| Future Close 10                                                  |
//+------------------------------------------------------------------+
double CPHXFutureProjectionProvider::FutureClose10() const
{

   if(!m_valid)
      return 0;


   return m_futureClose10;

}


//+------------------------------------------------------------------+
//| Future Close 20                                                  |
//+------------------------------------------------------------------+
double CPHXFutureProjectionProvider::FutureClose20() const
{

   if(!m_valid)
      return 0;


   return m_futureClose20;

}

#endif // PHX_FUTURE_PROJECTION_PROVIDER_MQH