//+------------------------------------------------------------------+
//|                    PHXMarketEngine.mqh                           |
//|              PHOENIX PRO Trading Framework                       |
//+------------------------------------------------------------------+
#ifndef __PHX_MARKET_ENGINE_MQH__
#define __PHX_MARKET_ENGINE_MQH__

#include "PHXTickBuffer.mqh"
#include "IPHXMarketPriceProvider.mqh"
//+------------------------------------------------------------------+
//| Market Engine                                                    |
//+------------------------------------------------------------------+
class CPHXMarketEngine :
      public IPHXMarketPriceProvider
{

private:

   bool m_initialized;

   ulong m_updateCount;

   CPHXTickBuffer* m_tickBuffer;
              
   string   m_symbol;

   double   m_bid;

   double   m_ask;

   long     m_spread;

   datetime m_lastUpdate;
   
   //--------------------------------------------------
   // Price Provider Interface
   //--------------------------------------------------

   virtual double Bid() const override;

   virtual double Ask() const override;

   virtual long Spread() const override;
   
   //--------------------------------------------------
   // Bar data
   //--------------------------------------------------

   SPHXBarData m_bar;


//--------------------------------------------------
// Constructor / Destructor
//--------------------------------------------------

public:

   CPHXMarketEngine();

   ~CPHXMarketEngine();



//--------------------------------------------------
// Lifecycle
//--------------------------------------------------

public:

   bool Initialize();

   void Shutdown();

   void Reset();

   bool IsInitialized() const;



//--------------------------------------------------
// Dependencies
//--------------------------------------------------

public:

   void SetTickBuffer(CPHXTickBuffer* buffer);

   
//--------------------------------------------------
// Data Access
//--------------------------------------------------

public:

   bool GetCurrentTick(SPHXTick &tick) const;
   
//--------------------------------------------------
// Bar Access
//--------------------------------------------------

   bool GetCurrentBar(SPHXBarData &bar) const;



//--------------------------------------------------
// Operations
//--------------------------------------------------

public:

   bool Update();



//--------------------------------------------------
// Statistics
//--------------------------------------------------

public:

   ulong GetUpdateCount() const;



//--------------------------------------------------
// Information
//--------------------------------------------------

public:

   string GetSymbol() const;

   double GetBid() const;

   double GetAsk() const;

   long GetSpread() const; 
   
   datetime GetLastUpdate() const;

};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXMarketEngine::CPHXMarketEngine()
{
   m_initialized = false;

   m_updateCount = 0;
   
   m_tickBuffer = NULL;
   
   m_symbol      = "";

   m_bid         = 0;

   m_ask         = 0;

   m_spread      = 0;

   m_lastUpdate  = 0;
   
   m_bar.Reset();
}


//+------------------------------------------------------------------+
//| Set Tick Buffer                                                  |
//+------------------------------------------------------------------+
void CPHXMarketEngine::SetTickBuffer(CPHXTickBuffer* buffer)
{
   m_tickBuffer = buffer;
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXMarketEngine::~CPHXMarketEngine()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXMarketEngine::Initialize()
{
   if(m_initialized)
      return true;


   Reset();


   m_initialized = true;


   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXMarketEngine::Shutdown()
{
   if(!m_initialized)
      return;


   Reset();


   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXMarketEngine::Reset()
{
   m_updateCount = 0;
   
   m_symbol     = "";

   m_bid        = 0;

   m_ask        = 0;

   m_spread     = 0;

   m_lastUpdate = 0;
}


//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXMarketEngine::IsInitialized() const
{
   return m_initialized;
}


//+------------------------------------------------------------------+
//| Update                                                           |
//+------------------------------------------------------------------+
bool CPHXMarketEngine::Update()
{
   if(!m_initialized)
      return false;


   m_updateCount++;


   m_symbol = _Symbol;


   m_bid = SymbolInfoDouble(
            _Symbol,
            SYMBOL_BID
        );


   m_ask = SymbolInfoDouble(
            _Symbol,
            SYMBOL_ASK
        );


   m_spread = SymbolInfoInteger(
               _Symbol,
               SYMBOL_SPREAD
           );


   m_lastUpdate = TimeCurrent();
   
   //--------------------------------------------------
   // Update Current Bar
   //--------------------------------------------------

   MqlRates rates[];

   ArraySetAsSeries(rates,true);


   if(CopyRates(
      _Symbol,
      PERIOD_CURRENT,
      0,
      1,
      rates
   ) > 0)
{

   m_bar.open =
      rates[0].open;

   m_bar.high =
      rates[0].high;

   m_bar.low =
      rates[0].low;

   m_bar.close =
      rates[0].close;

   m_bar.barIndex =
      iBars(
         _Symbol,
         PERIOD_CURRENT
      ) - 1;

}
   
   
   SPHXTick tick;

   tick.Reset();

   tick.time = m_lastUpdate;

   tick.bid = m_bid;

   tick.ask = m_ask;

   tick.last = 0;

   tick.volume = 0;

   tick.flags = 0;


if(CheckPointer(m_tickBuffer) == POINTER_DYNAMIC)
{
   m_tickBuffer.AddTick(tick);
}

   
   Print(
   "PHXMarketEngine: ",
   m_symbol,
   " Bid=",
   DoubleToString(m_bid,_Digits),
   " Ask=",
   DoubleToString(m_ask,_Digits),
   " Spread=",
   m_spread
);
   
   
   return true;
}


//+------------------------------------------------------------------+
//| Get Update Count                                                 |
//+------------------------------------------------------------------+
ulong CPHXMarketEngine::GetUpdateCount() const
{
   return m_updateCount;
}

string CPHXMarketEngine::GetSymbol() const
{
   return m_symbol;
}


double CPHXMarketEngine::GetBid() const
{
   return m_bid;
}


double CPHXMarketEngine::GetAsk() const
{
   return m_ask;
}


long CPHXMarketEngine::GetSpread() const
{
   return m_spread;
}


datetime CPHXMarketEngine::GetLastUpdate() const
{
   return m_lastUpdate;
}

//+------------------------------------------------------------------+
//| Price Provider                                                   |
//+------------------------------------------------------------------+

double CPHXMarketEngine::Bid() const
{
   return m_bid;
}


double CPHXMarketEngine::Ask() const
{
   return m_ask;
}


long CPHXMarketEngine::Spread() const
{
   return m_spread;
}
//+------------------------------------------------------------------+
//| Get Current Tick                                                 |
//+------------------------------------------------------------------+
bool CPHXMarketEngine::GetCurrentTick(SPHXTick &tick) const
{
   if(!m_initialized)
      return false;


   tick.Reset();


   tick.time = m_lastUpdate;

   tick.bid = m_bid;

   tick.ask = m_ask;

   tick.last = 0;

   tick.volume = 0;

   tick.flags = 0;


   return true;
}

//+------------------------------------------------------------------+
//| Get Current Bar                                                  |
//+------------------------------------------------------------------+

   bool CPHXMarketEngine::GetCurrentBar(
   SPHXBarData &bar
)  const
{

   if(!m_initialized)
   return false;


   bar = m_bar;


   return true;

}


#endif // __PHX_MARKET_ENGINE_MQH__