#ifndef PHX_MARKET_SNAPSHOT_PROVIDER_MQH
#define PHX_MARKET_SNAPSHOT_PROVIDER_MQH


#include "IPHXMarketSnapshotProvider.mqh"


//+------------------------------------------------------------------+
//| Market Snapshot Provider                                         |
//+------------------------------------------------------------------+
class CPHXMarketSnapshotProvider :
      public IPHXMarketSnapshotProvider
{

private:

   string m_symbol;

   ENUM_TIMEFRAMES m_timeframe;
   
   MqlRates m_rates[1];

   bool m_valid;


public:

   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------

   CPHXMarketSnapshotProvider();


   //--------------------------------------------------
   // Configure
   //--------------------------------------------------

   void Configure(
      string symbol,
      ENUM_TIMEFRAMES timeframe
   );

   bool Refresh();
   
public:

   //--------------------------------------------------
   // Market Data
   //--------------------------------------------------

   virtual double Open() const;

   virtual double High() const;

   virtual double Low() const;

   virtual double Close() const;


   //--------------------------------------------------
   // Counters
   //--------------------------------------------------

   virtual long BarIndex() const;

   virtual long TickIndex() const;

};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+

CPHXMarketSnapshotProvider::CPHXMarketSnapshotProvider()
{

   m_symbol = "";

   m_timeframe = PERIOD_CURRENT;

   m_valid = false;

}

//+------------------------------------------------------------------+
//| Refresh Market Data                                              |
//+------------------------------------------------------------------+
bool CPHXMarketSnapshotProvider::Refresh()
{

   if(m_symbol == "")
      return false;


   int copied =
      CopyRates(
         m_symbol,
         m_timeframe,
         0,
         1,
         m_rates
      );


   if(copied != 1)
   {
      m_valid = false;
      return false;
   }


   m_valid = true;


   return true;

}

//+------------------------------------------------------------------+
//| Open                                                             |
//+------------------------------------------------------------------+
double CPHXMarketSnapshotProvider::Open() const
{

   if(!m_valid)
      return 0;


   return m_rates[0].open;

}


//+------------------------------------------------------------------+
//| High                                                             |
//+------------------------------------------------------------------+
double CPHXMarketSnapshotProvider::High() const
{

   if(!m_valid)
      return 0;


   return m_rates[0].high;

}


//+------------------------------------------------------------------+
//| Low                                                              |
//+------------------------------------------------------------------+
double CPHXMarketSnapshotProvider::Low() const
{

   if(!m_valid)
      return 0;


   return m_rates[0].low;

}


//+------------------------------------------------------------------+
//| Close                                                            |
//+------------------------------------------------------------------+
double CPHXMarketSnapshotProvider::Close() const
{

   if(!m_valid)
      return 0;


   return m_rates[0].close;

}

//+------------------------------------------------------------------+
//| Bar Index                                                        |
//+------------------------------------------------------------------+
long CPHXMarketSnapshotProvider::BarIndex() const
{
   if(!m_valid)
      return 0;

   return m_rates[0].time;
}


//+------------------------------------------------------------------+
//| Tick Index                                                       |
//+------------------------------------------------------------------+
long CPHXMarketSnapshotProvider::TickIndex() const
{
   if(!m_valid)
      return 0;

   return m_rates[0].tick_volume;
}

#endif // PHX_MARKET_SNAPSHOT_PROVIDER_MQH