//+------------------------------------------------------------------+
//|                         PHXTickBuffer.mqh                        |
//|                    PHOENIX PRO Trading Framework                 |
//|                                                                  |
//| Description:                                                     |
//|   Fast tick storage service                                      |
//+------------------------------------------------------------------+

#ifndef __PHX_TICK_BUFFER_MQH__
#define __PHX_TICK_BUFFER_MQH__


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXMarketTypes.mqh"
#include <PHOENIX_PRO/Core/PHXConstants.mqh>

//+------------------------------------------------------------------+
//| Tick Buffer Class                                                |
//+------------------------------------------------------------------+
class CPHXTickBuffer
{

private:

   // Initialization state
   bool m_initialized;
   
   SPHXTick  m_buffer[PHX_TICK_BUFFER_SIZE];

   uint      m_head;

   uint      m_count;



//--------------------------------------------------
// Constructor / Destructor
//--------------------------------------------------

public:

   CPHXTickBuffer();

   ~CPHXTickBuffer();



//--------------------------------------------------
// Lifecycle
//--------------------------------------------------

public:

   bool Initialize();

   void Shutdown();

   void Reset();

   bool IsInitialized() const;



//--------------------------------------------------
// Operations
//--------------------------------------------------

public:

   bool AddTick(const SPHXTick &tick);

   bool GetLatest(SPHXTick &tick) const;

   bool GetPrevious(const uint shift,
                    SPHXTick &tick) const;



//--------------------------------------------------
// Information
//--------------------------------------------------

public:

   uint Count() const;

};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXTickBuffer::CPHXTickBuffer()
{
   m_initialized = false;

   m_head = 0;

   m_count = 0;

   for(uint i = 0; i < PHX_TICK_BUFFER_SIZE; i++)
      m_buffer[i].Reset();
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXTickBuffer::~CPHXTickBuffer()
{
   Shutdown();
}

//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXTickBuffer::Initialize()
{
   if(m_initialized)
      return true;

   Reset();

   m_initialized = true;

   return true;
}

//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXTickBuffer::Shutdown()
{
   if(!m_initialized)
      return;

   Reset();

   m_initialized = false;
}

//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXTickBuffer::Reset()
{
   m_head = 0;

   m_count = 0;

   for(uint i = 0; i < PHX_TICK_BUFFER_SIZE; i++)
      m_buffer[i].Reset();
}

//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXTickBuffer::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| Add Tick                                                         |
//+------------------------------------------------------------------+
bool CPHXTickBuffer::AddTick(const SPHXTick &tick)
{
   if(!m_initialized)
      return false;


   m_buffer[m_head] = tick;


   m_head++;


   if(m_head >= PHX_TICK_BUFFER_SIZE)
      m_head = 0;


   if(m_count < PHX_TICK_BUFFER_SIZE)
      m_count++;


   return true;
}

//+------------------------------------------------------------------+
//| Get Latest Tick                                                  |
//+------------------------------------------------------------------+
bool CPHXTickBuffer::GetLatest(SPHXTick &tick) const
{
   if(!m_initialized)
      return false;


   if(m_count == 0)
      return false;


   uint index;


   if(m_head == 0)
      index = PHX_TICK_BUFFER_SIZE - 1;
   else
      index = m_head - 1;


   tick = m_buffer[index];


   return true;
}

//+------------------------------------------------------------------+
//| Get Previous Tick                                                |
//+------------------------------------------------------------------+
bool CPHXTickBuffer::GetPrevious(
   const uint shift,
   SPHXTick &tick) const
{
   if(!m_initialized)
      return false;


   if(m_count == 0)
      return false;


   if(shift >= m_count)
      return false;


   int index = (int)m_head - 1 - (int)shift;


   while(index < 0)
      index += PHX_TICK_BUFFER_SIZE;


   tick = m_buffer[index];


   return true;
}

//+------------------------------------------------------------------+
//| Tick Count                                                       |
//+------------------------------------------------------------------+
uint CPHXTickBuffer::Count() const
{
   return m_count;
}

#endif // __PHX_TICK_BUFFER_MQH__