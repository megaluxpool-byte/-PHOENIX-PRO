//+------------------------------------------------------------------+
//|                     PHXSpreadMonitor.mqh                         |
//|                  PHOENIX PRO Trading Framework                   |
//+------------------------------------------------------------------+
#ifndef __PHX_SPREAD_MONITOR_MQH__
#define __PHX_SPREAD_MONITOR_MQH__

#include "PHXMarketTypes.mqh"

//+------------------------------------------------------------------+
//| Spread Monitor                                                   |
//+------------------------------------------------------------------+
class CPHXSpreadMonitor
{
private:

   string m_symbol;
   
   //--------------------------------------------------
   // Current spread
   //--------------------------------------------------
   
   int m_spreadPoints;
   
   double m_currentSpread;

   double m_currentSpreadPoints;
   
   //--------------------------------------------------
   // Spread limits
   //--------------------------------------------------

   int m_maxSpreadPoints;

   double m_maxATRRatio;
   
   
   //--------------------------------------------------
   // State
   //--------------------------------------------------
   
   bool   m_initialized;

public:

   CPHXSpreadMonitor();
   ~CPHXSpreadMonitor();

public:

   bool Initialize(string symbol);

   void Shutdown();

   void Reset();

   bool IsInitialized() const;

public:

   bool Update();

public:

   double GetSpread() const;

   double GetSpreadPoints() const;

   bool IsSpreadAllowed(double maxSpreadPoints) const;
   
   bool IsATRSpreadAllowed(double atrPoints) const;
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXSpreadMonitor::CPHXSpreadMonitor()
{
   m_symbol              = "";
   m_initialized         = false;
   m_currentSpread       = 0.0;
   m_currentSpreadPoints = 0.0;
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXSpreadMonitor::~CPHXSpreadMonitor()
{
   Shutdown();
}

//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXSpreadMonitor::Initialize(string symbol)
{
   if(m_initialized)
      return true;

   if(symbol=="")
      return false;

   m_symbol = symbol;

    
   //--------------------------------------------------
   // Spread parameters
   //--------------------------------------------------

   m_maxSpreadPoints = 50;

   m_maxATRRatio = 0.010;

   m_initialized = true;
   
   Reset();

   return true;
}

//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXSpreadMonitor::Shutdown()
{
   if(!m_initialized)
      return;

   Reset();

   m_symbol = "";

   m_initialized = false;
}

//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXSpreadMonitor::Reset()
{
   m_currentSpread       = 0.0;
   m_currentSpreadPoints = 0.0;
}

//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXSpreadMonitor::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| Update                                                           |
//+------------------------------------------------------------------+
bool CPHXSpreadMonitor::Update()
{
   if(!m_initialized)
      return false;

   MqlTick tick;

   if(!SymbolInfoTick(m_symbol, tick))
      return false;

   m_currentSpread = tick.ask - tick.bid;
   m_currentSpreadPoints = m_currentSpread / _Point;

   return true;
}

//+------------------------------------------------------------------+
//| Current Spread                                                   |
//+------------------------------------------------------------------+
double CPHXSpreadMonitor::GetSpread() const
{
   return m_currentSpread;
}

//+------------------------------------------------------------------+
//| Current Spread Points                                            |
//+------------------------------------------------------------------+
double CPHXSpreadMonitor::GetSpreadPoints() const
{
   return m_currentSpreadPoints;
}

//+------------------------------------------------------------------+
//| Spread Filter                                                    |
//+------------------------------------------------------------------+
bool CPHXSpreadMonitor::IsSpreadAllowed(double maxSpreadPoints) const
{
   return (m_currentSpreadPoints <= maxSpreadPoints);
}

//+------------------------------------------------------------------+
//| ATR Spread Filter                                                |
//+------------------------------------------------------------------+
bool CPHXSpreadMonitor::IsATRSpreadAllowed(double atrPrice) const
{

   if(atrPrice <= 0)
      return false;


   double point =
      SymbolInfoDouble(
         m_symbol,
         SYMBOL_POINT
      );


   if(point <= 0)
      return false;


   //--------------------------------------------------
   // Convert spread points to price
   //--------------------------------------------------

   double spreadPrice =
      m_spreadPoints * point;



   //--------------------------------------------------
   // Maximum allowed spread
   //--------------------------------------------------

   double maxAllowedSpread =
      atrPrice * m_maxATRRatio;



   return (
      spreadPrice <= maxAllowedSpread
   );

}

#endif // __PHX_SPREAD_MONITOR_MQH__