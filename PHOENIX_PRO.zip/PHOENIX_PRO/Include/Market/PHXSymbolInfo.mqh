//+------------------------------------------------------------------+
//|                    PHXSymbolInfo.mqh                             |
//|              PHOENIX PRO Trading Framework                       |
//+------------------------------------------------------------------+
#ifndef __PHX_SYMBOL_INFO_MQH__
#define __PHX_SYMBOL_INFO_MQH__


//+------------------------------------------------------------------+
//| Symbol Information Service                                       |
//+------------------------------------------------------------------+
class CPHXSymbolInfo
{

private:

   bool m_initialized;

   string m_symbol;

   int m_digits;

   double m_point;

   double m_tickSize;

   double m_tickValue;

   double m_contractSize;
   
   double m_volumeMin;

   double m_volumeMax;

   double m_volumeStep;


public:

   CPHXSymbolInfo();

   ~CPHXSymbolInfo();


public:

   bool Initialize();

   void Shutdown();

   void Reset();

   bool IsInitialized() const;


public:

   bool Update();


public:

   string Symbol() const;

   int Digits() const;

   double Point() const;

   double TickSize() const;

   double TickValue() const;

   double ContractSize() const;
   
   double VolumeMin() const;

   double VolumeMax() const;

   double VolumeStep() const;

};


//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXSymbolInfo::CPHXSymbolInfo()
{
   m_initialized = false;

   m_symbol = "";

   m_digits = 0;

   m_point = 0;

   m_tickSize = 0;

   m_tickValue = 0;

   m_contractSize = 0;
   
   m_volumeMin = 0;

   m_volumeMax = 0;

   m_volumeStep = 0;
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXSymbolInfo::~CPHXSymbolInfo()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXSymbolInfo::Initialize()
{
   if(m_initialized)
      return true;


   Reset();

   Update();


   m_initialized = true;

   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXSymbolInfo::Shutdown()
{
   if(!m_initialized)
      return;


   Reset();

   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXSymbolInfo::Reset()
{
   m_symbol = "";

   m_digits = 0;

   m_point = 0;

   m_tickSize = 0;

   m_tickValue = 0;

   m_contractSize = 0;
   
   m_volumeMin = 0;

   m_volumeMax = 0;

   m_volumeStep = 0;
}


//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXSymbolInfo::IsInitialized() const
{
   return m_initialized;
}


//+------------------------------------------------------------------+
//| Update                                                           |
//+------------------------------------------------------------------+
bool CPHXSymbolInfo::Update()
{
   if(!m_initialized)
      return false;


   m_symbol = _Symbol;


   m_digits =
      (int)SymbolInfoInteger(
            _Symbol,
            SYMBOL_DIGITS
      );


   m_point =
      SymbolInfoDouble(
            _Symbol,
            SYMBOL_POINT
      );


   m_tickSize =
      SymbolInfoDouble(
            _Symbol,
            SYMBOL_TRADE_TICK_SIZE
      );


   m_tickValue =
      SymbolInfoDouble(
            _Symbol,
            SYMBOL_TRADE_TICK_VALUE
      );
	  
	 m_contractSize =
      SymbolInfoDouble(
            _Symbol,
            SYMBOL_TRADE_CONTRACT_SIZE
      ); 

   m_volumeMin =
      SymbolInfoDouble(
            _Symbol,
            SYMBOL_VOLUME_MIN
      );


   m_volumeMax =
      SymbolInfoDouble(
            _Symbol,
            SYMBOL_VOLUME_MAX
      );


   m_volumeStep =
      SymbolInfoDouble(
            _Symbol,
            SYMBOL_VOLUME_STEP
      );


   return true;
}

//+------------------------------------------------------------------+
//| Getters                                                          |
//+------------------------------------------------------------------+

string CPHXSymbolInfo::Symbol() const
{
   return m_symbol;
}


int CPHXSymbolInfo::Digits() const
{
   return m_digits;
}


double CPHXSymbolInfo::Point() const
{
   return m_point;
}


double CPHXSymbolInfo::TickSize() const
{
   return m_tickSize;
}


double CPHXSymbolInfo::TickValue() const
{
   return m_tickValue;
}


double CPHXSymbolInfo::ContractSize() const
{
   return m_contractSize;
}


double CPHXSymbolInfo::VolumeMin() const
{
   return m_volumeMin;
}


double CPHXSymbolInfo::VolumeMax() const
{
   return m_volumeMax;
}


double CPHXSymbolInfo::VolumeStep() const
{
   return m_volumeStep;
}


#endif // __PHX_SYMBOL_INFO_MQH__