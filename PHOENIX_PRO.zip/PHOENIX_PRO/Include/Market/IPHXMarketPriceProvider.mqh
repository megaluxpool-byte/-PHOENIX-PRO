#ifndef PHX_MARKET_PRICE_PROVIDER_INTERFACE_MQH
#define PHX_MARKET_PRICE_PROVIDER_INTERFACE_MQH


//+------------------------------------------------------------------+
//| Market Price Provider Interface                                  |
//+------------------------------------------------------------------+

class IPHXMarketPriceProvider
{

public:

   //--------------------------------------------------
   // Destructor
   //--------------------------------------------------

   virtual ~IPHXMarketPriceProvider()
   {
   }


public:

   //--------------------------------------------------
   // Current Prices
   //--------------------------------------------------

   virtual double Bid() const = 0;

   virtual double Ask() const = 0;


   //--------------------------------------------------
   // Spread
   //--------------------------------------------------

   virtual long Spread() const = 0;

};


#endif // PHX_MARKET_PRICE_PROVIDER_INTERFACE_MQH