//+------------------------------------------------------------------+
//|                             PHXMarketTypes.mqh                   |
//|                    PHOENIX PRO Trading Framework                 |
//|                                                                  |
//| Description:                                                     |
//|   Market data structures                                         |
//+------------------------------------------------------------------+
#ifndef __PHX_MARKET_TYPES_MQH__
#define __PHX_MARKET_TYPES_MQH__


//+------------------------------------------------------------------+
//| Tick Data                                                        |
//+------------------------------------------------------------------+
struct SPHXTick
{
   // Tick time
   datetime time;


   // Price
   double bid;

   double ask;

   double last;


   // Volume
   long volume;


   // Flags
   uint flags;


   //--------------------------------------------------
   // Reset
   //--------------------------------------------------

   void Reset()
   {
      time = 0;

      bid = 0.0;

      ask = 0.0;

      last = 0.0;

      volume = 0;

      flags = 0;
   }
};


//+------------------------------------------------------------------+
//| Symbol Market State                                              |
//+------------------------------------------------------------------+
   struct SPHXSymbolState
{
   string symbol;


   double bid;

   double ask;


   double spread;

   double spreadPoints;


   // Price properties
   int digits;

   double point;

   double tickSize;

   double tickValue;


   // Contract
   double contractSize;
   

   // Volume
   double volumeMin;

   double volumeMax;

   double volumeStep;


   // Trading
   ENUM_SYMBOL_TRADE_MODE tradeMode;
   
   
   datetime lastUpdate;


   void Reset()
   {
      symbol = "";

      bid = 0.0;

      ask = 0.0;

      spread = 0.0;

      spreadPoints = 0.0;


      digits = 0;

      point = 0.0;
	  
	   tickSize = 0.0;

      tickValue = 0.0;


      contractSize = 0.0;

      volumeMin = 0.0;

      volumeMax = 0.0;

      volumeStep = 0.0;


      tradeMode = SYMBOL_TRADE_MODE_DISABLED;


      lastUpdate = 0;
   }
};


//+------------------------------------------------------------------+
//| Tick Data                                                        |
//+------------------------------------------------------------------+
   struct SPHXTickData
{
   double bid;

   double ask;

   double last;


   long volume;

   double realVolume;


   uint flags;


   datetime time;


   void Reset()
   {
      bid = 0.0;

      ask = 0.0;

      last = 0.0;


      volume = 0.0;

      realVolume = 0.0;


      flags = 0;


      time = 0;
   }
};


//+------------------------------------------------------------------+
//| Spread Information                                               |
//+------------------------------------------------------------------+
   struct SPHXSpreadInfo
{
   double currentSpread;

   double spreadPoints;


   double maxSpread;


   double spreadPercent;


   bool allowed;


   void Reset()
   {
      currentSpread = 0.0;

      spreadPoints = 0.0;


      maxSpread = 0.0;

      spreadPercent = 0.0;


      allowed = false;
   }
};


//+------------------------------------------------------------------+
//| Trading Session State                                            |
//+------------------------------------------------------------------+
   struct SPHXSessionState
{
   string name;


   bool active;

   bool tradingAllowed;


   int startHour;

   int startMinute;


   int endHour;

   int endMinute;


   void Reset()
   {
      name = "";


      active = false;

      tradingAllowed = false;


      startHour = 0;

      startMinute = 0;


      endHour = 0;

      endMinute = 0;
   }
};

//+------------------------------------------------------------------+
//| Bar Market Data                                                  |
//+------------------------------------------------------------------+

   struct SPHXBarData
{

   double open;

   double high;

   double low;

   double close;


   long barIndex;


   void Reset()
{
   open = 0.0;

   high = 0.0;

   low = 0.0;

   close = 0.0;

   barIndex = 0;
}

};

//+------------------------------------------------------------------+
//| Market Snapshot                                                  |
//+------------------------------------------------------------------+
   struct SPHXMarketSnapshot
{

   SPHXSymbolState symbol;

   SPHXTickData tick;

   SPHXBarData bar;

   SPHXSpreadInfo spread;

   SPHXSessionState session;


   void Reset()
{
   symbol.Reset();

   tick.Reset();

   bar.Reset();

   spread.Reset();

   session.Reset();
}

};


#endif // __PHX_MARKET_TYPES_MQH__