//+------------------------------------------------------------------+
//|                    PHXSessionManager.mqh                         |
//|                  PHOENIX PRO Trading Framework                   |
//+------------------------------------------------------------------+
#ifndef __PHX_SESSION_MANAGER_MQH__
#define __PHX_SESSION_MANAGER_MQH__

#include "PHXMarketTypes.mqh"


//+------------------------------------------------------------------+
//| Session Manager                                                  |
//+------------------------------------------------------------------+
class CPHXSessionManager
{

private:

   string m_symbol;


   bool m_initialized;


   // Trading days
   bool m_tradeMonday;
   bool m_tradeTuesday;
   bool m_tradeWednesday;
   bool m_tradeThursday;
   bool m_tradeFriday;


   // Session time
   int m_startHour;
   int m_startMinute;

   int m_endHour;
   int m_endMinute;



public:

   CPHXSessionManager();

   ~CPHXSessionManager();



public:

   bool Initialize(string symbol);

   void Shutdown();

   void Reset();

   bool IsInitialized() const;



public:

   bool IsTradingDay();

   bool IsTradingTime();



public:

   void SetTradingDays(
      bool monday,
      bool tuesday,
      bool wednesday,
      bool thursday,
      bool friday
   );


   void SetTradingTime(
      int startHour,
      int startMinute,
      int endHour,
      int endMinute
   );



public:

   string GetSymbol() const;

};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXSessionManager::CPHXSessionManager()
{
   m_symbol = "";

   m_initialized = false;


   m_tradeMonday    = true;
   m_tradeTuesday   = true;
   m_tradeWednesday = true;
   m_tradeThursday  = true;
   m_tradeFriday    = true;


   m_startHour   = 0;
   m_startMinute = 0;

   m_endHour   = 23;
   m_endMinute = 59;
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXSessionManager::~CPHXSessionManager()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXSessionManager::Initialize(string symbol)
{
   if(m_initialized)
      return true;


   if(symbol == "")
      return false;


   m_symbol = symbol;


   Reset();


   m_initialized = true;


   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXSessionManager::Shutdown()
{
   if(!m_initialized)
      return;


   Reset();


   m_symbol = "";


   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXSessionManager::Reset()
{
   m_tradeMonday    = true;
   m_tradeTuesday   = true;
   m_tradeWednesday = true;
   m_tradeThursday  = true;
   m_tradeFriday    = true;


   m_startHour   = 0;
   m_startMinute = 0;

   m_endHour   = 23;
   m_endMinute = 59;
}


//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXSessionManager::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| Check Trading Day                                                |
//+------------------------------------------------------------------+
bool CPHXSessionManager::IsTradingDay()
{
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);


   switch(dt.day_of_week)
   {
      case 1:
         return m_tradeMonday;

      case 2:
         return m_tradeTuesday;

      case 3:
         return m_tradeWednesday;

      case 4:
         return m_tradeThursday;

      case 5:
         return m_tradeFriday;
   }


   return false;
}


//+------------------------------------------------------------------+
//| Check Trading Time                                               |
//+------------------------------------------------------------------+
bool CPHXSessionManager::IsTradingTime()
{
   MqlDateTime dt;
   TimeToStruct(TimeCurrent(), dt);


   int currentMinutes =
      dt.hour * 60 + dt.min;


   int startMinutes =
      m_startHour * 60 + m_startMinute;


   int endMinutes =
      m_endHour * 60 + m_endMinute;


   return (
      currentMinutes >= startMinutes &&
      currentMinutes <= endMinutes
   );
}


//+------------------------------------------------------------------+
//| Set Trading Days                                                 |
//+------------------------------------------------------------------+
void CPHXSessionManager::SetTradingDays(
   bool monday,
   bool tuesday,
   bool wednesday,
   bool thursday,
   bool friday
)
{
   m_tradeMonday    = monday;
   m_tradeTuesday   = tuesday;
   m_tradeWednesday = wednesday;
   m_tradeThursday  = thursday;
   m_tradeFriday    = friday;
}


//+------------------------------------------------------------------+
//| Set Trading Time                                                  |
//+------------------------------------------------------------------+
void CPHXSessionManager::SetTradingTime(
   int startHour,
   int startMinute,
   int endHour,
   int endMinute
)
{
   m_startHour   = startHour;
   m_startMinute = startMinute;

   m_endHour     = endHour;
   m_endMinute   = endMinute;
}


//+------------------------------------------------------------------+
//| Get Symbol                                                        |
//+------------------------------------------------------------------+
string CPHXSessionManager::GetSymbol() const
{
   return m_symbol;
}

#endif // __PHX_SESSION_MANAGER_MQH__