//+------------------------------------------------------------------+
//|              PHXMarketServices.mqh                               |
//|              PHOENIX PRO Trading Framework                       |
//|                                                                  |
//| Description:                                                     |
//|   Root market service container                                  |
//+------------------------------------------------------------------+
#ifndef __PHX_MARKET_SERVICES_MQH__
#define __PHX_MARKET_SERVICES_MQH__


#include "PHXMarketEngine.mqh"
#include "PHXSymbolInfo.mqh"
#include "PHXTickBuffer.mqh"
#include "PHXSpreadMonitor.mqh"
#include "PHXMarketSnapshot.mqh"
#include "PHXSessionManager.mqh"
#include "IPHXMarketSnapshotProvider.mqh"


class CPHXMarketServices : public IPHXMarketSnapshotProvider
{

private:

   CPHXMarketEngine*     m_engine;

   CPHXSymbolInfo*       m_symbol;

   CPHXTickBuffer*       m_tickBuffer;

   CPHXSpreadMonitor* m_spreadMonitor;

   CPHXMarketSnapshot*   m_snapshot;


   bool m_initialized;


public:

   CPHXMarketServices();

   ~CPHXMarketServices();


public:

   bool Initialize();

   void Shutdown();

   void Reset();
   
   void Update();

   bool IsInitialized() const;


public:

   CPHXMarketEngine* GetMarketEngine();
   
   const CPHXMarketEngine* GetMarketEngine() const;

   CPHXSymbolInfo* GetSymbolInfo();

   CPHXTickBuffer* GetTickBuffer();

   CPHXSpreadMonitor* GetSpreadMonitor();
   
   CPHXSessionManager* GetSessionManager();

   CPHXMarketSnapshot* GetSnapshot();
   
   //--------------------------------------------------
   // Market Snapshot Provider
   //--------------------------------------------------

   double Open() const;

   double High() const;

   double Low() const;

   double Close() const;

   long BarIndex() const;

   long TickIndex() const;
   
   
};

//+------------------------------------------------------------------+
//| Get Spread Monitor                                               |
//+------------------------------------------------------------------+

CPHXSpreadMonitor* CPHXMarketServices::GetSpreadMonitor()
{
   return m_spreadMonitor;
}

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXMarketServices::CPHXMarketServices()
{
   m_engine     = NULL;
   m_symbol     = NULL;
   m_tickBuffer = NULL;
   m_spreadMonitor = NULL;
   m_snapshot   = NULL;

   m_initialized = false;
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXMarketServices::~CPHXMarketServices()
{
   Shutdown();
}

//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXMarketServices::Initialize()
{
   if(m_initialized)
      return true;


   //--------------------------------------------------
   // Tick Buffer
   //--------------------------------------------------

   m_tickBuffer = new CPHXTickBuffer();

   if(m_tickBuffer == NULL)
      return false;


   if(!m_tickBuffer.Initialize())
   {
      delete m_tickBuffer;

      m_tickBuffer = NULL;

      return false;
   }


   //--------------------------------------------------
   // Market Engine
   //--------------------------------------------------

   m_engine = new CPHXMarketEngine();

   if(m_engine == NULL)
      return false;


   if(!m_engine.Initialize())
   {
      delete m_engine;

      m_engine = NULL;

      return false;
   }


   //--------------------------------------------------
   // Connect Engine -> TickBuffer
   //--------------------------------------------------

   m_engine.SetTickBuffer(m_tickBuffer);



  //--------------------------------------------------
  // Symbol Info
  //--------------------------------------------------

   m_symbol = new CPHXSymbolInfo();

   if(m_symbol == NULL)
   return false;


   if(!m_symbol.Initialize())
{
   delete m_symbol;

   m_symbol = NULL;

   return false;
}


   //--------------------------------------------------
   // Market Snapshot
   //--------------------------------------------------

   m_snapshot = new CPHXMarketSnapshot();

   if(m_snapshot == NULL)
   return false;


   if(!m_snapshot.Initialize(_Symbol))
{
   delete m_snapshot;

   m_snapshot = NULL;

   return false;
}


   //--------------------------------------------------
   // Spread Monitor
   //--------------------------------------------------

   m_spreadMonitor = new CPHXSpreadMonitor();

   if(m_spreadMonitor == NULL)
   return false;


   if(!m_spreadMonitor.Initialize(_Symbol))
{
   delete m_spreadMonitor;

   m_spreadMonitor = NULL;

   return false;
}


   //--------------------------------------------------
   // Services Ready
   //--------------------------------------------------

   m_initialized = true;


   return true;
}

   //+------------------------------------------------------------------+
   //| Shutdown                                                         |
   //+------------------------------------------------------------------+
   void CPHXMarketServices::Shutdown()
{
   if(!m_initialized)
      return;

   Print("PHXMarketServices: Shutdown started");

   if(m_spreadMonitor != NULL)
   {
      (*m_spreadMonitor).Shutdown();

      delete m_spreadMonitor;

      m_spreadMonitor = NULL;
      
      Print("PHXMarketServices: SpreadMonitor released");
   }


   if(m_snapshot != NULL)
   {
      (*m_snapshot).Shutdown();

      delete m_snapshot;

      m_snapshot = NULL;
      
      Print("PHXMarketServices: Snapshot released");
   }


   if(m_tickBuffer != NULL)
   {
      (*m_tickBuffer).Shutdown();

      delete m_tickBuffer;

      m_tickBuffer = NULL;
      
      Print("PHXMarketServices: TickBuffer released");
   }


   if(m_symbol != NULL)
   {
      (*m_symbol).Shutdown();

      delete m_symbol;

      m_symbol = NULL;
      
      Print("PHXMarketServices: SymbolInfo released");
   }


   if(m_engine != NULL)
   {
      (*m_engine).Shutdown();

      delete m_engine;

      m_engine = NULL;
      
      Print("PHXMarketServices: Engine released");
   }


   m_initialized = false;
}

   //+------------------------------------------------------------------+
   //| Reset                                                            |
   //+------------------------------------------------------------------+
   void CPHXMarketServices::Reset()
{
   Shutdown();

   Initialize();
}

   //+------------------------------------------------------------------+
   //| Update                                                          |
   //+------------------------------------------------------------------+
   void CPHXMarketServices::Update()
{
   if(!m_initialized)
      return;


   if(m_symbol != NULL)
      m_symbol.Update();


   if(m_engine != NULL)
      m_engine.Update();


   SPHXTick tick;

   tick.Reset();


   //--------------------------------------------------
   // Update Market Snapshot
   //--------------------------------------------------

   if(m_engine != NULL && m_snapshot != NULL)
{

   //--------------------------------------------------
   // Tick
   //--------------------------------------------------

   SPHXTick tick;

   tick.Reset();


   if(m_engine.GetCurrentTick(tick))
   {
      (*m_snapshot).Update(tick);
   }


   //--------------------------------------------------
   // Bar
   //--------------------------------------------------

   SPHXBarData bar;

   bar.Reset();


   if(m_engine.GetCurrentBar(bar))
   {
      (*m_snapshot).UpdateBar(bar);
   }

}


   if(m_spreadMonitor != NULL)
   {
      m_spreadMonitor.Update();
   }
   
   Print(
   "PHXSpreadMonitor: ",
   _Symbol,
   " SpreadPoints=",
   DoubleToString(
      m_spreadMonitor.GetSpreadPoints(),
      0
   )
);
}
//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXMarketServices::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| Get Market Engine                                                |
//+------------------------------------------------------------------+
CPHXMarketEngine* CPHXMarketServices::GetMarketEngine()
{
   return m_engine;
}

const CPHXMarketEngine* CPHXMarketServices::GetMarketEngine() const
{
   return m_engine;
}

//+------------------------------------------------------------------+
//| Get Snapshot                                                     |
//+------------------------------------------------------------------+
CPHXMarketSnapshot* CPHXMarketServices::GetSnapshot()
{
   return m_snapshot;
}

//+------------------------------------------------------------------+
//| Market Snapshot Provider                                         |
//+------------------------------------------------------------------+

   double CPHXMarketServices::Open() const
{
   if(m_snapshot == NULL)
      return 0.0;

   SPHXMarketSnapshot snapshot = (*m_snapshot).GetSnapshot();

   return snapshot.bar.open;
}


//+------------------------------------------------------------------+
//| High                                                              |
//+------------------------------------------------------------------+

   double CPHXMarketServices::High() const
{
   if(m_snapshot == NULL)
      return 0.0;

   SPHXMarketSnapshot snapshot = (*m_snapshot).GetSnapshot();

   return snapshot.bar.high;
}


//+------------------------------------------------------------------+
//| Low                                                               |
//+------------------------------------------------------------------+

   double CPHXMarketServices::Low() const
{
   if(m_snapshot == NULL)
      return 0.0;

   SPHXMarketSnapshot snapshot = (*m_snapshot).GetSnapshot();

   return snapshot.bar.low;
}


//+------------------------------------------------------------------+
//| Close                                                             |
//+------------------------------------------------------------------+

   double CPHXMarketServices::Close() const
{
   if(m_snapshot == NULL)
      return 0.0;

   SPHXMarketSnapshot snapshot = (*m_snapshot).GetSnapshot();

   return snapshot.bar.close;
}


//+------------------------------------------------------------------+
//| Bar Index                                                         |
//+------------------------------------------------------------------+

   long CPHXMarketServices::BarIndex() const
{
   if(m_snapshot == NULL)
      return 0;

   SPHXMarketSnapshot snapshot = (*m_snapshot).GetSnapshot();

   return snapshot.bar.barIndex;
}


//+------------------------------------------------------------------+
//| Tick Index                                                        |
//+------------------------------------------------------------------+

   long CPHXMarketServices::TickIndex() const
{
   if(m_snapshot == NULL)
      return 0;

   SPHXMarketSnapshot snapshot = (*m_snapshot).GetSnapshot();

   return (long)snapshot.tick.time;
}

#endif // __PHX_MARKET_SERVICES_MQH__