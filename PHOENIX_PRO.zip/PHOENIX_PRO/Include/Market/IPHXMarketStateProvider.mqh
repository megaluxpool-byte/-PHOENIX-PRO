#ifndef PHX_MARKET_STATE_PROVIDER_INTERFACE_MQH
#define PHX_MARKET_STATE_PROVIDER_INTERFACE_MQH


//+------------------------------------------------------------------+
//| Market State Provider Interface                                  |
//+------------------------------------------------------------------+
class IPHXMarketStateProvider
{

public:

   //--------------------------------------------------
   // Destructor
   //--------------------------------------------------

   virtual ~IPHXMarketStateProvider()
   {
   }


public:

   //--------------------------------------------------
   // Spread
   //--------------------------------------------------

   virtual int Spread() const = 0;


   //--------------------------------------------------
   // Trading Session
   //--------------------------------------------------

   virtual bool SessionOpen() const = 0;


   //--------------------------------------------------
   // Liquidity
   //--------------------------------------------------

   virtual bool HighLiquidity() const = 0;


};


#endif // PHX_MARKET_STATE_PROVIDER_INTERFACE_MQH