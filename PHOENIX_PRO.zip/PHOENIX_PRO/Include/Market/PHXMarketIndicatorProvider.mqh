#ifndef PHX_MARKET_INDICATOR_PROVIDER_MQH
#define PHX_MARKET_INDICATOR_PROVIDER_MQH


#include "../Indicators/IPHXMarketIndicatorProvider.mqh"
#include "../Indicators/PHXIndicatorServices.mqh"


//+------------------------------------------------------------------+
//| Market Indicator Provider                                        |
//+------------------------------------------------------------------+
class CPHXMarketIndicatorProvider :
      public IPHXMarketIndicatorProvider
{
private:

   CPHXIndicatorServices* m_indicatorService;
   
   string m_symbol;

   ENUM_TIMEFRAMES m_timeframe;

   int m_atrHandle;
   int m_rsiHandle;   
   
   double m_atrBuffer[1];
   double m_rsiBuffer[1];  
   long m_volume;
   double m_averageVolume; 
   double m_adx;
   double m_plusDI;
   double m_minusDI;
   double m_dailyATR;
   double m_ma2;
   bool m_valid;

public:
   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------
   CPHXMarketIndicatorProvider();
   //--------------------------------------------------
   // Initialize
   //--------------------------------------------------
   bool Initialize(
      string symbol,
      ENUM_TIMEFRAMES timeframe
   );
   //--------------------------------------------------
   // Set Indicator Service
   //--------------------------------------------------
   void SetIndicatorService(
      CPHXIndicatorServices* service
   );
   //--------------------------------------------------
   // Refresh
   //--------------------------------------------------
   bool Refresh();
public:
   //--------------------------------------------------
   // Indicators
   //--------------------------------------------------
   virtual double ATR() const;
   virtual double RSI() const;
   virtual long Volume() const;
   virtual double AverageVolume() const;  
   virtual double ADX() const;
   virtual double PlusDI() const;
   virtual double MinusDI() const;
   virtual double DailyATR() const;
   virtual double DATR() const;
   virtual double MA2() const;

};
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXMarketIndicatorProvider::CPHXMarketIndicatorProvider()
{
   m_symbol = "";
   m_timeframe = PERIOD_CURRENT;  
   m_atrHandle = INVALID_HANDLE;
   m_indicatorService = NULL;  
   
   m_rsiHandle = INVALID_HANDLE;
   m_volume = 0;
   m_averageVolume = 0; 
   m_adx = 0.0;
   m_plusDI = 0.0;
   m_minusDI = 0.0;
   m_dailyATR = 0.0;
   m_ma2 = 0.0;
   m_valid = false;
}
//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXMarketIndicatorProvider::Initialize(
   string symbol,
   ENUM_TIMEFRAMES timeframe
)
{
   m_symbol = symbol;
   m_timeframe = timeframe;
   m_atrHandle =
      iATR(
         m_symbol,
         m_timeframe,
         14
      );
   m_rsiHandle =
      iRSI(
         m_symbol,
         m_timeframe,
         14,
         PRICE_CLOSE
      );
   if(
   m_atrHandle == INVALID_HANDLE ||
   m_rsiHandle == INVALID_HANDLE 
)
   {
      return false;
   }
   return true;
}
//+------------------------------------------------------------------+
//| Set Indicator Service                                            |
//+------------------------------------------------------------------+
void CPHXMarketIndicatorProvider::SetIndicatorService(
   CPHXIndicatorServices* service
)
{
   m_indicatorService = service;
}
//+------------------------------------------------------------------+
//| Refresh Indicators                                               |
//+------------------------------------------------------------------+
bool CPHXMarketIndicatorProvider::Refresh()
{
   if(
   m_atrHandle == INVALID_HANDLE ||
   m_rsiHandle == INVALID_HANDLE    
)
      return false;
      
   //--------------------------------------------------
   // ATR
   //--------------------------------------------------

   if(
      CopyBuffer(
         m_atrHandle,
         0,
         0,
         1,
         m_atrBuffer
      ) != 1
   )
   {
      return false;
   }
   //--------------------------------------------------
   // RSI
   //--------------------------------------------------
   if(
      CopyBuffer(
         m_rsiHandle,
         0,
         0,
         1,
         m_rsiBuffer
      ) != 1
   )
      return false;
   //--------------------------------------------------
   // Volume
   //--------------------------------------------------
   MqlRates rates[3];
   int copied =
      CopyRates(
         m_symbol,
         m_timeframe,
         0,
         3,
         rates
      );
   if(copied != 3)
      return false;
   // текущий бар
   m_volume = rates[0].tick_volume;
   // средний объём двух предыдущих баров
   m_averageVolume =
      (
         (double)rates[1].tick_volume +
         (double)rates[2].tick_volume
      )
      / 2.0;
   m_valid = true;
   return true;
}
//+------------------------------------------------------------------+
//| ATR                                                              |
//+------------------------------------------------------------------+
double CPHXMarketIndicatorProvider::ATR() const
{
   if(!m_valid)
      return 0;
   return m_atrBuffer[0];
}
//+------------------------------------------------------------------+
//| RSI                                                              |
//+------------------------------------------------------------------+
double CPHXMarketIndicatorProvider::RSI() const
{
   if(!m_valid)
      return 0;
   return m_rsiBuffer[0];
}
//+------------------------------------------------------------------+
//| Volume                                                           |
//+------------------------------------------------------------------+
long CPHXMarketIndicatorProvider::Volume() const
{
   if(!m_valid)
      return 0;
   return m_volume;
}
//+------------------------------------------------------------------+
//| Average Volume                                                   |
//+------------------------------------------------------------------+
double CPHXMarketIndicatorProvider::AverageVolume() const
{
   if(!m_valid)
      return 0;
   return m_averageVolume;
}
double CPHXMarketIndicatorProvider::ADX() const
{
   return m_adx;
}
double CPHXMarketIndicatorProvider::PlusDI() const
{
   return m_plusDI;
}
double CPHXMarketIndicatorProvider::MinusDI() const
{
   return m_minusDI;
}
double CPHXMarketIndicatorProvider::DailyATR() const
{
   if(m_indicatorService == NULL)
      return 0.0;
   return (*m_indicatorService).DailyATR();
}
double CPHXMarketIndicatorProvider::DATR() const
{
   if(m_indicatorService == NULL)
      return 0.0;
   return (*m_indicatorService).DATR();
}
double CPHXMarketIndicatorProvider::MA2() const
{
   return m_ma2;
}

#endif // PHX_MARKET_INDICATOR_PROVIDER_MQH