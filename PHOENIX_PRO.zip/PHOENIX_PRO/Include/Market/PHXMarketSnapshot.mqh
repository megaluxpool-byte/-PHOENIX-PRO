//+------------------------------------------------------------------+
//|                   PHXMarketSnapshot.mqh                          |
//|                 PHOENIX PRO Trading Framework                    |
//+------------------------------------------------------------------+
#ifndef __PHX_MARKET_SNAPSHOT_MQH__
#define __PHX_MARKET_SNAPSHOT_MQH__

#include "PHXMarketTypes.mqh"


//+------------------------------------------------------------------+
//| Market Snapshot                                                  |
//+------------------------------------------------------------------+
class CPHXMarketSnapshot
{

private:

   string m_symbol;


   bool m_initialized;


   // Price data
   double m_bid;

   double m_ask;

   double m_last;

   // Bar data


   double m_open;

   double m_high;

   double m_low;

   double m_close;

   long m_barIndex;

   // Spread
   double m_spread;

   double m_spreadPoints;


   // Volume
   long m_volume;


   // Tick data
   datetime m_tickTime;


   // Update state
   datetime m_updateTime;



public:

   CPHXMarketSnapshot();

   ~CPHXMarketSnapshot();

   SPHXMarketSnapshot GetSnapshot() const;

public:

   bool Initialize(string symbol);

   void Shutdown();

   void Reset();

   bool IsInitialized() const;



public:

   bool Update(const SPHXTick &tick);

   bool UpdateBar(const SPHXBarData &bar);

public:

   string GetSymbol() const;


   double GetBid() const;

   double GetAsk() const;

   double GetLast() const;


   double GetSpread() const;

   double GetSpreadPoints() const;


   long GetVolume() const;


   datetime GetTickTime() const;

   datetime GetUpdateTime() const;

};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXMarketSnapshot::CPHXMarketSnapshot()
{
   m_symbol = "";

   m_initialized = false;

   m_bid = 0.0;
   m_ask = 0.0;
   m_last = 0.0;
   
   m_open = 0.0;
   m_high = 0.0;
   m_low = 0.0;
   m_close = 0.0;

   m_barIndex = 0;

   m_spread = 0.0;
   m_spreadPoints = 0.0;

   m_volume = 0;

   m_tickTime = 0;

   m_updateTime = 0;
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXMarketSnapshot::~CPHXMarketSnapshot()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXMarketSnapshot::Initialize(string symbol)
{
   if(m_initialized)
      return true;


   if(symbol == "")
      return false;


   m_symbol = symbol;


   Reset();


   m_initialized = true;


   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXMarketSnapshot::Shutdown()
{
   if(!m_initialized)
      return;


   Reset();


   m_symbol = "";


   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXMarketSnapshot::Reset()
{
   m_bid = 0.0;
   m_ask = 0.0;
   m_last = 0.0;

   m_spread = 0.0;
   m_spreadPoints = 0.0;

   m_volume = 0;

   m_tickTime = 0;

   m_updateTime = 0;
}


//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
   bool CPHXMarketSnapshot::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| Update Snapshot                                                  |
//+------------------------------------------------------------------+
   bool CPHXMarketSnapshot::Update(const SPHXTick &tick)
{
   if(!m_initialized)
      return false;


   m_bid = tick.bid;

   m_ask = tick.ask;

   m_last = tick.last;


   m_spread = m_ask - m_bid;

   m_spreadPoints = m_spread / _Point;


   m_volume = tick.volume;


   m_tickTime = tick.time;

   m_updateTime = TimeCurrent();


   return true;
}

//+------------------------------------------------------------------+
//| Update Bar                                                       |
//+------------------------------------------------------------------+

   bool CPHXMarketSnapshot::UpdateBar(
   const SPHXBarData &bar
)
{

   if(!m_initialized)
   return false;


   m_open     = bar.open;
   m_high     = bar.high;
   m_low      = bar.low;
   m_close    = bar.close;
   m_barIndex = bar.barIndex;


   return true;

}
//+------------------------------------------------------------------+
//| Get Snapshot                                                     |
//+------------------------------------------------------------------+
SPHXMarketSnapshot CPHXMarketSnapshot::GetSnapshot() const
{
   SPHXMarketSnapshot snapshot;


   //--------------------------------------------------
   // Symbol
   //--------------------------------------------------

   snapshot.symbol.symbol =
      m_symbol;



   //--------------------------------------------------
   // Tick Data
   //--------------------------------------------------

   snapshot.tick.bid =
      m_bid;


   snapshot.tick.ask =
      m_ask;


   snapshot.tick.last =
      m_last;


   snapshot.tick.volume =
      m_volume;


   snapshot.tick.time =
      m_tickTime;

   //--------------------------------------------------
   // Bar Data
   //--------------------------------------------------

   snapshot.bar.open =
   m_open;

   snapshot.bar.high =
   m_high;

   snapshot.bar.low =
   m_low;

   snapshot.bar.close =
   m_close;

   snapshot.bar.barIndex =
   m_barIndex;

   //--------------------------------------------------
   // Spread Info
   //--------------------------------------------------

   snapshot.spread.currentSpread =
      m_spread;


   snapshot.spread.spreadPoints =
      m_spreadPoints;


   //--------------------------------------------------
   // Session
   //--------------------------------------------------

   // Пока оставляем без заполнения.
   // Данные будут добавлены после подключения
   // CPHXSessionManager.


   return snapshot;
}
//+------------------------------------------------------------------+
//| Get Symbol                                                       |
//+------------------------------------------------------------------+
string CPHXMarketSnapshot::GetSymbol() const
{
   return m_symbol;
}


//+------------------------------------------------------------------+
//| Get Bid                                                           |
//+------------------------------------------------------------------+
double CPHXMarketSnapshot::GetBid() const
{
   return m_bid;
}


//+------------------------------------------------------------------+
//| Get Ask                                                           |
//+------------------------------------------------------------------+
double CPHXMarketSnapshot::GetAsk() const
{
   return m_ask;
}


//+------------------------------------------------------------------+
//| Get Last                                                          |
//+------------------------------------------------------------------+
double CPHXMarketSnapshot::GetLast() const
{
   return m_last;
}


//+------------------------------------------------------------------+
//| Get Spread                                                        |
//+------------------------------------------------------------------+
double CPHXMarketSnapshot::GetSpread() const
{
   return m_spread;
}


//+------------------------------------------------------------------+
//| Get Spread Points                                                 |
//+------------------------------------------------------------------+
double CPHXMarketSnapshot::GetSpreadPoints() const
{
   return m_spreadPoints;
}


//+------------------------------------------------------------------+
//| Get Volume                                                        |
//+------------------------------------------------------------------+
long CPHXMarketSnapshot::GetVolume() const
{
   return m_volume;
}


//+------------------------------------------------------------------+
//| Get Tick Time                                                     |
//+------------------------------------------------------------------+
datetime CPHXMarketSnapshot::GetTickTime() const
{
   return m_tickTime;
}


//+------------------------------------------------------------------+
//| Get Update Time                                                   |
//+------------------------------------------------------------------+
datetime CPHXMarketSnapshot::GetUpdateTime() const
{
   return m_updateTime;
}



#endif // __PHX_MARKET_SNAPSHOT_MQH__