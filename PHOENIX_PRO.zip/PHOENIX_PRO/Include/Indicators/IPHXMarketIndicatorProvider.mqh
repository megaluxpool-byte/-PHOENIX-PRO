#ifndef PHX_MARKET_INDICATOR_PROVIDER_INTERFACE_MQH
#define PHX_MARKET_INDICATOR_PROVIDER_INTERFACE_MQH


//+------------------------------------------------------------------+
//| Market Indicator Provider Interface                              |
//+------------------------------------------------------------------+
class IPHXMarketIndicatorProvider
{

public:

   //--------------------------------------------------
   // Destructor
   //--------------------------------------------------

   virtual ~IPHXMarketIndicatorProvider()
   {
   }


public:
   //--------------------------------------------------
   // ADX
   //--------------------------------------------------
   
   virtual double ADX() const = 0;

   virtual double PlusDI() const = 0;

   virtual double MinusDI() const = 0;
   
   //--------------------------------------------------
   // Volatility
   //--------------------------------------------------

   virtual double ATR() const = 0;
   
   virtual double DailyATR() const = 0;
   
   //--------------------------------------------------
   // Diagnostic ATR
   //--------------------------------------------------

   virtual double DATR() const = 0;

   //--------------------------------------------------
   // Momentum
   //--------------------------------------------------

   virtual double RSI() const = 0;


   //--------------------------------------------------
   // Volume
   //--------------------------------------------------

   virtual long Volume() const = 0;

   virtual double AverageVolume() const = 0;
   
   //--------------------------------------------------
   // MA2
   //--------------------------------------------------
   
   virtual double MA2() const = 0;

};


#endif // PHX_MARKET_INDICATOR_PROVIDER_INTERFACE_MQH