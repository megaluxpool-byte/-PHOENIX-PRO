#ifndef PHX_EMA_PROVIDER_INTERFACE_MQH
#define PHX_EMA_PROVIDER_INTERFACE_MQH


//+------------------------------------------------------------------+
//| EMA Provider Interface                                           |
//+------------------------------------------------------------------+
class IPHXEMAProvider
{

public:

   //--------------------------------------------------
   // Destructor
   //--------------------------------------------------

   virtual ~IPHXEMAProvider()
   {
   }


public:

   //--------------------------------------------------
   // EMA Values
   //--------------------------------------------------

   virtual double EMA20() const = 0;
   
   virtual bool EMA20AtShift(
   int shift,
   double &value
)  const = 0;

   virtual double EMA50() const = 0;

   virtual double EMA100() const = 0;

   virtual double EMA200() const = 0;

};


#endif // PHX_EMA_PROVIDER_INTERFACE_MQH