//+------------------------------------------------------------------+
//|                              PHXADX.mqh                          |
//|                    PHOENIX PRO Trading Framework                 |
//|                                                                  |
//| Description:                                                     |
//|   Average Directional Index service                              |
//+------------------------------------------------------------------+

#ifndef __PHX_ADX_MQH__
#define __PHX_ADX_MQH__


#include "PHXIndicatorTypes.mqh"


//+------------------------------------------------------------------+
//| ADX Service                                                      |
//+------------------------------------------------------------------+
class CPHXADX
{

private:

   int m_handle;


   string m_symbol;


   ENUM_TIMEFRAMES m_timeframe;


   int m_period;


   bool m_initialized;


   SPHXADXValue m_value;



public:

   CPHXADX();

   ~CPHXADX();



public:

   bool Initialize(
      string symbol,
      ENUM_TIMEFRAMES timeframe,
      int period
   );


   void Shutdown();


   void Reset();


   bool Update();


   bool IsInitialized() const;



public:

   double GetADX() const;
   
   double GetPreviousADX() const;

   double GetPlusDI() const;

   double GetMinusDI() const;


   SPHXADXValue GetData() const;

};


//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXADX::CPHXADX()
{
   m_handle = INVALID_HANDLE;

   m_symbol = "";

   m_timeframe = PERIOD_CURRENT;

   m_period = 14;

   m_initialized = false;

   m_value.Reset();
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXADX::~CPHXADX()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXADX::Initialize(
   string symbol,
   ENUM_TIMEFRAMES timeframe,
   int period
)
{
   if(m_initialized)
      return true;


   if(symbol == "")
      return false;


   if(period <= 0)
      return false;


   m_symbol = symbol;

   m_timeframe = timeframe;

   m_period = period;


   m_handle = iADX(
      m_symbol,
      m_timeframe,
      m_period
   );


   if(m_handle == INVALID_HANDLE)
      return false;


   m_value.Reset();


   m_initialized = true;


   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXADX::Shutdown()
{
   if(!m_initialized)
      return;


   if(m_handle != INVALID_HANDLE)
   {
      IndicatorRelease(m_handle);

      m_handle = INVALID_HANDLE;
   }


   Reset();


   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXADX::Reset()
{
   m_value.Reset();
}


//+------------------------------------------------------------------+
//| Update                                                            |
//+------------------------------------------------------------------+
bool CPHXADX::Update()
{
   if(!m_initialized)
      return false;


   double adxBuffer[];

   double plusBuffer[];

   double minusBuffer[];


   ArraySetAsSeries(adxBuffer,true);

   ArraySetAsSeries(plusBuffer,true);

   ArraySetAsSeries(minusBuffer,true);


   if(CopyBuffer(
      m_handle,
      0,
      0,
      1,
      adxBuffer
   ) <= 0)
      return false;


   if(CopyBuffer(
      m_handle,
      1,
      0,
      1,
      plusBuffer
   ) <= 0)
      return false;


   if(CopyBuffer(
      m_handle,
      2,
      0,
      1,
      minusBuffer
   ) <= 0)
      return false;


   m_value.adx = adxBuffer[0];

   m_value.plusDI = plusBuffer[0];

   m_value.minusDI = minusBuffer[0];
   
Print(
   "PHX ADX UPDATE: ",
   "ADX=",
   DoubleToString(m_value.adx,2),
   " +DI=",
   DoubleToString(m_value.plusDI,2),
   " -DI=",
   DoubleToString(m_value.minusDI,2)
);

   m_value.time = TimeCurrent();


   return true;
}


//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXADX::IsInitialized() const
{
   return m_initialized;
}


//+------------------------------------------------------------------+
//| Get ADX                                                           |
//+------------------------------------------------------------------+
double CPHXADX::GetADX() const
{
   if(!m_initialized)
      return 0.0;

   return m_value.adx;
}

//+------------------------------------------------------------------+
//| Get Previous ADX                                                 |
//+------------------------------------------------------------------+
double CPHXADX::GetPreviousADX() const
{
   if(!m_initialized)
      return 0.0;


   double adxBuffer[];


   ArraySetAsSeries(
      adxBuffer,
      true
   );


   if(
      CopyBuffer(
         m_handle,
         0,
         1,
         1,
         adxBuffer
      ) <= 0
   )
      return 0.0;


   return adxBuffer[0];
}
//+------------------------------------------------------------------+
//| Get +DI                                                           |
//+------------------------------------------------------------------+
double CPHXADX::GetPlusDI() const
{
   if(!m_initialized)
      return 0.0;
   
   return m_value.plusDI;
}


//+------------------------------------------------------------------+
//| Get -DI                                                           |
//+------------------------------------------------------------------+
double CPHXADX::GetMinusDI() const
{
   if(!m_initialized)
      return 0.0;
   
   return m_value.minusDI;
}


//+------------------------------------------------------------------+
//| Get Data                                                         |
//+------------------------------------------------------------------+
SPHXADXValue CPHXADX::GetData() const
{
   return m_value;
}


#endif // __PHX_ADX_MQH__