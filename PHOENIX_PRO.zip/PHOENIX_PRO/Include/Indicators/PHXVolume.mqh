//+------------------------------------------------------------------+
//|                       PHXVolumeAnalyzer.mqh                      |
//|                    PHOENIX PRO Trading Framework                 |
//|                                                                  |
//| Description:                                                     |
//|   Volume analysis service                                        |
//+------------------------------------------------------------------+

#ifndef __PHX_VOLUME_ANALYZER_MQH__
#define __PHX_VOLUME_ANALYZER_MQH__


#include "PHXIndicatorTypes.mqh"


//+------------------------------------------------------------------+
//| Volume Analyzer                                                  |
//+------------------------------------------------------------------+
class CPHXVolumeAnalyzer
{

private:

   string m_symbol;


   ENUM_TIMEFRAMES m_timeframe;


   int m_period;


   bool m_initialized;


   SPHXVolumeState m_state;



public:

   CPHXVolumeAnalyzer();

   ~CPHXVolumeAnalyzer();



public:

   bool Initialize(
      string symbol,
      ENUM_TIMEFRAMES timeframe,
      int period
   );


   void Shutdown();


   void Reset();


   bool Update();


   bool IsInitialized() const;



public:

   long GetCurrentVolume() const;


   double GetAverageVolume() const;


   bool IsConfirmed() const;


   SPHXVolumeState GetData() const;

};



//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXVolumeAnalyzer::CPHXVolumeAnalyzer()
{
   m_symbol = "";

   m_timeframe = PERIOD_CURRENT;

   m_period = 2;

   m_initialized = false;


   m_state.Reset();
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXVolumeAnalyzer::~CPHXVolumeAnalyzer()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXVolumeAnalyzer::Initialize(
   string symbol,
   ENUM_TIMEFRAMES timeframe,
   int period
)
{
   if(m_initialized)
      return true;


   if(symbol == "")
      return false;


   if(period <= 0)
      return false;


   m_symbol = symbol;

   m_timeframe = timeframe;

   m_period = period;


   m_state.Reset();


   m_initialized = true;


   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXVolumeAnalyzer::Shutdown()
{
   if(!m_initialized)
      return;


   Reset();


   m_symbol = "";


   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXVolumeAnalyzer::Reset()
{
   m_state.Reset();
}


//+------------------------------------------------------------------+
//| Update                                                            |
//+------------------------------------------------------------------+
bool CPHXVolumeAnalyzer::Update()
{
   if(!m_initialized)
      return false;


   MqlRates rates[];


   ArraySetAsSeries(
      rates,
      true
   );


   int copied = CopyRates(
      m_symbol,
      m_timeframe,
      0,
      m_period + 1,
      rates
   );


   if(copied <= m_period)
      return false;



   long currentVolume = rates[0].tick_volume;


   double average = 0.0;


   for(int i = 1; i <= m_period; i++)
   {
      average += rates[i].tick_volume;
   }


   average /= m_period;



   m_state.currentVolume = currentVolume;

   m_state.averageVolume = average;


   m_state.confirmed =
      (currentVolume > average);


   m_state.time = TimeCurrent();



   return true;
}


//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXVolumeAnalyzer::IsInitialized() const
{
   return m_initialized;
}


//+------------------------------------------------------------------+
//| Current Volume                                                   |
//+------------------------------------------------------------------+
long CPHXVolumeAnalyzer::GetCurrentVolume() const
{
   return m_state.currentVolume;
}


//+------------------------------------------------------------------+
//| Average Volume                                                   |
//+------------------------------------------------------------------+
double CPHXVolumeAnalyzer::GetAverageVolume() const
{
   return m_state.averageVolume;
}


//+------------------------------------------------------------------+
//| Confirmation                                                     |
//+------------------------------------------------------------------+
bool CPHXVolumeAnalyzer::IsConfirmed() const
{
   return m_state.confirmed;
}


//+------------------------------------------------------------------+
//| Data                                                             |
//+------------------------------------------------------------------+
SPHXVolumeState CPHXVolumeAnalyzer::GetData() const
{
   return m_state;
}



#endif // __PHX_VOLUME_ANALYZER_MQH__