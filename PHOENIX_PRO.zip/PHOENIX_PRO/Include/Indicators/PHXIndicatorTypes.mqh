//+------------------------------------------------------------------+
//|                         PHXIndicatorTypes.mqh                    |
//|                    PHOENIX PRO Trading Framework                 |
//|                                                                  |
//| Description:                                                     |
//|   Indicator data structures                                     |
//+------------------------------------------------------------------+

#ifndef __PHX_INDICATOR_TYPES_MQH__
#define __PHX_INDICATOR_TYPES_MQH__


//+------------------------------------------------------------------+
//| ATR Value                                                        |
//+------------------------------------------------------------------+
struct SPHXATRValue
{
   double value;

   datetime time;


   void Reset()
   {
      value = 0.0;

      time = 0;
   }
};


//+------------------------------------------------------------------+
//| Moving Average Value                                             |
//+------------------------------------------------------------------+
struct SPHXMAValue
{
   double value;

   datetime time;


   void Reset()
   {
      value = 0.0;

      time = 0;
   }
};


//+------------------------------------------------------------------+
//| RSI Value                                                        |
//+------------------------------------------------------------------+
struct SPHXRSIValue
{
   double value;

   datetime time;


   void Reset()
   {
      value = 0.0;

      time = 0;
   }
};


//+------------------------------------------------------------------+
//| ADX Value                                                        |
//+------------------------------------------------------------------+
struct SPHXADXValue
{
   double adx;

   double plusDI;

   double minusDI;


   datetime time;


   void Reset()
   {
      adx = 0.0;

      plusDI = 0.0;

      minusDI = 0.0;


      time = 0;
   }
};


//+------------------------------------------------------------------+
//| Volume State                                                     |
//+------------------------------------------------------------------+
struct SPHXVolumeState
{
   long currentVolume;

   double averageVolume;


   bool confirmed;


   datetime time;


   void Reset()
   {
      currentVolume = 0;

      averageVolume = 0.0;


      confirmed = false;


      time = 0;
   }
};


//+------------------------------------------------------------------+
//| Indicator Snapshot                                               |
//+------------------------------------------------------------------+
struct SPHXIndicatorSnapshot
{
   SPHXATRValue atr;

   SPHXMAValue ma;

   SPHXRSIValue rsi;

   SPHXADXValue adx;

   SPHXVolumeState volume;


   void Reset()
   {
      atr.Reset();

      ma.Reset();

      rsi.Reset();

      adx.Reset();

      volume.Reset();
   }
};


#endif // __PHX_INDICATOR_TYPES_MQH__