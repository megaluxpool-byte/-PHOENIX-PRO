#ifndef __PHX_ATR_ENERGY_MQH__
#define __PHX_ATR_ENERGY_MQH__

//+------------------------------------------------------------------+
//| PHX ATR Energy                                                   |
//|                                                                  |
//| Trading energy is calculated ONLY from D1 data.                  |
//| Working chart timeframe does not participate in the decision.    |
//+------------------------------------------------------------------+

class CPHXATREnergy
{

private:

   //--------------------------------------------------
   // Minimum remaining D1 energy required for entry
   //--------------------------------------------------
   double m_minRemainingRatio;
   //--------------------------------------------------
   // Last calculated values
   //--------------------------------------------------
   double m_technicalDailyATR;
   double m_dayOpen;
   double m_dayHigh;
   double m_dayLow;
   double m_currentDailyRange;
   double m_usedATR;
   double m_usedRatio;
   double m_remainingATR;
   double m_remainingRatio;
   bool   m_allowed;

public:

   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------
   CPHXATREnergy()
{
   m_minRemainingRatio = 0.30;
   Reset();

   Print(
      "PHX D1 ENERGY VERIFY BUILD: PHXATREnergy #111.2"
   );
}
   //--------------------------------------------------
   // Reset
   //--------------------------------------------------
   void Reset()
   {
      m_technicalDailyATR = 0.0;
      m_dayOpen = 0.0;
      m_dayHigh = 0.0;
      m_dayLow  = 0.0;
      m_currentDailyRange = 0.0;
      m_usedATR   = 0.0;
      m_usedRatio = 0.0;
      m_remainingATR   = 0.0;
      m_remainingRatio = 0.0;
      m_allowed = false;
   }
   //--------------------------------------------------
   // D1 Energy Check
   //
   // technicalDailyATR:
   // PHX technical D1 ATR calculated from previous
   // completed daily candles.
   //--------------------------------------------------
   bool IsEnergyEnough(
      double technicalDailyATR
   )
   {
   Print(
   "PHX D1 VERIFY ENTER: ",
   "Symbol=", _Symbol,
   " TechnicalATR=",
   DoubleToString(
      technicalDailyATR,
      _Digits
   )
);
      //--------------------------------------------------
      // Technical D1 ATR protection
      //--------------------------------------------------
      if(technicalDailyATR <= 0.0)
      {
         m_allowed = false;
         Print(
            "PHX D1 ENERGY: Technical DailyATR invalid"
         );
         return false;
      }
      //--------------------------------------------------
      // Read CURRENT D1 candle
      //--------------------------------------------------
      MqlRates daily[];
      ArraySetAsSeries(
         daily,
         true
      );
      int copied =
         CopyRates(
            _Symbol,
            PERIOD_D1,
            0,
            1,
            daily
         );
      if(copied != 1)
      {
         m_allowed = false;

         Print(
            "PHX D1 ENERGY: Current D1 candle unavailable"
         );
         return false;
      }
      //--------------------------------------------------
      // Current D1 data
      //--------------------------------------------------
      m_technicalDailyATR =
         technicalDailyATR;

      m_dayOpen =
         daily[0].open;

      m_dayHigh =
         daily[0].high;

      m_dayLow =
         daily[0].low;
      //--------------------------------------------------
      // Current daily range
      //
      // IMPORTANT:
      // This is independent from M1/M5/M30/H1.
      //--------------------------------------------------
      m_currentDailyRange =
         m_dayHigh -
         m_dayLow;
      if(m_currentDailyRange < 0.0)
      {
         m_allowed = false;
         Print(
            "PHX D1 ENERGY: Invalid current daily range"
         );
         return false;
      }
      //--------------------------------------------------
      // Used D1 ATR
      //--------------------------------------------------
      m_usedATR =
         m_currentDailyRange;
      m_usedRatio =
         m_usedATR /
         m_technicalDailyATR;
      //--------------------------------------------------
      // Remaining D1 ATR
      //--------------------------------------------------
      m_remainingATR =
         m_technicalDailyATR -
         m_currentDailyRange;
      //--------------------------------------------------
      // Daily range may exceed Technical DailyATR
      //--------------------------------------------------
      if(m_remainingATR < 0.0)
      {
         m_remainingATR = 0.0;
      }
      m_remainingRatio =
         m_remainingATR /
         m_technicalDailyATR;
      //--------------------------------------------------
// Final trading permission
//--------------------------------------------------
m_allowed =
   (
      m_remainingRatio >=
      m_minRemainingRatio
   );

//--------------------------------------------------
// TEMPORARY D1 ENERGY VERIFICATION
//
// Print only:
// 1. on first calculation
// 2. when D1 candle changes
// 3. when D1 High changes
// 4. when D1 Low changes
//--------------------------------------------------
static datetime diagnosticD1Time = 0;
static double   diagnosticD1High = 0.0;
static double   diagnosticD1Low  = 0.0;

bool d1Changed =
   (
      diagnosticD1Time != daily[0].time ||
      diagnosticD1High != daily[0].high ||
      diagnosticD1Low  != daily[0].low
   );

if(d1Changed)
{
   double currentBid =
      SymbolInfoDouble(
         _Symbol,
         SYMBOL_BID
      );

   Print(
      "PHX D1 VERIFY: ",
      "Symbol=", _Symbol,
      " D1Time=",
      TimeToString(
         daily[0].time,
         TIME_DATE | TIME_MINUTES
      ),
      " Open=",
      DoubleToString(
         daily[0].open,
         _Digits
      ),
      " High=",
      DoubleToString(
         daily[0].high,
         _Digits
      ),
      " Low=",
      DoubleToString(
         daily[0].low,
         _Digits
      ),
      " Close=",
      DoubleToString(
         daily[0].close,
         _Digits
      ),
      " Bid=",
      DoubleToString(
         currentBid,
         _Digits
      ),
      " Range=",
      DoubleToString(
         m_currentDailyRange,
         _Digits
      ),
      " TechnicalATR=",
      DoubleToString(
         m_technicalDailyATR,
         _Digits
      ),
      " EnergyLeft=",
      DoubleToString(
         m_remainingRatio * 100.0,
         2
      ),
      "%"
   );

   diagnosticD1Time =
      daily[0].time;

   diagnosticD1High =
      daily[0].high;

   diagnosticD1Low =
      daily[0].low;
}

return m_allowed;
      //--------------------------------------------------
      // Full diagnostic report
      //--------------------------------------------------
       return m_allowed;
   }
   //--------------------------------------------------
   // Local ATR Diagnostics
   //
   // IMPORTANT:
   // M30/H1 ratio has NO trading authority.
   //--------------------------------------------------
void PrintLocalATRDiagnostics(
   double currentATR,
   double baseATR
)
{
}
   //--------------------------------------------------
   // Minimum Remaining Energy
   //--------------------------------------------------
   void SetMinimumRemainingRatio(
      double ratio
   )
   {
      if(
         ratio < 0.0 ||
         ratio > 1.0
      )
      {
         return;
      }

      m_minRemainingRatio =
         ratio;
   }
   //--------------------------------------------------
   // Accessors
   //--------------------------------------------------
   double GetTechnicalDailyATR() const
   {
      return m_technicalDailyATR;
   }

   double GetDayOpen() const
   {
      return m_dayOpen;
   }

   double GetDayHigh() const
   {
      return m_dayHigh;
   }

   double GetDayLow() const
   {
      return m_dayLow;
   }

   double GetCurrentDailyRange() const
   {
      return m_currentDailyRange;
   }

   double GetUsedRatio() const
   {
      return m_usedRatio;
   }

   double GetRemainingATR() const
   {
      return m_remainingATR;
   }

   double GetRemainingRatio() const
   {
      return m_remainingRatio;
   }

   bool IsAllowed() const
   {
      return m_allowed;
   }
};

#endif // __PHX_ATR_ENERGY_MQH__