//+------------------------------------------------------------------+
//|                              PHXRSI.mqh                          |
//|                    PHOENIX PRO Trading Framework                 |
//|                                                                  |
//| Description:                                                     |
//|   Relative Strength Index service                                |
//+------------------------------------------------------------------+

#ifndef __PHX_RSI_MQH__
#define __PHX_RSI_MQH__

#include "PHXIndicatorTypes.mqh"

//+------------------------------------------------------------------+
//| RSI Service                                                      |
//+------------------------------------------------------------------+
class CPHXRSI
{
private:
   int m_handle;
   string m_symbol;
   ENUM_TIMEFRAMES m_timeframe;
   int m_period;
   ENUM_APPLIED_PRICE m_price;

   bool m_initialized;
   SPHXRSIValue m_value;
   double m_previousValue;
public:

   CPHXRSI();

   ~CPHXRSI();

public:
   bool Initialize(
      string symbol,
      ENUM_TIMEFRAMES timeframe,
      int period,
      ENUM_APPLIED_PRICE price
   );
   void Shutdown();
   void Reset();
   bool Update();
   bool IsInitialized() const;
public:
   double GetValue() const;
   double GetPreviousValue() const;
   SPHXRSIValue GetData() const;
};
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXRSI::CPHXRSI()
{
   m_handle = INVALID_HANDLE;
   m_symbol = "";
   m_timeframe = PERIOD_CURRENT;
   m_period = 14;
   m_price = PRICE_CLOSE;
   m_initialized = false;
   m_previousValue = 0.0;
   m_value.Reset();
}
//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXRSI::~CPHXRSI()
{
   Shutdown();
}
//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXRSI::Initialize(
   string symbol,
   ENUM_TIMEFRAMES timeframe,
   int period,
   ENUM_APPLIED_PRICE price
)
{
   if(m_initialized)
      return true;
   if(symbol == "")
      return false;
   if(period <= 0)
      return false;
   m_symbol = symbol;
   m_timeframe = timeframe;
   m_period = period;
   m_price = price;
   m_handle = iRSI(
      m_symbol,
      m_timeframe,
      m_period,
      m_price
   );
   if(m_handle == INVALID_HANDLE)
      return false;
   m_value.Reset();
   m_initialized = true;
   return true;
}
//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
   void CPHXRSI::Shutdown()
{
   if(!m_initialized)
      return;
   if(m_handle != INVALID_HANDLE)
   {
      IndicatorRelease(m_handle);
      m_handle = INVALID_HANDLE;
   }
   Reset();
   m_initialized = false;
}
//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
   void CPHXRSI::Reset()
{
   m_previousValue = 0.0;

   m_value.Reset();
}
//+------------------------------------------------------------------+
//| Update                                                            |
//+------------------------------------------------------------------+
   bool CPHXRSI::Update()
{
   if(!m_initialized)
      return false;
   double buffer[];
   ArraySetAsSeries(buffer,true);
   if(CopyBuffer(
      m_handle,
      0,
      0,
      1,
      buffer
   ) <= 0)
   {
      return false;
   }
   m_previousValue = m_value.value;
   m_value.value = buffer[0];
   m_value.time = TimeCurrent();
   return true;
}
//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXRSI::IsInitialized() const
{
   return m_initialized;
}
//+------------------------------------------------------------------+
//| Get Value                                                        |
//+------------------------------------------------------------------+
double CPHXRSI::GetValue() const
{
   if(!m_initialized)
      return 0.0;
   return m_value.value;
}
//+------------------------------------------------------------------+
//| Get Previous Value                                               |
//+------------------------------------------------------------------+
double CPHXRSI::GetPreviousValue() const
{
   if(!m_initialized)
      return 0.0;
   return m_previousValue;
}
//+------------------------------------------------------------------+
//| Get Data                                                         |
//+------------------------------------------------------------------+
SPHXRSIValue CPHXRSI::GetData() const
{
   return m_value;
}

#endif // __PHX_RSI_MQH__