//+------------------------------------------------------------------+
//| PHXMTFAlignment.mqh                                              |
//| PHOENIX PRO                                                      |
//| Multi-Timeframe Alignment                                       |
//+------------------------------------------------------------------+
#ifndef __PHX_MTF_ALIGNMENT_MQH__
#define __PHX_MTF_ALIGNMENT_MQH__

//+------------------------------------------------------------------+
//| Direction                                                        |
//+------------------------------------------------------------------+
enum ENUM_PHX_MTF_DIRECTION
{
   PHX_MTF_NONE = 0,
   PHX_MTF_BUY  = 1,
   PHX_MTF_SELL = -1
};


//+------------------------------------------------------------------+
//| Result                                                           |
//+------------------------------------------------------------------+
struct SPHXMTFAlignmentResult
{
   int HigherTFScore;
   int SignalTFScore;
   int EntryTFScore;

   int TotalScore;

   int HigherTrend;
   int SignalTrend;
   int EntryTrend;

   double EntryEMASlope;
   double EntryEMADistance;


   void Reset()
   {
      HigherTFScore = 0;
      SignalTFScore = 0;
      EntryTFScore  = 0;

      TotalScore = 0;

      HigherTrend = 0;
      SignalTrend = 0;
      EntryTrend  = 0;

      EntryEMASlope = 0.0;
      EntryEMADistance = 0.0;
   }
};


//+------------------------------------------------------------------+
//| MTF Alignment                                                    |
//+------------------------------------------------------------------+
class CPHXMTFAlignment
{

private:

   int m_fastEMA;
   int m_slowEMA;

   int m_slopeBars;


   //---------------------------------------------------------------
   // EMA value
   //---------------------------------------------------------------
double EMAValue(
   string symbol,
   ENUM_TIMEFRAMES tf,
   int period,
   int shift
)
{
   int handle =
      iMA(
         symbol,
         tf,
         period,
         0,
         MODE_EMA,
         PRICE_CLOSE
      );

   if(handle == INVALID_HANDLE)
      return 0.0;

   double buffer[];

   ArraySetAsSeries(
      buffer,
      true
   );

   if(
      CopyBuffer(
         handle,
         0,
         shift,
         1,
         buffer
      ) <= 0
   )
   {
      return 0.0;
   }

   return buffer[0];
}

   //---------------------------------------------------------------
   // Trend calculation
   //---------------------------------------------------------------
   int CalculateTrend(
      string symbol,
      ENUM_TIMEFRAMES tf
   )
   {
      double fast =
         EMAValue(
            symbol,
            tf,
            m_fastEMA,
            0
         );


      double slow =
         EMAValue(
            symbol,
            tf,
            m_slowEMA,
            0
         );


      if(fast > slow)
         return 1;


      if(fast < slow)
         return -1;


      return 0;
   }


   //---------------------------------------------------------------
   // EMA slope
   //---------------------------------------------------------------
   double CalculateSlope(
      string symbol,
      ENUM_TIMEFRAMES tf
   )
   {
      double current =
         EMAValue(
            symbol,
            tf,
            m_fastEMA,
            0
         );


      double previous =
         EMAValue(
            symbol,
            tf,
            m_fastEMA,
            m_slopeBars
         );


      if(current == 0.0 || previous == 0.0)
         return 0.0;


      return
         (current - previous) /
         m_slopeBars;
   }


public:


   //---------------------------------------------------------------
   // Constructor
   //---------------------------------------------------------------
   CPHXMTFAlignment()
   {
      m_fastEMA = 20;
      m_slowEMA = 50;

      m_slopeBars = 3;
   }


   //---------------------------------------------------------------
   // Configuration
   //---------------------------------------------------------------
   void Configure(
      int fastEMA,
      int slowEMA,
      int slopeBars
   )
   {
      m_fastEMA = fastEMA;
      m_slowEMA = slowEMA;

      m_slopeBars = slopeBars;
   }


   //---------------------------------------------------------------
   // Calculate
   //---------------------------------------------------------------
   bool Calculate(
      string symbol,
      ENUM_TIMEFRAMES higherTF,
      ENUM_TIMEFRAMES signalTF,
      ENUM_TIMEFRAMES entryTF,
      ENUM_PHX_MTF_DIRECTION direction,
      SPHXMTFAlignmentResult &result
   )
   {

      result.Reset();


      result.HigherTrend =
         CalculateTrend(
            symbol,
            higherTF
         );


      result.SignalTrend =
         CalculateTrend(
            symbol,
            signalTF
         );


      result.EntryTrend =
         CalculateTrend(
            symbol,
            entryTF
         );


      result.EntryEMASlope =
         CalculateSlope(
            symbol,
            entryTF
         );


      double fast =
         EMAValue(
            symbol,
            entryTF,
            m_fastEMA,
            0
         );


      double slow =
         EMAValue(
            symbol,
            entryTF,
            m_slowEMA,
            0
         );


      result.EntryEMADistance =
         fast - slow;


      int wanted =
         (int)direction;


      //-----------------------------------------------------------
      // Higher TF
      //-----------------------------------------------------------
      if(result.HigherTrend == wanted)
         result.HigherTFScore = 2;
      else
      if(result.HigherTrend != 0)
         result.HigherTFScore = -2;


      //-----------------------------------------------------------
      // Signal TF
      //-----------------------------------------------------------
      if(result.SignalTrend == wanted)
         result.SignalTFScore = 2;
      else
      if(result.SignalTrend != 0)
         result.SignalTFScore = -1;


      //-----------------------------------------------------------
      // Entry TF
      //-----------------------------------------------------------
      if(result.EntryTrend == wanted)
      {
         if(
            (direction == PHX_MTF_BUY &&
             result.EntryEMASlope > 0)

            ||

            (direction == PHX_MTF_SELL &&
             result.EntryEMASlope < 0)
         )
         {
            result.EntryTFScore = 1;
         }
         else
         {
            result.EntryTFScore = 0;
         }
      }
      else
      if(result.EntryTrend != 0)
      {
         result.EntryTFScore = -2;
      }


      result.TotalScore =
         result.HigherTFScore +
         result.SignalTFScore +
         result.EntryTFScore;


      return true;
   }

};

//+------------------------------------------------------------------+

#endif