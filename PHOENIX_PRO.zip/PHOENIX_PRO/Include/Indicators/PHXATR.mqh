//+------------------------------------------------------------------+
//|                              PHXATR.mqh                          |
//|                    PHOENIX PRO Trading Framework                 |
//|                                                                  |
//| Description:                                                     |
//|   Average True Range indicator service                           |
//+------------------------------------------------------------------+

#ifndef __PHX_ATR_MQH__
#define __PHX_ATR_MQH__


#include "PHXIndicatorTypes.mqh"


//+------------------------------------------------------------------+
//| ATR Service                                                      |
//+------------------------------------------------------------------+
class CPHXATR
{

private:

   int m_handle;


   string m_symbol;


   ENUM_TIMEFRAMES m_timeframe;


   int m_period;
//--------------------------------------------------
// Adaptive ATR Settings
//--------------------------------------------------

   int m_adaptivePeriod;

   bool m_initialized;
   
   bool m_adaptiveDailyMode;
   
//--------------------------------------------------
// ATR Values
//--------------------------------------------------

   double m_datr;        // Classic ATR(14) for diagnostics

   double m_dailyATR;    // Adaptive Daily ATR for trading

   double m_previousValue;

   SPHXATRValue m_value;
   
   datetime m_lastBarTime; 
   
   



public:

   CPHXATR();

   ~CPHXATR();



public:

   bool Initialize(
      string symbol,
      ENUM_TIMEFRAMES timeframe,
      int period
   );


   void Shutdown();


   void Reset();


   bool Update();


   bool IsInitialized() const;



public:

   double GetValue() const;

   double GetPreviousValue() const;
   
   SPHXATRValue GetData() const;
   
   double DATR() const;
   
   double CalculateAdaptiveDailyATR();

};


//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXATR::CPHXATR()
{
   m_previousValue = 0.0;
   
   m_handle = INVALID_HANDLE;

   m_symbol = "";

   m_timeframe = PERIOD_CURRENT;

   m_period = 14;

   m_adaptivePeriod = 5;

   m_datr = 0.0;

   m_dailyATR = 0.0;

   m_initialized = false;
   
   m_adaptiveDailyMode = false;

   m_value.Reset();
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXATR::~CPHXATR()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXATR::Initialize(
   string symbol,
   ENUM_TIMEFRAMES timeframe,
   int period
)
{
   if(m_initialized)
      return true;


   if(symbol == "")
      return false;


   if(period <= 0)
      return false;


   m_symbol = symbol;

   m_timeframe = timeframe;

   m_period = period;
   
   m_adaptiveDailyMode =
(
   m_timeframe == PERIOD_D1
);


   m_handle = iATR(
      m_symbol,
      m_timeframe,
      m_period
   );
   
   m_dailyATR = 0.0;
   
   Print(
   "PHX ATR HANDLE: ",
   "TF=",
   EnumToString(m_timeframe),
   " Handle=",
   m_handle,
   " Error=",
   GetLastError()
);
   
if(m_handle == INVALID_HANDLE)

{
Print(
   "PHX ATR HANDLE INVALID: TF=",
   EnumToString(m_timeframe)
);
   Print(
      "PHX ATR HANDLE FAILED: ",
      "TF=",
      EnumToString(m_timeframe),
      " Error=",
      GetLastError()
   );

   return false;
}   
   
Print(
   "PHX ATR INIT: Symbol=",
   m_symbol,
   " TF=",
   EnumToString(m_timeframe),
   " Period=",
   m_period
);

ResetLastError();
m_value.Reset();

m_initialized = true;

   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXATR::Shutdown()
{
   if(!m_initialized)
      return;


   if(m_handle != INVALID_HANDLE)
   {
      IndicatorRelease(m_handle);

      m_handle = INVALID_HANDLE;
   }


   Reset();


   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXATR::Reset()
{
   m_previousValue = 0.0;

   m_datr = 0.0;

   m_dailyATR = 0.0;

   m_lastBarTime = 0;

   m_value.Reset();
}


//+------------------------------------------------------------------+
//| Update                                                            |
//+------------------------------------------------------------------+
bool CPHXATR::Update()
{
   if(!m_initialized)
      return false;
      
      if(m_adaptiveDailyMode)
{

   //--------------------------------------------------
   // Classic ATR(14) for diagnostics
   //--------------------------------------------------

   double buffer[];


   ArraySetAsSeries(
      buffer,
      true
   );


   int copied =
      CopyBuffer(
         m_handle,
         0,
         1,
         1,
         buffer
      );


   if(copied > 0)
   {
      m_datr = buffer[0];
   }



   //--------------------------------------------------
   // Adaptive Daily ATR - working value
   //--------------------------------------------------
   double adaptiveATR =
      CalculateAdaptiveDailyATR();

   if(adaptiveATR <= 0)
      return false;

   m_previousValue =
      m_value.value;

   m_dailyATR =
   adaptiveATR;

   m_value.value =
   m_dailyATR;

   m_value.time =
      TimeCurrent();

   return true;
}
   double buffer[];
   ArraySetAsSeries(buffer,true);
int calculated =
   BarsCalculated(m_handle);

if(calculated <= 0)
{
   Print(
      "PHX ATR Waiting History: TF=",
      EnumToString(m_timeframe),
      " BarsCalculated=",
      calculated
   );

   if(m_value.value > 0)
   {
      Print(
         "PHX ATR Using Previous Value TF=",
         EnumToString(m_timeframe)
      );
      return true;
   }

   return true;
}
   int copied =
   CopyBuffer(
      m_handle,
      0,
      1,
      1,
      buffer
   );

if(copied <= 0)
{
   Print(
      "PHX ATR CopyBuffer FAILED: TF=",
      EnumToString(m_timeframe),
      " Error=",
      GetLastError()
   );

   return false;
}

   m_previousValue = m_value.value;
   
   m_value.value = buffer[0]; 
   Print(
   "PHX ATR UPDATE: TF=",
   EnumToString(m_timeframe),
   " Value=",
   DoubleToString(m_value.value,5)
);
   m_value.time = TimeCurrent();

   return true;
}
//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXATR::IsInitialized() const
{
   return m_initialized;
}


//+------------------------------------------------------------------+
//| Get Value                                                        |
//+------------------------------------------------------------------+
double CPHXATR::GetValue() const
{
   if(!m_initialized)
      return 0.0;

   return m_value.value;
}


//+------------------------------------------------------------------+
//| Get Data                                                         |
//+------------------------------------------------------------------+
SPHXATRValue CPHXATR::GetData() const
{
   return m_value;
}


double CPHXATR::GetPreviousValue() const
{
   return m_previousValue;
}
//+------------------------------------------------------------------+
//| DATR                                               |
//+------------------------------------------------------------------+
double CPHXATR::DATR() const
{
   return m_datr;
}
//+------------------------------------------------------------------+
//| Adaptive Daily ATR                                               |
//+------------------------------------------------------------------+
double CPHXATR::CalculateAdaptiveDailyATR()
{
   //--------------------------------------------------
   // Validation
   //--------------------------------------------------

   if(m_adaptivePeriod < 3)
      return 0.0;


   //--------------------------------------------------
   // Need one additional bar for Previous Close
   //--------------------------------------------------

   int requiredBars =
      m_adaptivePeriod + 1;


   MqlRates rates[];

   ArraySetAsSeries(
      rates,
      true
   );


   int copied =
      CopyRates(
         m_symbol,
         PERIOD_D1,
         1,
         requiredBars,
         rates
      );


   if(copied < requiredBars)
   {
      Print(
         "PHX Adaptive ATR: Not enough D1 history. Required=",
         requiredBars,
         " Copied=",
         copied
      );

      return 0.0;
   }


   //--------------------------------------------------
   // True Range values
   //--------------------------------------------------

   double values[];

   ArrayResize(
      values,
      m_adaptivePeriod
   );


   double sum = 0.0;

   double minValue = DBL_MAX;

   double maxValue = -DBL_MAX;


   for(int i = 0; i < m_adaptivePeriod; i++)
   {

      double previousClose =
         rates[i + 1].close;


      double highLow =
         rates[i].high -
         rates[i].low;


      double highClose =
         MathAbs(
            rates[i].high -
            previousClose
         );

      double lowClose =
         MathAbs(
            rates[i].low -
            previousClose
         );

      double trueRange =
         MathMax(
            highLow,
            MathMax(
               highClose,
               lowClose
            )
         );

      values[i] =
         trueRange;

      sum +=
         trueRange;

      if(trueRange < minValue)
         minValue = trueRange;

      if(trueRange > maxValue)
         maxValue = trueRange; 

   }


   //--------------------------------------------------
   // Remove one minimum and one maximum value
   //--------------------------------------------------

   double filteredSum =
      sum -
      minValue -
      maxValue;


   int filteredCount =
      m_adaptivePeriod - 2;


   if(filteredCount <= 0)
      return 0.0;


   //--------------------------------------------------
   // Final Adaptive Daily ATR
   //--------------------------------------------------

   double result =
      filteredSum /
      filteredCount;
   return result;
}

#endif // __PHX_ATR_MQH__