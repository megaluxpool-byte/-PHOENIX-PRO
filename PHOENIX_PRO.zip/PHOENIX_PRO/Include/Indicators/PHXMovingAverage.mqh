//+------------------------------------------------------------------+
//|                      PHXMovingAverage.mqh                        |
//|                    PHOENIX PRO Trading Framework                 |
//|                                                                  |
//| Description:                                                     |
//|   Moving Average indicator service                              |
//+------------------------------------------------------------------+

#ifndef __PHX_MOVING_AVERAGE_MQH__
#define __PHX_MOVING_AVERAGE_MQH__


#include "PHXIndicatorTypes.mqh"


//+------------------------------------------------------------------+
//| Moving Average Service                                           |
//+------------------------------------------------------------------+
class CPHXMovingAverage
{

private:

   int m_handle;


   string m_symbol;


   ENUM_TIMEFRAMES m_timeframe;


   int m_period;


   ENUM_MA_METHOD m_method;


   ENUM_APPLIED_PRICE m_price;


   bool m_initialized;


   SPHXMAValue m_value;



public:

   CPHXMovingAverage();

   ~CPHXMovingAverage();



public:

   bool Initialize(
      string symbol,
      ENUM_TIMEFRAMES timeframe,
      int period,
      ENUM_MA_METHOD method,
      ENUM_APPLIED_PRICE price
   );


   void Shutdown();


   void Reset();


   bool Update();


   bool IsInitialized() const;



public:

   double GetValue() const;


   SPHXMAValue GetData() const;

};


//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXMovingAverage::CPHXMovingAverage()
{
   m_handle = INVALID_HANDLE;

   m_symbol = "";

   m_timeframe = PERIOD_CURRENT;

   m_period = 0;

   m_method = MODE_SMA;

   m_price = PRICE_CLOSE;

   m_initialized = false;

   m_value.Reset();
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXMovingAverage::~CPHXMovingAverage()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXMovingAverage::Initialize(
   string symbol,
   ENUM_TIMEFRAMES timeframe,
   int period,
   ENUM_MA_METHOD method,
   ENUM_APPLIED_PRICE price
)
{
   if(m_initialized)
      return true;


   if(symbol == "")
      return false;


   if(period <= 0)
      return false;


   m_symbol = symbol;

   m_timeframe = timeframe;

   m_period = period;

   m_method = method;

   m_price = price;


   m_handle = iMA(
      m_symbol,
      m_timeframe,
      m_period,
      0,
      m_method,
      m_price
   );


   if(m_handle == INVALID_HANDLE)
      return false;


   m_value.Reset();


   m_initialized = true;


   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXMovingAverage::Shutdown()
{
   if(!m_initialized)
      return;


   if(m_handle != INVALID_HANDLE)
   {
      IndicatorRelease(m_handle);

      m_handle = INVALID_HANDLE;
   }


   Reset();


   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXMovingAverage::Reset()
{
   m_value.Reset();
}


//+------------------------------------------------------------------+
//| Update                                                            |
//+------------------------------------------------------------------+
bool CPHXMovingAverage::Update()
{
   if(!m_initialized)
      return false;


   double buffer[];


   ArraySetAsSeries(buffer,true);


   if(CopyBuffer(
      m_handle,
      0,
      0,
      1,
      buffer
   ) <= 0)
   {
      return false;
   }


   m_value.value = buffer[0];

   m_value.time = TimeCurrent();


   return true;
}


//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXMovingAverage::IsInitialized() const
{
   return m_initialized;
}


//+------------------------------------------------------------------+
//| Get Value                                                        |
//+------------------------------------------------------------------+
double CPHXMovingAverage::GetValue() const
{
   if(!m_initialized)
      return 0.0;

   return m_value.value;
}


//+------------------------------------------------------------------+
//| Get Data                                                         |
//+------------------------------------------------------------------+
SPHXMAValue CPHXMovingAverage::GetData() const
{
   return m_value;
}


#endif // __PHX_MOVING_AVERAGE_MQH__