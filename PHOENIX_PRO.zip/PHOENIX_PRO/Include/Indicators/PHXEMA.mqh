//+------------------------------------------------------------------+
//|                      PHXEMovingAverage.mqh                        |
//|                    PHOENIX PRO Trading Framework                 |
//|                                                                  |
//| Description:                                                     |
//|   Exponential Moving Average indicator service                              |
//+------------------------------------------------------------------+

#ifndef __PHX_EMA_MQH__
#define __PHX_EMA_MQH__

//+------------------------------------------------------------------+
//| Universal EMA Service                                            |
//+------------------------------------------------------------------+
class CPHXEMA
{

private:

   //--------------------------------------------------
   // Indicator Handle
   //--------------------------------------------------

   int m_handle;

   //--------------------------------------------------
   // EMA Period
   //--------------------------------------------------

   int m_period;

   //--------------------------------------------------
   // Working Timeframe
   //--------------------------------------------------

   ENUM_TIMEFRAMES m_timeframe;

   //--------------------------------------------------
   // Applied Price
   //--------------------------------------------------

   ENUM_APPLIED_PRICE m_price;

   //--------------------------------------------------
   // Current EMA
   //--------------------------------------------------

   double m_current;

   //--------------------------------------------------
   // Previous EMA
   //--------------------------------------------------

   double m_previous;

   //--------------------------------------------------
   // Initialization State
   //--------------------------------------------------

   bool m_initialized;

   //--------------------------------------------------
   // Debug Mode
   //--------------------------------------------------

   bool m_debug;



public:

   CPHXEMA();

   ~CPHXEMA();



public:

   bool Initialize(
      int period,
      ENUM_TIMEFRAMES timeframe = PERIOD_CURRENT,
      ENUM_APPLIED_PRICE price = PRICE_CLOSE
   );

   void Shutdown();

   bool Update();

   void Reset();



public:

   double Current() const;

   double Previous() const;
   
   double Delta() const;

   int Period() const;

   bool IsInitialized() const;

   void EnableDebug(
      bool enable
   );

};



//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXEMA::CPHXEMA()
{
   Reset();
}



//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXEMA::~CPHXEMA()
{
   Shutdown();
}



//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXEMA::Reset()
{

   m_handle = INVALID_HANDLE;

   m_period = 0;

   m_timeframe = PERIOD_CURRENT;

   m_price = PRICE_CLOSE;

   m_current = 0.0;

   m_previous = 0.0;

   m_initialized = false;

   m_debug = false;

}

//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXEMA::Initialize(
   int period,
   ENUM_TIMEFRAMES timeframe,
   ENUM_APPLIED_PRICE price
)
{

   //--------------------------------------------------
   // Already initialized
   //--------------------------------------------------

   if(m_initialized)
      Shutdown();


   //--------------------------------------------------
   // Store settings
   //--------------------------------------------------

   m_period    = period;

   m_timeframe = timeframe;

   m_price     = price;


   //--------------------------------------------------
   // Create EMA Handle
   //--------------------------------------------------

   m_handle =
      iMA(
         _Symbol,
         m_timeframe,
         m_period,
         0,
         MODE_EMA,
         m_price
      );


   //--------------------------------------------------
   // Handle check
   //--------------------------------------------------

   if(m_handle == INVALID_HANDLE)
   {

      Print(
         "PHXEMA: unable to create EMA(",
         m_period,
         ")"
      );

      return false;

   }


   m_initialized = true;


   if(m_debug)
   {

      Print(
         "PHXEMA: EMA(",
         m_period,
         ") initialized."
      );

   }


   return true;

}

//+------------------------------------------------------------------+
//| Update                                                           |
//+------------------------------------------------------------------+
bool CPHXEMA::Update()
{

   if(!m_initialized)
      return false;

   double buffer[];

   ArrayResize(buffer, 2);
   
   //--------------------------------------------------
   // Copy EMA values
   //--------------------------------------------------
ResetLastError();

int copied =
   CopyBuffer(
      m_handle,
      0,
      0,
      2,
      buffer
   );

if(copied != 2)
{
   int error = GetLastError();

   Print(
      "PHX EMA COPY FAILED: ",
      "Period=", IntegerToString(m_period),
      " TF=", EnumToString(m_timeframe),
      " Handle=", IntegerToString(m_handle),
      " BarsCalculated=", IntegerToString(BarsCalculated(m_handle)),
      " Copied=", IntegerToString(copied),
      " Error=", IntegerToString(error)
   );

   return false;
}

   //--------------------------------------------------
   // Store values
   //--------------------------------------------------

   m_current  = buffer[0];

   m_previous = buffer[1];

   //--------------------------------------------------
   // Debug
   //--------------------------------------------------

   if(m_debug)
   {
      Print(
         "PHXEMA(",
         m_period,
         "): ",
         DoubleToString(m_current,5),
         "  Prev=",
         DoubleToString(m_previous,5)
      );
   }

   return true;
}

//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXEMA::Shutdown()
{

   if(m_handle != INVALID_HANDLE)
   {
      IndicatorRelease(m_handle);

      m_handle = INVALID_HANDLE;
   }

   m_initialized = false;
}

//+------------------------------------------------------------------+
//| Current                                                          |
//+------------------------------------------------------------------+
double CPHXEMA::Current() const
{
   return m_current;
}

//+------------------------------------------------------------------+
//| Previous                                                         |
//+------------------------------------------------------------------+
double CPHXEMA::Previous() const
{
   return m_previous;
}

//+------------------------------------------------------------------+
//| Delta                                                            |
//+------------------------------------------------------------------+
double CPHXEMA::Delta() const
{
   return (m_current - m_previous);
}

//+------------------------------------------------------------------+
//| Period                                                           |
//+------------------------------------------------------------------+
int CPHXEMA::Period() const
{
   return m_period;
}

//+------------------------------------------------------------------+
//| Initialized                                                      |
//+------------------------------------------------------------------+
bool CPHXEMA::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| Debug                                                            |
//+------------------------------------------------------------------+
void CPHXEMA::EnableDebug(bool enable)
{
   m_debug = enable;
}

#endif // __PHX_EMA_MQH__