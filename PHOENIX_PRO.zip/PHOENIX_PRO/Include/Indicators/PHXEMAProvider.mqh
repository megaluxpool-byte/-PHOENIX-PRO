#ifndef PHX_EMA_PROVIDER_MQH
#define PHX_EMA_PROVIDER_MQH


#include "IPHXEMAProvider.mqh"


//+------------------------------------------------------------------+
//| EMA Provider                                                     |
//+------------------------------------------------------------------+
class CPHXEMAProvider :
      public IPHXEMAProvider
{

private:

   string m_symbol;

   ENUM_TIMEFRAMES m_timeframe;


   int m_handle20;

   int m_handle50;

   int m_handle100;

   int m_handle200;


   double m_buffer20[1];

   double m_buffer50[1];

   double m_buffer100[1];

   double m_buffer200[1];


   bool m_valid;


public:

   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------

   CPHXEMAProvider();


   //--------------------------------------------------
   // Configure
   //--------------------------------------------------

   bool Initialize(
      string symbol,
      ENUM_TIMEFRAMES timeframe
   );


   //--------------------------------------------------
   // Refresh
   //--------------------------------------------------

   bool Refresh();


public:

   //--------------------------------------------------
   // EMA Values
   //--------------------------------------------------

   virtual double EMA20() const;
   
   virtual bool EMA20AtShift(
   int shift,
   double &value
)  const;

   virtual double EMA50() const;

   virtual double EMA100() const;

   virtual double EMA200() const;


};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXEMAProvider::CPHXEMAProvider()
{

   m_symbol = "";

   m_timeframe = PERIOD_CURRENT;


   m_handle20 = INVALID_HANDLE;

   m_handle50 = INVALID_HANDLE;

   m_handle100 = INVALID_HANDLE;

   m_handle200 = INVALID_HANDLE;


   m_valid = false;

}

//+------------------------------------------------------------------+
//| Initialize EMA Handles                                           |
//+------------------------------------------------------------------+
bool CPHXEMAProvider::Initialize(
   string symbol,
   ENUM_TIMEFRAMES timeframe
)
{

   m_symbol = symbol;

   m_timeframe = timeframe;


   m_handle20 =
      iMA(
         m_symbol,
         m_timeframe,
         20,
         0,
         MODE_EMA,
         PRICE_CLOSE
      );


   m_handle50 =
      iMA(
         m_symbol,
         m_timeframe,
         50,
         0,
         MODE_EMA,
         PRICE_CLOSE
      );


   m_handle100 =
      iMA(
         m_symbol,
         m_timeframe,
         100,
         0,
         MODE_EMA,
         PRICE_CLOSE
      );


   m_handle200 =
      iMA(
         m_symbol,
         m_timeframe,
         200,
         0,
         MODE_EMA,
         PRICE_CLOSE
      );


   if(
      m_handle20 == INVALID_HANDLE ||
      m_handle50 == INVALID_HANDLE ||
      m_handle100 == INVALID_HANDLE ||
      m_handle200 == INVALID_HANDLE
   )
   {
      return false;
   }


   return true;

}

//+------------------------------------------------------------------+
//| Refresh EMA Values                                               |
//+------------------------------------------------------------------+
bool CPHXEMAProvider::Refresh()
{

   if(
      m_handle20 == INVALID_HANDLE ||
      m_handle50 == INVALID_HANDLE ||
      m_handle100 == INVALID_HANDLE ||
      m_handle200 == INVALID_HANDLE
   )
      return false;



   if(
      CopyBuffer(
         m_handle20,
         0,
         0,
         1,
         m_buffer20
      ) != 1
   )
      return false;



   if(
      CopyBuffer(
         m_handle50,
         0,
         0,
         1,
         m_buffer50
      ) != 1
   )
      return false;



   if(
      CopyBuffer(
         m_handle100,
         0,
         0,
         1,
         m_buffer100
      ) != 1
   )
      return false;



   if(
      CopyBuffer(
         m_handle200,
         0,
         0,
         1,
         m_buffer200
      ) != 1
   )
      return false;



   m_valid = true;


   return true;

}

//+------------------------------------------------------------------+
//| EMA Metods                                               |
//+------------------------------------------------------------------+

double CPHXEMAProvider::EMA20() const
{
   if(!m_valid)
      return 0;

   return m_buffer20[0];
}
bool CPHXEMAProvider::EMA20AtShift(
   int shift,
   double &value
) const
{
   value =
      0.0;


   if(
      !m_valid ||
      m_handle20 == INVALID_HANDLE ||
      shift < 0
   )
   {
      return false;
   }


   double buffer[1];


   if(
      CopyBuffer(
         m_handle20,
         0,
         shift,
         1,
         buffer
      ) != 1
   )
   {
      return false;
   }


   value =
      buffer[0];


   return true;
}

double CPHXEMAProvider::EMA50() const
{
   if(!m_valid)
      return 0;

   return m_buffer50[0];
}


double CPHXEMAProvider::EMA100() const
{
   if(!m_valid)
      return 0;

   return m_buffer100[0];
}


double CPHXEMAProvider::EMA200() const
{
   if(!m_valid)
      return 0;

   return m_buffer200[0];
}

#endif // PHX_EMA_PROVIDER_MQH