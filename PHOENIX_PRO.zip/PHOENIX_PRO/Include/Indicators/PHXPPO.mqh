#ifndef __PHX_PPO_MQH__
#define __PHX_PPO_MQH__

//+------------------------------------------------------------------+
//| PHOENIX PRO                                                      |
//| Percentage Price Oscillator                                      |
//+------------------------------------------------------------------+
class CPHXPPO
{
private:
   string          m_symbol;
   ENUM_TIMEFRAMES m_timeframe;
   int             m_fastPeriod;
   int             m_slowPeriod;
   int             m_fastHandle;
   int             m_slowHandle;
   bool            m_initialized;

public:

   CPHXPPO();
   bool Initialize(
      const string symbol,
      const ENUM_TIMEFRAMES timeframe,
      const int fastPeriod,
      const int slowPeriod
   );
   void Shutdown();
   bool IsInitialized() const;
   string GetSymbol() const;
   ENUM_TIMEFRAMES GetTimeframe() const;
   int GetFastPeriod() const;
   int GetSlowPeriod() const;
   
   bool GetValue(
   const int shift,
   double &value
)  const;
 
   bool GetShiftByTime(
   const datetime time,
   int &shift
)  const;

   bool GetValues(
   const int startShift,
   const int count,
   double &values[]
)  const;

   bool GetAverageChange(
   const int startShift,
   const int period,
   double &averageChange
)  const;

   bool IsLocalHigh(
   const double &values[],
   const int index,
   const int depth
)  const;

   bool IsLocalLow(
   const double &values[],
   const int index,
   const int depth
)  const;

   bool GetHighProminence(
   const double &values[],
   const int index,
   const int depth,
   double &prominence
)  const;

   bool GetLowProminence(
   const double &values[],
   const int index,
   const int depth,
   double &prominence
)  const;
};
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXPPO::CPHXPPO()
{
   m_symbol      = "";
   m_timeframe   = PERIOD_CURRENT;
   m_fastPeriod  = 0;
   m_slowPeriod  = 0;
   m_fastHandle  = INVALID_HANDLE;
   m_slowHandle  = INVALID_HANDLE;
   m_initialized = false;
}
//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXPPO::Initialize(
   const string symbol,
   const ENUM_TIMEFRAMES timeframe,
   const int fastPeriod,
   const int slowPeriod
)
{
   //--------------------------------------------------
   // Validate Parameters
   //--------------------------------------------------
   if(symbol == "")
      return false;
   if(fastPeriod <= 0)
      return false;
   if(slowPeriod <= 0)
      return false;
   if(fastPeriod >= slowPeriod)
      return false;
   //--------------------------------------------------
   // Clean Previous State
   //--------------------------------------------------
   Shutdown();
   //--------------------------------------------------
   // Create Fast EMA
   //--------------------------------------------------
   m_fastHandle =
      iMA(
         symbol,
         timeframe,
         fastPeriod,
         0,
         MODE_EMA,
         PRICE_CLOSE
      );
   if(m_fastHandle == INVALID_HANDLE)
   {
      Shutdown();
      return false;
   }
   //--------------------------------------------------
   // Create Slow EMA
   //--------------------------------------------------
   m_slowHandle =
      iMA(
         symbol,
         timeframe,
         slowPeriod,
         0,
         MODE_EMA,
         PRICE_CLOSE
      );
   if(m_slowHandle == INVALID_HANDLE)
   {
      Shutdown();
      return false;
   }
   //--------------------------------------------------
   // Store Configuration
   //--------------------------------------------------
   m_symbol     = symbol;
   m_timeframe  = timeframe;

   m_fastPeriod = fastPeriod;
   m_slowPeriod = slowPeriod;

   m_initialized = true;
   return true;
}
//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXPPO::Shutdown()
{
   if(m_fastHandle != INVALID_HANDLE)
   {
      IndicatorRelease(
         m_fastHandle
      );
      m_fastHandle =
         INVALID_HANDLE;
   }
   if(m_slowHandle != INVALID_HANDLE)
   {
      IndicatorRelease(
         m_slowHandle
      );
      m_slowHandle =
         INVALID_HANDLE;
   }
   m_initialized = false;
}
//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXPPO::IsInitialized() const
{
   return m_initialized;
}
//+------------------------------------------------------------------+
//| Get Symbol                                                       |
//+------------------------------------------------------------------+
string CPHXPPO::GetSymbol() const
{
   return m_symbol;
}
//+------------------------------------------------------------------+
//| Get Timeframe                                                    |
//+------------------------------------------------------------------+
ENUM_TIMEFRAMES CPHXPPO::GetTimeframe() const
{
   return m_timeframe;
}
//+------------------------------------------------------------------+
//| Get Fast Period                                                  |
//+------------------------------------------------------------------+
int CPHXPPO::GetFastPeriod() const
{
   return m_fastPeriod;
}
//+------------------------------------------------------------------+
//| Get Slow Period                                                  |
//+------------------------------------------------------------------+
int CPHXPPO::GetSlowPeriod() const
{
   return m_slowPeriod;
}
//+------------------------------------------------------------------+
//| Get PPO Value                                                    |
//+------------------------------------------------------------------+
bool CPHXPPO::GetValue(
   const int shift,
   double &value
) const
{
   //--------------------------------------------------
   // Reset Output
   //--------------------------------------------------
   value = 0.0;
   //--------------------------------------------------
   // Validate State
   //--------------------------------------------------
   if(!m_initialized)
      return false;
   //--------------------------------------------------
   // Closed Bars Only
   //--------------------------------------------------
   if(shift <= 0)
      return false;
   if(
      m_fastHandle == INVALID_HANDLE ||
      m_slowHandle == INVALID_HANDLE
   )
   {
      return false;
   }
   //--------------------------------------------------
   // Read Fast EMA
   //--------------------------------------------------
   double fastBuffer[1];
   if(
      CopyBuffer(
         m_fastHandle,
         0,
         shift,
         1,
         fastBuffer
      ) != 1
   )
   {
      return false;
   }
   //--------------------------------------------------
   // Read Slow EMA
   //--------------------------------------------------
   double slowBuffer[1];
   if(
      CopyBuffer(
         m_slowHandle,
         0,
         shift,
         1,
         slowBuffer
      ) != 1
   )
   {
      return false;
   }
   double fastEMA =
      fastBuffer[0];
   double slowEMA =
      slowBuffer[0];
   //--------------------------------------------------
   // Validate EMA Values
   //--------------------------------------------------
   if(
      fastEMA == EMPTY_VALUE ||
      slowEMA == EMPTY_VALUE
   )
   {
      return false;
   }
   if(slowEMA == 0.0)
      return false;
   //--------------------------------------------------
   // Percentage Price Oscillator
   //--------------------------------------------------
   value =
      100.0 *
      (
         fastEMA -
         slowEMA
      ) /
      slowEMA;
   return true;
}
//+------------------------------------------------------------------+
//| Get Bar Shift By Time                                            |
//+------------------------------------------------------------------+
bool CPHXPPO::GetShiftByTime(
   const datetime time,
   int &shift
) const
{
   //--------------------------------------------------
   // Reset Output
   //--------------------------------------------------
   shift = -1;
   //--------------------------------------------------
   // Validate State
   //--------------------------------------------------
   if(!m_initialized)
      return false;
   if(time <= 0)
      return false;
   //--------------------------------------------------
   // Find Exact Bar
   //--------------------------------------------------
   int foundShift =
      iBarShift(
         m_symbol,
         m_timeframe,
         time,
         true
      );
   if(foundShift < 0)
      return false;
   //--------------------------------------------------
   // Closed Bars Only
   //--------------------------------------------------
   if(foundShift <= 0)
      return false;
   shift =
      foundShift;
   return true;
}
//+------------------------------------------------------------------+
//| Get PPO Values                                                   |
//+------------------------------------------------------------------+
bool CPHXPPO::GetValues(
   const int startShift,
   const int count,
   double &values[]
) const
{
   //--------------------------------------------------
   // Validate State
   //--------------------------------------------------
   if(!m_initialized)
      return false;
   //--------------------------------------------------
   // Closed Bars Only
   //--------------------------------------------------
   if(startShift <= 0)
      return false;
   if(count <= 0)
      return false;
   if(
      m_fastHandle == INVALID_HANDLE ||
      m_slowHandle == INVALID_HANDLE
   )
   {
      return false;
   }
   //--------------------------------------------------
   // Prepare Output
   //--------------------------------------------------
   ArrayResize(
      values,
      count
   );
   //--------------------------------------------------
   // Prepare EMA Buffers
   //--------------------------------------------------
   double fastBuffer[];
   double slowBuffer[];
   ArrayResize(
      fastBuffer,
      count
   );
   ArrayResize(
      slowBuffer,
      count
   );
   //--------------------------------------------------
   // Read Fast EMA
   //--------------------------------------------------
   int fastCopied =
      CopyBuffer(
         m_fastHandle,
         0,
         startShift,
         count,
         fastBuffer
      );
   if(fastCopied != count)
      return false;
   //--------------------------------------------------
   // Read Slow EMA
   //--------------------------------------------------
   int slowCopied =
      CopyBuffer(
         m_slowHandle,
         0,
         startShift,
         count,
         slowBuffer
      );
   if(slowCopied != count)
      return false;
   //--------------------------------------------------
   // Calculate PPO
   //--------------------------------------------------
   for(int i = 0; i < count; i++)
   {
      double fastEMA =
         fastBuffer[i];
      double slowEMA =
         slowBuffer[i];
      if(
         fastEMA == EMPTY_VALUE ||
         slowEMA == EMPTY_VALUE
      )
      {
         return false;
      }
      if(slowEMA == 0.0)
         return false;
      values[i] =
         100.0 *
         (
            fastEMA -
            slowEMA
         ) /
         slowEMA;
   }
   return true;
}

//+------------------------------------------------------------------+
//| Get Average PPO Change                                           |
//+------------------------------------------------------------------+
bool CPHXPPO::GetAverageChange(
   const int startShift,
   const int period,
   double &averageChange
) const
{
   //--------------------------------------------------
   // Reset Output
   //--------------------------------------------------

   averageChange = 0.0;

   //--------------------------------------------------
   // Validate Input
   //--------------------------------------------------

   if(!m_initialized)
      return false;

   if(startShift <= 0)
      return false;

   if(period <= 0)
      return false;

   //--------------------------------------------------
   // Need One Extra PPO Value
   //--------------------------------------------------

   int count =
      period + 1;

   double values[];

   if(
      !GetValues(
         startShift,
         count,
         values
      )
   )
   {
      return false;
   }

   //--------------------------------------------------
   // Calculate Average Absolute PPO Change
   //--------------------------------------------------

   double sum =
      0.0;

   int validCount =
      0;

   for(int i = 0; i < period; i++)
   {
      double change =
         MathAbs(
            values[i + 1] -
            values[i]
         );

      sum +=
         change;

      validCount++;
   }

   if(validCount <= 0)
      return false;

   averageChange =
      sum /
      (double)validCount;

   if(averageChange <= 0.0)
      return false;

   return true;
}
//+------------------------------------------------------------------+
//| Is Local PPO High                                                |
//+------------------------------------------------------------------+
bool CPHXPPO::IsLocalHigh(
   const double &values[],
   const int index,
   const int depth
) const
{
   //--------------------------------------------------
   // Validate Input
   //--------------------------------------------------
   int size =
      ArraySize(
         values
      );
   if(size <= 0)
      return false;
   if(depth <= 0)
      return false;
   if(index < depth)
      return false;
   if(index + depth >= size)
      return false;
   //--------------------------------------------------
   // Compare Left / Right Neighbours
   //--------------------------------------------------
   double center =
      values[index];
   for(int offset = 1; offset <= depth; offset++)
   {
      if(
         center <= values[index - offset]
      )
      {
         return false;
      }
      if(
         center <= values[index + offset]
      )
      {
         return false;
      }
   }
   return true;
}
//+------------------------------------------------------------------+
//| Is Local PPO Low                                                 |
//+------------------------------------------------------------------+
bool CPHXPPO::IsLocalLow(
   const double &values[],
   const int index,
   const int depth
) const
{
   //--------------------------------------------------
   // Validate Input
   //--------------------------------------------------
   int size =
      ArraySize(
         values
      );
   if(size <= 0)
      return false;
   if(depth <= 0)
      return false;
   if(index < depth)
      return false;
   if(index + depth >= size)
      return false;
   //--------------------------------------------------
   // Compare Left / Right Neighbours
   //--------------------------------------------------
   double center =
      values[index];
   for(int offset = 1; offset <= depth; offset++)
   {
      if(
         center >= values[index - offset]
      )
      {
         return false;
      }
      if(
         center >= values[index + offset]
      )
      {
         return false;
      }
   }
   return true;
}
//+------------------------------------------------------------------+
//| Get PPO High Prominence                                          |
//+------------------------------------------------------------------+
   bool CPHXPPO::GetHighProminence(
   const double &values[],
   const int index,
   const int depth,
   double &prominence
) const
{
   //--------------------------------------------------
   // Reset Output
   //--------------------------------------------------
   prominence = 0.0;
   //--------------------------------------------------
   // Validate Input
   //--------------------------------------------------
   int size =
      ArraySize(
         values
      );
   if(size <= 0)
      return false;
   if(depth <= 0)
      return false;
   if(index < depth)
      return false;
   if(index + depth >= size)
      return false;
   //--------------------------------------------------
   // Validate Local High
   //--------------------------------------------------
   if(
      !IsLocalHigh(
         values,
         index,
         depth
      )
   )
   {
      return false;
   }
   //--------------------------------------------------
   // Find Left / Right Bases
   //--------------------------------------------------
   double leftBase =
      values[index - 1];
   double rightBase =
      values[index + 1];
   for(int offset = 2; offset <= depth; offset++)
   {
      if(
         values[index - offset] < leftBase
      )
      {
         leftBase =
            values[index - offset];
      }
      if(
         values[index + offset] < rightBase
      )
      {
         rightBase =
            values[index + offset];
      }
   }
   //--------------------------------------------------
   // Calculate Prominence
   //--------------------------------------------------
   double leftProminence =
      values[index] -
      leftBase;
   double rightProminence =
      values[index] -
      rightBase;
   prominence =
      MathMin(
         leftProminence,
         rightProminence
      );
   if(prominence < 0.0)
      return false;
   return true;
}
//+------------------------------------------------------------------+
//| Get PPO Low Prominence                                           |
//+------------------------------------------------------------------+
bool CPHXPPO::GetLowProminence(
   const double &values[],
   const int index,
   const int depth,
   double &prominence
) const
{
   //--------------------------------------------------
   // Reset Output
   //--------------------------------------------------
   prominence = 0.0;
   //--------------------------------------------------
   // Validate Input
   //--------------------------------------------------
   int size =
      ArraySize(
         values
      );
   if(size <= 0)
      return false;
   if(depth <= 0)
      return false;
   if(index < depth)
      return false;
   if(index + depth >= size)
      return false;
   //--------------------------------------------------
   // Validate Local Low
   //--------------------------------------------------
   if(
      !IsLocalLow(
         values,
         index,
         depth
      )
   )
   {
      return false;
   }
   //--------------------------------------------------
   // Find Left / Right Bases
   //--------------------------------------------------
   double leftBase =
      values[index - 1];
   double rightBase =
      values[index + 1];
   for(int offset = 2; offset <= depth; offset++)
   {
      if(
         values[index - offset] > leftBase
      )
      {
         leftBase =
            values[index - offset];
      }
      if(
         values[index + offset] > rightBase
      )
      {
         rightBase =
            values[index + offset];
      }
   }
   //--------------------------------------------------
   // Calculate Prominence
   //--------------------------------------------------
   double leftProminence =
      leftBase -
      values[index];
   double rightProminence =
      rightBase -
      values[index];
   prominence =
      MathMin(
         leftProminence,
         rightProminence
      );
   if(prominence < 0.0)
      return false;
   return true;
}

#endif


