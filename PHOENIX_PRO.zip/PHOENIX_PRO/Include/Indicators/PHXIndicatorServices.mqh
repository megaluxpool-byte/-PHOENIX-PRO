//+------------------------------------------------------------------+
//|                  PHXIndicatorServices.mqh                       |
//|                 PHOENIX PRO Trading Framework                   |
//|                                                                  |
//| Description:                                                     |
//|   Root container for indicator services                          |
//+------------------------------------------------------------------+

#ifndef __PHX_INDICATOR_SERVICES_MQH__
#define __PHX_INDICATOR_SERVICES_MQH__


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXATR.mqh"
#include "PHXMovingAverage.mqh"
#include "PHXRSI.mqh"
#include "PHXADX.mqh"
#include "PHXVolumeAnalyzer.mqh"
#include "..\Core\PHXATRMomentum.mqh"
#include "PHXATREnergy.mqh"
#include "PHXEMA.mqh"
#include "PHXMTFAlignment.mqh"
#include "IPHXMarketIndicatorProvider.mqh"
#include "..\Core\PHXConstants.mqh"
#include "..\Core\PHXConfigTypes.mqh"

//+------------------------------------------------------------------+
//| Indicator Services Container                                     |
//+------------------------------------------------------------------+

class CPHXIndicatorServices :
      public IPHXMarketIndicatorProvider
{


private:
   
   CPHXATR*              m_currentATR; 
   CPHXATR*              m_baseATR;   
   CPHXATR*              m_dailyATR;   
   CPHXATRMomentum*      m_atrMomentum;   
   CPHXATREnergy*        m_atrEnergy;
   CPHXMovingAverage*    m_ma;
   CPHXRSI*              m_rsi;
   CPHXADX*              m_adx;
   CPHXVolumeAnalyzer*   m_volume;   
   CPHXMTFAlignment      m_mtfAlignment;   
   bool m_initialized;
   
//--------------------------------------------------
// EMA
//--------------------------------------------------

   CPHXEMA m_fastEMA;
   CPHXEMA m_mediumEMA;
   CPHXEMA m_slowEMA;
   CPHXEMA m_trendEMA;
public:

   CPHXIndicatorServices();
   ~CPHXIndicatorServices();



public:

   bool Initialize();
   void Shutdown();
   bool ConfigureMTFAlignment(
   const SPHXMTFAlignmentConfig &config
);
   void Reset();   
   bool Update();
   bool IsInitialized() const;

//--------------------------------------------------
// Market Indicator Provider
//--------------------------------------------------
   //--------------------------------------------------
   // ADX
   //--------------------------------------------------
   double ADX() const override;
   double PlusDI() const override;
   double MinusDI() const override;   
   //--------------------------------------------------
   // MA2
   //--------------------------------------------------
   double MA2() const override;   
   //--------------------------------------------------
   // ATR
   //--------------------------------------------------
   double ATR() const override;  
   double DailyATR() const override;   
   double DATR() const override;
   //--------------------------------------------------
   // RSI
   //--------------------------------------------------  
   double RSI() const override;
   //--------------------------------------------------
   // Volume
   //--------------------------------------------------
   long Volume() const override;
   double AverageVolume() const override;  
public:
   CPHXATR* GetCurrentATR();   
   CPHXATR* GetBaseATR();   
   CPHXATR* GetDailyATRProvider() const;
   CPHXMovingAverage* GetMA();
   CPHXRSI* GetRSI();
   CPHXADX* GetADX();
   CPHXVolumeAnalyzer* GetVolume();   
   CPHXEMA* GetFastEMA();
   CPHXEMA* GetMediumEMA();
   CPHXEMA* GetSlowEMA();
   CPHXEMA* GetTrendEMA();
   CPHXMTFAlignment* GetMTFAlignment();
};
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXIndicatorServices::CPHXIndicatorServices()
{
   m_currentATR = NULL;   
   m_baseATR = NULL; 
   m_dailyATR = NULL;
   m_ma = NULL;
   m_rsi = NULL;
   m_adx = NULL;
   m_volume = NULL;
   m_initialized = false;
}
//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXIndicatorServices::~CPHXIndicatorServices()
{
   Shutdown();
}
//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXIndicatorServices::Initialize()
{
   if(m_initialized)
      return true;
   //--------------------------------------------------
   // Current ATR
   //--------------------------------------------------
m_currentATR = new CPHXATR();
if(m_currentATR == NULL)
{
   Shutdown();
   return false;
}
if(!(*m_currentATR).Initialize(
      _Symbol,
      PERIOD_M30,
      14))
{
   delete m_currentATR;
   m_currentATR = NULL;
   return false;
}
   //--------------------------------------------------
   // Base ATR
   //--------------------------------------------------
   m_baseATR = new CPHXATR();
   if(m_baseATR == NULL)
{
   Shutdown();
   return false;
}
   if(!(*m_baseATR).Initialize(
      _Symbol,
      PERIOD_H1,
      14))     
{
   delete m_baseATR;
   m_baseATR = NULL;
   return false;
}
//--------------------------------------------------
// Daily ATR
//--------------------------------------------------
m_dailyATR = new CPHXATR();

if(m_dailyATR == NULL)
{
   Shutdown();
   return false;
}
if(!(*m_dailyATR).Initialize(
      _Symbol,
      PERIOD_D1,
      14))
{
   delete m_dailyATR;
   m_dailyATR = NULL;

   return false;
}
m_atrMomentum = new CPHXATRMomentum();

if(m_atrMomentum == NULL)
{
   return false;
}
   m_ma = new CPHXMovingAverage();

   if(m_ma == NULL)
   {
   Shutdown();
   return false;
   }
   if(!(*m_ma).Initialize(
         _Symbol,
         PERIOD_CURRENT,
         2,
         MODE_EMA,
         PRICE_CLOSE))
   {
      delete m_ma;
      m_ma = NULL;

      return false;
   }
   m_rsi = new CPHXRSI();

   if(m_rsi == NULL)
   {
   Shutdown();
   return false;
   }
   if(!(*m_rsi).Initialize(
         _Symbol,
         PERIOD_CURRENT,
         14,
         PRICE_CLOSE))
   {
      delete m_rsi;
      m_rsi = NULL;

      return false;
   }
   m_adx = new CPHXADX();
   if(m_adx == NULL)
   {
   Shutdown();
   return false;
   }
   if(!(*m_adx).Initialize(
         _Symbol,
         PERIOD_CURRENT,
         14))
   {
      delete m_adx;
      m_adx = NULL;

      return false;
   }
   m_volume = new CPHXVolumeAnalyzer();

   if(m_volume == NULL)
   {
   Shutdown();
   return false;
   }
   if(!(*m_volume).Initialize(
         _Symbol,
         PERIOD_CURRENT,
         2))
   {
      delete m_volume;
      m_volume = NULL;
      return false;
   }
//--------------------------------------------------
// EMA
//--------------------------------------------------

if(!m_fastEMA.Initialize(20))
   return false;
if(!m_mediumEMA.Initialize(50))
   return false;
if(!m_slowEMA.Initialize(100))
   return false;
if(!m_trendEMA.Initialize(200))
   return false;
   m_initialized = true;
   
//-Временная вставка--
if(PHX_VERBOSE_DEBUG)
{
   Print(
      "PHX ATR Services: ",
      "Current ATR=",
      (*m_currentATR).GetValue(),
      " Base ATR=",
      (*m_baseATR).GetValue()
   );
}
   return true;
}
//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXIndicatorServices::Shutdown()
{
   Print("PHXIndicatorServices: Shutdown started");
 //--------------------------------------------------
// Current ATR
//--------------------------------------------------
if(m_currentATR != NULL)
{
   (*m_currentATR).Shutdown();
   delete m_currentATR;
   m_currentATR = NULL;
   Print("PHXIndicatorServices: Current ATR released");
}
//--------------------------------------------------
// Base ATR
//--------------------------------------------------
if(m_baseATR != NULL)
{
   (*m_baseATR).Shutdown();
   delete m_baseATR;
   m_baseATR = NULL;
   Print("PHXIndicatorServices: Base ATR released");
}
//--------------------------------------------------
// Daily ATR
//--------------------------------------------------

if(m_dailyATR != NULL)
{
   delete m_dailyATR;
   m_dailyATR = NULL;
}
   //--------------------------------------------------
   // Moving Average
   //--------------------------------------------------
   if(m_ma != NULL)
   {
      (*m_ma).Shutdown();
      delete m_ma;
      m_ma = NULL;     
      Print("PHXIndicatorServices: MA released");
   }
   //--------------------------------------------------
   // RSI
   //--------------------------------------------------
   if(m_rsi != NULL)
   {
      (*m_rsi).Shutdown();
      delete m_rsi;
      m_rsi = NULL;     
      Print("PHXIndicatorServices: RSI released");
   }
   //--------------------------------------------------
   // ADX
   //--------------------------------------------------
   if(m_adx != NULL)
   {
      (*m_adx).Shutdown();
      delete m_adx;
      m_adx = NULL;     
      Print("PHXIndicatorServices: ADX released");
   }
   //--------------------------------------------------
   // Volume Analyzer
   //--------------------------------------------------
   if(m_volume != NULL)
   {
      (*m_volume).Shutdown();
      delete m_volume;
      m_volume = NULL;      
      Print("PHXIndicatorServices: VOLUME released");
   }
   //--------------------------------------------------
   // Volume Analyzer
   //--------------------------------------------------
   if(m_atrMomentum != NULL)
{
   delete m_atrMomentum;
   m_atrMomentum = NULL;
}
//--------------------------------------------------
// EMA
//--------------------------------------------------
   m_fastEMA.Shutdown();
   m_mediumEMA.Shutdown();
   m_slowEMA.Shutdown();
   m_trendEMA.Shutdown();
   //--------------------------------------------------
   // Reset state
   //--------------------------------------------------
   m_initialized = false;
}
//+------------------------------------------------------------------+ 
//| Reset | 
//+------------------------------------------------------------------+ 
void CPHXIndicatorServices::Reset() 
{
   if(m_currentATR != NULL)
      (*m_currentATR).Reset();
   if(m_baseATR != NULL)
      (*m_baseATR).Reset(); 
    if(m_ma != NULL) 
   (*m_ma).Reset(); 
   if(m_rsi != NULL) 
   (*m_rsi).Reset(); 
    if(m_adx != NULL) 
   (*m_adx).Reset(); 
    if(m_volume != NULL) 
   (*m_volume).Reset();  
   if(!m_initialized)
   return;  
 }
 //+------------------------------------------------------------------+
//| Update                                                            |
//+------------------------------------------------------------------+
bool CPHXIndicatorServices::Update()
{
   if(!m_initialized)
      return false;
   bool result = true;
   if(m_currentATR != NULL)
   {
      if(!(*m_currentATR).Update())
      {
         Print("PHX Indicator FAILED: CurrentATR");
         result = false;
      }
   }
   if(m_baseATR != NULL)
{
   if(!(*m_baseATR).Update())
   {
      Print("PHX Indicator WARNING: BaseATR waiting history");
   }
}
   if(m_dailyATR != NULL)
{
   if(!(*m_dailyATR).Update())
   {
      Print("PHX Indicator WARNING: DailyATR waiting history");
   }
}
   if(m_ma != NULL)
   {
      if(!(*m_ma).Update())
      {
         Print("PHX Indicator FAILED: MA");
         result = false;
      }
   }
   if(m_rsi != NULL)
   {
      if(!(*m_rsi).Update())
      {
         Print("PHX Indicator FAILED: RSI");
         result = false;
      }
   }
   if(m_adx != NULL)
   {
      if(!(*m_adx).Update())
      {
         Print("PHX Indicator FAILED: ADX");
         result = false;
      }
   }
   if(m_volume != NULL)
   {
      if(!(*m_volume).Update())
      {
         Print("PHX Indicator FAILED: Volume");
         result = false;
      }
   }
//--------------------------------------------------
// EMA
//--------------------------------------------------
   if(!m_fastEMA.Update())
   {
      Print("PHX Indicator FAILED: FastEMA");
      result = false;
   }
   if(!m_mediumEMA.Update())
   {
      Print("PHX Indicator FAILED: MediumEMA");
      result = false;
   }
   if(!m_slowEMA.Update())
   {
      Print("PHX Indicator FAILED: SlowEMA");
      result = false;
   }
   if(!m_trendEMA.Update())
   {
      Print("PHX Indicator FAILED: TrendEMA");
      result = false;
   }
   return result;
}
//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXIndicatorServices::IsInitialized() const
{
   return m_initialized;
}
//+------------------------------------------------------------------+
//| Get Base ATR                                                     |
//+------------------------------------------------------------------+
CPHXATR* CPHXIndicatorServices::GetBaseATR()
{
   return m_baseATR;
}
//+------------------------------------------------------------------+
//| Get Current ATR                                                  |
//+------------------------------------------------------------------+
CPHXATR* CPHXIndicatorServices::GetCurrentATR()
{
   return m_currentATR;
}
CPHXMovingAverage* CPHXIndicatorServices::GetMA()
{
   if(!m_initialized)
      return NULL;   
   return m_ma;
}
CPHXRSI* CPHXIndicatorServices::GetRSI()
{
   if(!m_initialized)
      return NULL;   
   return m_rsi;
}
CPHXADX* CPHXIndicatorServices::GetADX()
{
   if(!m_initialized)
      return NULL;   
   return m_adx;
}
CPHXVolumeAnalyzer* CPHXIndicatorServices::GetVolume()
{
   if(!m_initialized)
      return NULL;  
   return m_volume;
}
//+------------------------------------------------------------------+
//| Get Daily ATR Provider                                                 |
//+------------------------------------------------------------------+
CPHXATR* CPHXIndicatorServices::GetDailyATRProvider() const
{
   return m_dailyATR;
}
//+------------------------------------------------------------------+
//| Get Fast EMA                                                     |
//+------------------------------------------------------------------+
CPHXEMA* CPHXIndicatorServices::GetFastEMA()
{
   return &m_fastEMA;
}
//+------------------------------------------------------------------+
//| Get Medium EMA                                                   |
//+------------------------------------------------------------------+
CPHXEMA* CPHXIndicatorServices::GetMediumEMA()
{
   return &m_mediumEMA;
}
//+------------------------------------------------------------------+
//| Get Slow EMA                                                     |
//+------------------------------------------------------------------+
CPHXEMA* CPHXIndicatorServices::GetSlowEMA()
{
   return &m_slowEMA;
}
//+------------------------------------------------------------------+
//| Get Trend EMA                                                    |
//+------------------------------------------------------------------+
CPHXEMA* CPHXIndicatorServices::GetTrendEMA()
{
   return &m_trendEMA;
}
//+------------------------------------------------------------------+
//| Get MTF Alignment                                                |
//+------------------------------------------------------------------+
CPHXMTFAlignment* CPHXIndicatorServices::GetMTFAlignment()
{
   return &m_mtfAlignment;
}
//+------------------------------------------------------------------+
//| ADX                                                              |
//+------------------------------------------------------------------+
double CPHXIndicatorServices::ADX() const
{
   if(m_adx == NULL)
      return 0.0;
   return m_adx.GetADX();
}
//+------------------------------------------------------------------+
//| Plus DI                                                          |
//+------------------------------------------------------------------+
double CPHXIndicatorServices::PlusDI() const
{
   if(m_adx == NULL)
      return 0.0;
   return m_adx.GetPlusDI();
}
//+------------------------------------------------------------------+
//| Minus DI                                                         |
//+------------------------------------------------------------------+
double CPHXIndicatorServices::MinusDI() const
{
   if(m_adx == NULL)
      return 0.0;
   return m_adx.GetMinusDI();
}
//+------------------------------------------------------------------+
//| MA2                                                              |
//+------------------------------------------------------------------+
double CPHXIndicatorServices::MA2() const
{
   if(m_ma == NULL)
      return 0.0;
   return m_ma.GetValue();
}
//+------------------------------------------------------------------+
//| Daily ATR                                                        |
//+------------------------------------------------------------------+

double CPHXIndicatorServices::DailyATR() const
{
   if(m_dailyATR == NULL)
      return 0.0;

   return (*m_dailyATR).GetValue();
}
//+------------------------------------------------------------------+
//| ATR                                                              |
//+------------------------------------------------------------------+
double CPHXIndicatorServices::ATR() const
{
   if(m_currentATR == NULL)
      return 0.0;
   return (*m_currentATR).GetValue();
}
//+------------------------------------------------------------------+
//| DATR                                                              |
//+------------------------------------------------------------------+
double CPHXIndicatorServices::DATR() const
{
   if(m_dailyATR == NULL)
      return 0.0;
   return (*m_dailyATR).DATR();
}
//+------------------------------------------------------------------+
//| RSI                                                              |
//+------------------------------------------------------------------+
double CPHXIndicatorServices::RSI() const
{
   if(m_rsi == NULL)
      return 0.0;
   return (*m_rsi).GetValue();
}
//+------------------------------------------------------------------+
//| Volume                                                           |
//+------------------------------------------------------------------+
long CPHXIndicatorServices::Volume() const
{
   if(m_volume == NULL)
      return 0;
   return (*m_volume).GetCurrentVolume();
}
//+------------------------------------------------------------------+
//| Average Volume                                                   |
//+------------------------------------------------------------------+
double CPHXIndicatorServices::AverageVolume() const
{
   if(m_volume == NULL)
      return 0.0;
   return (*m_volume).GetAverageVolume();
}
//+------------------------------------------------------------------+
//| Configure MTF Alignment                                          |
//+------------------------------------------------------------------+
bool CPHXIndicatorServices::ConfigureMTFAlignment(
   const SPHXMTFAlignmentConfig &config
)
{
   m_mtfAlignment.Configure(
      config.FastEMA,
      config.SlowEMA,
      config.SlopeBars
   );
   return true;
}

#endif // __PHX_INDICATOR_SERVICES_MQH__