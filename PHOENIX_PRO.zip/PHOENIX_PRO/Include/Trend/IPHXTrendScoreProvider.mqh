#ifndef PHX_TREND_SCORE_PROVIDER_INTERFACE_MQH
#define PHX_TREND_SCORE_PROVIDER_INTERFACE_MQH


#include "../Signal/PHXTrendScoreTypes.mqh"


//+------------------------------------------------------------------+
//| Trend Score Provider Interface                                   |
//+------------------------------------------------------------------+
class IPHXTrendScoreProvider
{

public:

   //--------------------------------------------------
   // Destructor
   //--------------------------------------------------

   virtual ~IPHXTrendScoreProvider()
   {
   }


public:

   //--------------------------------------------------
   // Calculate Score
   //--------------------------------------------------

   virtual bool Calculate(
      SPHXTrendScore &score
   ) = 0;


   //--------------------------------------------------
   // Get Latest Score
   //--------------------------------------------------

   virtual bool GetScore(
      SPHXTrendScore &score
   ) const = 0;


};


#endif // PHX_TREND_SCORE_PROVIDER_INTERFACE_MQH