#ifndef PHX_TREND_STATISTICS_MQH
#define PHX_TREND_STATISTICS_MQH

#include "PHXTrendStatisticsTypes.mqh"
#include "../Core/PHXSnapshotBuffer.mqh"
#include "PHXTrendSnapshotBuilder.mqh"

class CPHXTrendStatistics
{

private:

   CPHXTrendSnapshotBuilder *m_builder;

   CPHXSnapshotBuffer m_buffer;
   
   SPHXTrendSnapshot m_current;

   bool m_initialized;
   
public:

   CPHXTrendStatistics();

   ~CPHXTrendStatistics();


public:

   bool Initialize(
      int historySize
   );


   void Reset();


   bool Update();
   
   
   bool GetLatest(
      SPHXTrendSnapshot &snapshot
   );
   
   bool AddSnapshot(
   const SPHXTrendSnapshot &snapshot
   );
   
   bool SetBuilder(
   CPHXTrendSnapshotBuilder *builder
);
   
    int Size() const;
    
    bool IsInitialized() const;

    ulong TotalRecords() const;
    
    SPHXTrendSnapshot GetCurrent() const;
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXTrendStatistics::CPHXTrendStatistics()
{
   m_builder = NULL;
   Reset();
}
 

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXTrendStatistics::~CPHXTrendStatistics()
{
   Reset();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXTrendStatistics::Initialize(
   int historySize
)
{

   if(historySize <= 0)
      return false;


   if(!m_buffer.Initialize(historySize))
      return false;


   m_current.Reset();
   
   m_initialized=true;

   return true;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXTrendStatistics::Reset()
{

   m_buffer.Clear();

   m_current.Reset();
   
   m_builder = NULL;
   
   m_initialized=false;

}

//+------------------------------------------------------------------+
//| Update Statistics                                                |
//+------------------------------------------------------------------+
bool CPHXTrendStatistics::Update()
{

   if(m_builder == NULL)
      return false;


   SPHXTrendSnapshot snapshot;


   if(!(*m_builder).Build(snapshot))
      return false;


   if(!m_buffer.Push(snapshot))
      return false;


   m_current = snapshot;


   return true;

}
//+------------------------------------------------------------------+
//| Set Snapshot Builder                                             |
//+------------------------------------------------------------------+
bool CPHXTrendStatistics::SetBuilder(
   CPHXTrendSnapshotBuilder *builder
)
{

   if(builder == NULL)
      return false;


   m_builder = builder;


   return true;

}
//+------------------------------------------------------------------+
//| Add Snapshot                                                     |
//+------------------------------------------------------------------+
bool CPHXTrendStatistics::AddSnapshot(
   const SPHXTrendSnapshot &snapshot
)
{

   return m_buffer.Push(snapshot);

}

//+------------------------------------------------------------------+
//| Get Latest                                                       |
//+------------------------------------------------------------------+
bool CPHXTrendStatistics::GetLatest(
   SPHXTrendSnapshot &snapshot
)
{

   return m_buffer.Last(snapshot);

}

//+------------------------------------------------------------------+
//| Get Current Snapshot                                             |
//+------------------------------------------------------------------+

SPHXTrendSnapshot CPHXTrendStatistics::GetCurrent() const
{
   return m_current;
}

//+------------------------------------------------------------------+
//| Size                                                             |
//+------------------------------------------------------------------+
int CPHXTrendStatistics::Size() const
{
   return m_buffer.Size();
}



#endif