#ifndef PHX_RESEARCH_JOURNAL_MQH
#define PHX_RESEARCH_JOURNAL_MQH

//--------------------------------------------------
// Includes
//--------------------------------------------------
#include "PHXSignalQualityTypes.mqh"

//+------------------------------------------------------------------+
//| Research Journal                                                 |
//+------------------------------------------------------------------+
class CPHXResearchJournal
{
private:
   //--------------------------------------------------
   // State
   //--------------------------------------------------
   bool   m_initialized;
   string m_fileName;
   string m_entryFileName;

public:
   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------
   CPHXResearchJournal()
   {
      m_initialized = false;
      m_fileName      = "PHXResearchJournal.csv";
      m_entryFileName = "PHXResearchEntryJournal.csv";
   }

   //--------------------------------------------------
   // Initialize
   //--------------------------------------------------
   bool Initialize()
   {
      int handle =
         FileOpen(
            m_fileName,
            FILE_READ |
            FILE_WRITE |
            FILE_CSV |
            FILE_SHARE_READ,
            ';'
         );

      if(handle == INVALID_HANDLE)
      {
         Print(
            "PHX Research Journal ERROR: FileOpen failed. Error=",
            GetLastError()
         );
         m_initialized = false;
         return false;
      }

      //--------------------------------------------------
      // Write header only for empty file
      //--------------------------------------------------
      if(FileSize(handle) <= 2)
      {
         string header = "";
         header += "TIME;";
         header += "SYMBOL;";
         header += "TICKET;";
         header += "DIR;";
         header += "ENTRY;";
         header += "CANDLE_POSITION;";
         header += "EXECUTION_DELAY_MS;";
         header += "PRICE_VS_CANDLE_HIGH;";
         header += "D1_ATR;";
         header += "D1_RANGE;";
         header += "ENERGY_USED;";
         header += "ENERGY_LEFT;";
         header += "ATR;";
         header += "RSI;";
         header += "RSI_EXIT_70;";
         header += "RSI_EXIT_75;";
         header += "RSI_EXIT_78;";
         header += "BUY_ALLOWED;";
         header += "SELL_ALLOWED;";
         header += "BUY_BLOCK_TREND;";
         header += "BUY_BLOCK_EMA;";
         header += "BUY_BLOCK_RSI;";
         header += "BUY_BLOCK_VOLUME;";
         header += "BUY_BLOCK_CANDLE;";
         header += "BUY_BLOCK_NEAR_HIGH;";
         header += "BUY_BLOCK_NEAR_LOW;";
         header += "SELL_BLOCK_TREND;";
         header += "SELL_BLOCK_EMA;";
         header += "SELL_BLOCK_RSI;";
         header += "SELL_BLOCK_VOLUME;";
         header += "SELL_BLOCK_CANDLE;";
         header += "SELL_BLOCK_NEAR_HIGH;";
         header += "SELL_BLOCK_NEAR_LOW;";
         header += "ADX;";
         header += "TREND;";
         header += "SCORE;";
         header += "EMA_SCORE;";
         header += "ATR_SCORE;";
         header += "RSI_SCORE;";
         header += "VOL_SCORE;";
         header += "ADX_SCORE;";
         header += "MARKET_SCORE;";
         header += "MTF_SCORE;";
         header += "HIGHER_TF_TREND;";
         header += "SIGNAL_TF_TREND;";
         header += "ENTRY_TF_TREND;";
         header += "ENTRY_EMA_SLOPE;";
         header += "ENTRY_EMA_DISTANCE;";

//--------------------------------------------------
// Market Phase Diagnostics
//--------------------------------------------------

header += "MARKET_PHASE;";
header += "BUY_EXHAUSTION_RISK;";
header += "SELL_EXHAUSTION_RISK;";
header += "M1_BULL_SEQUENCE;";
header += "M1_BEAR_SEQUENCE;";
header += "RSI_CHANGE;";
header += "EMA_SLOPE_CHANGE;";

         header += "P5;";
         header += "CH5;";
         header += "P10;";
         header += "CH10;";
         header += "P20;";
         header += "CH20;";
         header += "RESEARCH_TF;";
         header += "HAS_DIVERGENCE;";
         header += "DIV_TYPE;";
         header += "DIV_CONTEXT;";
         header += "DIV_PRICE_DELTA_NORM;";
         header += "DIV_PPO_DELTA_NORM;";
         header += "DIV_MATCH_OFFSET_1;";
         header += "DIV_MATCH_OFFSET_2;";
         header += "DIV_PROFILE_VALID;";
         header += "DIV_RSI;";
         header += "DIV_ADX;";
         header += "DIV_ADX_DIRECTION;";
         header += "DIV_REL_VOLUME;";
         header += "DIV_VOLUME_DIRECTION;";
         header += "DIV_STRUCTURE_CONFIRMED;";
         header += "DIV_BREAK_DISTANCE_NORM;";
         header += "DIV_CONFIRM_DELAY_BARS";
         header += "\r\n";

         FileWriteString(handle, header);
         FileFlush(handle);
      }

      FileClose(handle);

      //--------------------------------------------------
      // Initialize immediate Entry / Decision Journal
      //--------------------------------------------------
      int entryHandle =
         FileOpen(
            m_entryFileName,
            FILE_READ |
            FILE_WRITE |
            FILE_CSV |
            FILE_SHARE_READ,
            ';'
         );

      if(entryHandle == INVALID_HANDLE)
      {
         Print(
            "PHX Research Entry Journal ERROR: FileOpen failed. Error=",
            GetLastError()
         );
         m_initialized = false;
         return false;
      }

      if(FileSize(entryHandle) <= 2)
      {
         string entryHeader = "";
         entryHeader += "TIME;";
         entryHeader += "SYMBOL;";
         entryHeader += "DIR;";
         entryHeader += "ENTRY;";
         entryHeader += "BUY_ALLOWED;";
         entryHeader += "SELL_ALLOWED;";
         entryHeader += "BUY_BLOCK_TREND;";
         entryHeader += "BUY_BLOCK_EMA;";
         entryHeader += "BUY_BLOCK_RSI;";
         entryHeader += "BUY_BLOCK_VOLUME;";
         entryHeader += "BUY_BLOCK_CANDLE;";
         entryHeader += "BUY_BLOCK_NEAR_HIGH;";
         entryHeader += "BUY_BLOCK_NEAR_LOW;";
         entryHeader += "SELL_BLOCK_TREND;";
         entryHeader += "SELL_BLOCK_EMA;";
         entryHeader += "SELL_BLOCK_RSI;";
         entryHeader += "SELL_BLOCK_VOLUME;";
         entryHeader += "SELL_BLOCK_CANDLE;";
         entryHeader += "SELL_BLOCK_NEAR_HIGH;";
         entryHeader += "SELL_BLOCK_NEAR_LOW;";
         entryHeader += "D1_ATR;";
         entryHeader += "D1_RANGE;";
         entryHeader += "ENERGY_USED;";
         entryHeader += "ENERGY_LEFT;";
         entryHeader += "ATR;";
         entryHeader += "RSI;";
         entryHeader += "RSI_EXIT_70;";
         entryHeader += "RSI_EXIT_75;";
         entryHeader += "RSI_EXIT_78;";
         entryHeader += "ADX;";
         entryHeader += "TREND;";
         entryHeader += "SCORE;";
         entryHeader += "EMA_SCORE;";
         entryHeader += "ATR_SCORE;";
         entryHeader += "RSI_SCORE;";
         entryHeader += "VOL_SCORE;";
         entryHeader += "ADX_SCORE;";
         entryHeader += "MARKET_SCORE;";
         entryHeader += "MTF_SCORE;";
         entryHeader += "HIGHER_TF_TREND;";
         entryHeader += "SIGNAL_TF_TREND;";
         entryHeader += "ENTRY_TF_TREND;";
         entryHeader += "ENTRY_EMA_SLOPE;";
         entryHeader += "ENTRY_EMA_DISTANCE;";

         //--------------------------------------------------
         // Market Phase Diagnostics
         //--------------------------------------------------

         entryHeader += "MARKET_PHASE;";
         entryHeader += "BUY_EXHAUSTION_RISK;";
         entryHeader += "SELL_EXHAUSTION_RISK;";
         entryHeader += "M1_BULL_SEQUENCE;";
         entryHeader += "M1_BEAR_SEQUENCE;";
         entryHeader += "RSI_CHANGE;";
         entryHeader += "EMA_SLOPE_CHANGE;";
         
         entryHeader += "RESEARCH_TF;";
         entryHeader += "M5_TIME;";
         entryHeader += "M5_OPEN;";
         entryHeader += "M5_HIGH;";
         entryHeader += "M5_LOW;";
         entryHeader += "M5_CLOSE;";
         entryHeader += "M5_RANGE;";
         entryHeader += "M1_TIME_0;";
         entryHeader += "M1_OPEN_0;";
         entryHeader += "M1_HIGH_0;";
         entryHeader += "M1_LOW_0;";
         entryHeader += "M1_CLOSE_0;";
         entryHeader += "M1_TIME_1;";
         entryHeader += "M1_OPEN_1;";
         entryHeader += "M1_HIGH_1;";
         entryHeader += "M1_LOW_1;";
         entryHeader += "M1_CLOSE_1;";
         entryHeader += "M1_TIME_2;";
         entryHeader += "M1_OPEN_2;";
         entryHeader += "M1_HIGH_2;";
         entryHeader += "M1_LOW_2;";
         entryHeader += "M1_CLOSE_2;";
         entryHeader += "M1_TIME_3;";
         entryHeader += "M1_OPEN_3;";
         entryHeader += "M1_HIGH_3;";
         entryHeader += "M1_LOW_3;";
         entryHeader += "M1_CLOSE_3;";
         entryHeader += "M1_TIME_4;";
         entryHeader += "M1_OPEN_4;";
         entryHeader += "M1_HIGH_4;";
         entryHeader += "M1_LOW_4;";
         entryHeader += "M1_CLOSE_4;";
         entryHeader += "M1_TIME_5;";
         entryHeader += "M1_OPEN_5;";
         entryHeader += "M1_HIGH_5;";
         entryHeader += "M1_LOW_5;";
         entryHeader += "M1_CLOSE_5";
         entryHeader += "\r\n";

         if(FileWriteString(entryHandle, entryHeader) == 0)
         {
            Print(
               "PHX Research Entry Journal ERROR: Header write failed. Error=",
               GetLastError()
            );
            FileClose(entryHandle);
            m_initialized = false;
            return false;
         }

         FileFlush(entryHandle);
      }

      FileClose(entryHandle);
      m_initialized = true;
      return true;
   }

   //--------------------------------------------------
   // Shutdown
   //--------------------------------------------------
   void Shutdown()
   {
      m_initialized = false;
   }

   //--------------------------------------------------
   // Is Initialized
   //--------------------------------------------------
   bool IsInitialized() const
   {
      return m_initialized;
   }

   //--------------------------------------------------
   // Write Immediate Entry / Decision Snapshot
   //--------------------------------------------------
   bool WriteEntrySnapshot(
      const SPHXSignalQualityRecord &record
   )
   {
      if(!m_initialized)
         return false;

      int handle =
         FileOpen(
            m_entryFileName,
            FILE_READ |
            FILE_WRITE |
            FILE_CSV |
            FILE_SHARE_READ,
            ';'
         );

      if(handle == INVALID_HANDLE)
      {
         Print(
            "PHX Research Entry Journal ERROR: Write FileOpen failed. Error=",
            GetLastError()
         );
         return false;
      }

      FileSeek(
         handle,
         0,
         SEEK_END
      );

      string line = "";
      line += TimeToString(record.Time, TIME_DATE | TIME_SECONDS) + ";";
      line += record.Symbol + ";";
      line += IntegerToString(record.Signal) + ";";
      line += DoubleToString(record.EntryPrice, _Digits) + ";";
      line += IntegerToString((int)record.BuyAllowed) + ";";
      line += IntegerToString((int)record.SellAllowed) + ";";
      line += IntegerToString((int)record.BuyBlockTrend) + ";";
      line += IntegerToString((int)record.BuyBlockEMA) + ";";
      line += IntegerToString((int)record.BuyBlockRSI) + ";";
      line += IntegerToString((int)record.BuyBlockVolume) + ";";
      line += IntegerToString((int)record.BuyBlockCandle) + ";";
      line += IntegerToString((int)record.BuyBlockNearHigh) + ";";
      line += IntegerToString((int)record.BuyBlockNearLow) + ";";
      line += IntegerToString((int)record.SellBlockTrend) + ";";
      line += IntegerToString((int)record.SellBlockEMA) + ";";
      line += IntegerToString((int)record.SellBlockRSI) + ";";
      line += IntegerToString((int)record.SellBlockVolume) + ";";
      line += IntegerToString((int)record.SellBlockCandle) + ";";
      line += IntegerToString((int)record.SellBlockNearHigh) + ";";
      line += IntegerToString((int)record.SellBlockNearLow) + ";";
      line += DoubleToString(record.DailyATR, 5) + ";";
      line += DoubleToString(record.CurrentD1Range, 5) + ";";
      line += DoubleToString(record.EnergyUsedPercent, 2) + ";";
      line += DoubleToString(record.EnergyLeftPercent, 2) + ";";
      line += DoubleToString(record.ATR, 5) + ";";
      line += DoubleToString(record.RSI, 2) + ";";
      line += IntegerToString((int)record.RSIExit70) + ";";
      line += IntegerToString((int)record.RSIExit75) + ";";
      line += IntegerToString((int)record.RSIExit78) + ";";
      line += DoubleToString(record.ADX, 2) + ";";
      line += IntegerToString(record.Trend) + ";";
      line += IntegerToString(record.Score) + ";";
      line += IntegerToString(record.EMAScore) + ";";
      line += IntegerToString(record.ATRScore) + ";";
      line += IntegerToString(record.RSIScore) + ";";
      line += IntegerToString(record.VolumeScore) + ";";
      line += IntegerToString(record.ADXScore) + ";";
      line += IntegerToString(record.MarketScore) + ";";
      line += IntegerToString(record.MTFScore) + ";";
      line += IntegerToString(record.HigherTFTrend) + ";";
      line += IntegerToString(record.SignalTFTrend) + ";";
      line += IntegerToString(record.EntryTFTrend) + ";";
      line += DoubleToString(record.EntryEMASlope, 6) + ";";
      line += DoubleToString(record.EntryEMADistance, 6) + ";";
      //--------------------------------------------------
      // Market Phase Diagnostics
      //--------------------------------------------------

      line += IntegerToString((int)record.MarketPhase) + ";";
      line += IntegerToString((int)record.BuyExhaustionRisk) + ";";
      line += IntegerToString((int)record.SellExhaustionRisk) + ";";
      line += IntegerToString(record.M1BullSequence) + ";";
      line += IntegerToString(record.M1BearSequence) + ";";
      line += DoubleToString(record.RSIChange, 2) + ";";
      line += DoubleToString(record.EMASlopeChange, 6) + ";";

      line += IntegerToString((int)record.ResearchTF) + ";";
      line += TimeToString(record.M5Time, TIME_DATE | TIME_SECONDS) + ";";
      line += DoubleToString(record.M5Open, _Digits) + ";";
      line += DoubleToString(record.M5High, _Digits) + ";";
      line += DoubleToString(record.M5Low, _Digits) + ";";
      line += DoubleToString(record.M5Close, _Digits) + ";";
      line += DoubleToString(record.M5Range, _Digits) + ";";
      line += TimeToString(record.M1Time0, TIME_DATE | TIME_SECONDS) + ";";
      line += DoubleToString(record.M1Open0, _Digits) + ";";
      line += DoubleToString(record.M1High0, _Digits) + ";";
      line += DoubleToString(record.M1Low0, _Digits) + ";";
      line += DoubleToString(record.M1Close0, _Digits) + ";";
      line += TimeToString(record.M1Time1, TIME_DATE | TIME_SECONDS) + ";";
      line += DoubleToString(record.M1Open1, _Digits) + ";";
      line += DoubleToString(record.M1High1, _Digits) + ";";
      line += DoubleToString(record.M1Low1, _Digits) + ";";
      line += DoubleToString(record.M1Close1, _Digits) + ";";
      line += TimeToString(record.M1Time2, TIME_DATE | TIME_SECONDS) + ";";
      line += DoubleToString(record.M1Open2, _Digits) + ";";
      line += DoubleToString(record.M1High2, _Digits) + ";";
      line += DoubleToString(record.M1Low2, _Digits) + ";";
      line += DoubleToString(record.M1Close2, _Digits) + ";";
      line += TimeToString(record.M1Time3, TIME_DATE | TIME_SECONDS) + ";";
      line += DoubleToString(record.M1Open3, _Digits) + ";";
      line += DoubleToString(record.M1High3, _Digits) + ";";
      line += DoubleToString(record.M1Low3, _Digits) + ";";
      line += DoubleToString(record.M1Close3, _Digits) + ";";
      line += TimeToString(record.M1Time4, TIME_DATE | TIME_SECONDS) + ";";
      line += DoubleToString(record.M1Open4, _Digits) + ";";
      line += DoubleToString(record.M1High4, _Digits) + ";";
      line += DoubleToString(record.M1Low4, _Digits) + ";";
      line += DoubleToString(record.M1Close4, _Digits) + ";";
      line += TimeToString(record.M1Time5, TIME_DATE | TIME_SECONDS) + ";";
      line += DoubleToString(record.M1Open5, _Digits) + ";";
      line += DoubleToString(record.M1High5, _Digits) + ";";
      line += DoubleToString(record.M1Low5, _Digits) + ";";
      line += DoubleToString(record.M1Close5, _Digits);
      line += "\r\n";

      if(FileWriteString(handle, line) == 0)
      {
         Print(
            "PHX Research Entry Journal ERROR: FileWriteString failed. Error=",
            GetLastError()
         );
         FileClose(handle);
         return false;
      }

      FileFlush(handle);
      FileClose(handle);
      return true;
   }

   //--------------------------------------------------
   // Write Completed Record
   //--------------------------------------------------
   bool Write(
      const SPHXSignalQualityRecord &record
   )
   {
      if(!m_initialized)
         return false;

      //--------------------------------------------------
      // Research Journal accepts only
      // fully completed quality records
      //--------------------------------------------------
      if(!record.Completed20)
         return false;

      //--------------------------------------------------
      // Open journal
      //--------------------------------------------------
      int handle =
         FileOpen(
            m_fileName,
            FILE_READ |
            FILE_WRITE |
            FILE_CSV |
            FILE_SHARE_READ,
            ';'
         );

      if(handle == INVALID_HANDLE)
      {
         Print(
            "PHX Research Journal ERROR: Write FileOpen failed. Error=",
            GetLastError()
         );
         return false;
      }

      //--------------------------------------------------
      // Append
      //--------------------------------------------------
      FileSeek(
         handle,
         0,
         SEEK_END
      );

      //--------------------------------------------------
      // Build one physical CSV line.
      // FileWrite() cannot accept this many parameters.
      //--------------------------------------------------
      string line = "";
      line += TimeToString(record.Time, TIME_DATE | TIME_SECONDS) + ";";
      line += record.Symbol + ";";
      line += IntegerToString((int)record.Ticket) + ";";
      line += IntegerToString(record.Signal) + ";";
      line += DoubleToString(record.EntryPrice, _Digits) + ";";
      line += DoubleToString(record.CandlePosition, 3) + ";";
      line += IntegerToString((int)record.ExecutionDelayMS) + ";";
      line += DoubleToString(record.PriceVsCandleHigh, _Digits) + ";";
      line += DoubleToString(record.DailyATR, 5) + ";";
      line += DoubleToString(record.CurrentD1Range, 5) + ";";
      line += DoubleToString(record.EnergyUsedPercent, 2) + ";";
      line += DoubleToString(record.EnergyLeftPercent, 2) + ";";
      line += DoubleToString(record.ATR, 5) + ";";
      line += DoubleToString(record.RSI, 2) + ";";
      line += IntegerToString((int)record.RSIExit70) + ";";
      line += IntegerToString((int)record.RSIExit75) + ";";
      line += IntegerToString((int)record.RSIExit78) + ";";
      line += IntegerToString((int)record.BuyAllowed) + ";";
      line += IntegerToString((int)record.SellAllowed) + ";";
      line += IntegerToString((int)record.BuyBlockTrend) + ";";
      line += IntegerToString((int)record.BuyBlockEMA) + ";";
      line += IntegerToString((int)record.BuyBlockRSI) + ";";
      line += IntegerToString((int)record.BuyBlockVolume) + ";";
      line += IntegerToString((int)record.BuyBlockCandle) + ";";
      line += IntegerToString((int)record.BuyBlockNearHigh) + ";";
      line += IntegerToString((int)record.BuyBlockNearLow) + ";";
      line += IntegerToString((int)record.SellBlockTrend) + ";";
      line += IntegerToString((int)record.SellBlockEMA) + ";";
      line += IntegerToString((int)record.SellBlockRSI) + ";";
      line += IntegerToString((int)record.SellBlockVolume) + ";";
      line += IntegerToString((int)record.SellBlockCandle) + ";";
      line += IntegerToString((int)record.SellBlockNearHigh) + ";";
      line += IntegerToString((int)record.SellBlockNearLow) + ";";
      line += DoubleToString(record.ADX, 2) + ";";
      line += IntegerToString(record.Trend) + ";";
      line += IntegerToString(record.Score) + ";";
      line += IntegerToString(record.EMAScore) + ";";
      line += IntegerToString(record.ATRScore) + ";";
      line += IntegerToString(record.RSIScore) + ";";
      line += IntegerToString(record.VolumeScore) + ";";
      line += IntegerToString(record.ADXScore) + ";";
      line += IntegerToString(record.MarketScore) + ";";
      line += IntegerToString(record.MTFScore) + ";";
      line += IntegerToString(record.HigherTFTrend) + ";";
      line += IntegerToString(record.SignalTFTrend) + ";";
      line += IntegerToString(record.EntryTFTrend) + ";";
      line += DoubleToString(record.EntryEMASlope, 6) + ";";
      line += DoubleToString(record.EntryEMADistance, 6) + ";";
      //--------------------------------------------------
      // Market Phase Diagnostics
      //--------------------------------------------------

line += IntegerToString(record.MarketPhase);
line += ";";

line += record.BuyExhaustionRisk ? "1" : "0";
line += ";";

line += record.SellExhaustionRisk ? "1" : "0";
line += ";";

line += IntegerToString(record.M1BullSequence);
line += ";";

line += IntegerToString(record.M1BearSequence);
line += ";";

line += DoubleToString(record.RSIChange,2);
line += ";";

line += DoubleToString(record.EMASlopeChange,6);
line += ";";

      line += DoubleToString(record.PriceAfter5, _Digits) + ";";
      line += DoubleToString(record.Change5, 5) + ";";
      line += DoubleToString(record.PriceAfter10, _Digits) + ";";
      line += DoubleToString(record.Change10, 5) + ";";
      line += DoubleToString(record.PriceAfter20, _Digits) + ";";
      line += DoubleToString(record.Change20, 5) + ";";
      line += IntegerToString((int)record.ResearchTF) + ";";
      line += IntegerToString((int)record.HasDivergence) + ";";
      line += IntegerToString((int)record.DivergenceType) + ";";
      line += IntegerToString((int)record.DivergenceContext) + ";";
      line += DoubleToString(record.DivergencePriceDeltaNorm, 5) + ";";
      line += DoubleToString(record.DivergencePPODeltaNorm, 5) + ";";
      line += IntegerToString(record.DivergenceMatchOffset1Bars) + ";";
      line += IntegerToString(record.DivergenceMatchOffset2Bars) + ";";
      line += IntegerToString((int)record.DivergenceProfileValid) + ";";
      line += DoubleToString(record.DivergenceRSI, 2) + ";";
      line += DoubleToString(record.DivergenceADX, 2) + ";";
      line += IntegerToString((int)record.DivergenceADXDirection) + ";";
      line += DoubleToString(record.DivergenceRelativeVolume, 5) + ";";
      line += IntegerToString((int)record.DivergenceVolumeDirection) + ";";
      line += IntegerToString((int)record.DivergenceStructureConfirmed) + ";";
      line += DoubleToString(record.DivergenceBreakDistanceNorm, 5) + ";";
      line += IntegerToString(record.DivergenceConfirmationDelayBars);
      line += "\r\n";

      if(FileWriteString(handle, line) == 0)
      {
         Print(
            "PHX Research Journal ERROR: FileWriteString failed. Error=",
            GetLastError()
         );
         FileClose(handle);
         return false;
      }

      FileFlush(handle);
      FileClose(handle);
      return true;
   }
};

#endif
