#ifndef PHX_TREND_STATISTICS_TYPES_MQH
#define PHX_TREND_STATISTICS_TYPES_MQH

//--------------------------------------------------
// Base Types
//--------------------------------------------------
#include "../Core/PHXStatisticsTypes.mqh"
#include "../Signal/PHXTrendTypes.mqh"
#include "../Signal/PHXTrendScoreTypes.mqh"
#include "../Signal/PHXSignalTypes.mqh"
//+------------------------------------------------------------------+
//| Trend Snapshot                                                   |
//+------------------------------------------------------------------+
struct SPHXTrendSnapshot
{
   //--------------------------------------------------
   // Header
   //--------------------------------------------------
   SPHXStatisticsHeader Header;
   //--------------------------------------------------
   // OHLC
   //--------------------------------------------------
   double Open;
   double High;
   double Low;
   double Close;
   //--------------------------------------------------
   // EMA
   //--------------------------------------------------
   double EMA20;
   double EMA50;
   double EMA100;
   double EMA200;  
   //--------------------------------------------------
   // MA2
   //--------------------------------------------------
   double MA2;
   //--------------------------------------------------
   // Entry Timing / Market Phase
   //--------------------------------------------------
   double RSIChange;
   double EMASlope;
   double EMASlopeChange;
   int MomentumDirection;
   int MomentumScore;
   //--------------------------------------------------
   // Trend transition diagnostics
   //--------------------------------------------------
   ENUM_PHX_TREND PreviousTrend;
   int BarsSinceTrendChange;
   int M1BullSequence;
   int M1BearSequence;
   ENUM_PHX_MARKET_PHASE MarketPhase;
   //--------------------------------------------------
   // Trend
   //--------------------------------------------------
   ENUM_PHX_TREND Trend;
   ENUM_PHX_TREND_STRENGTH Strength;
   //--------------------------------------------------
   // Scores
   //--------------------------------------------------
   SPHXTrendScore Score;
   //--------------------------------------------------
   // Market
   //--------------------------------------------------
   double ATR;
   double RSI;
   long Volume;
   double AverageVolume;  
   //--------------------------------------------------
   // ADX
   //--------------------------------------------------
   double ADX;
   double PlusDI;
   double MinusDI;
   int Spread;
   bool SessionOpen;
   bool HighLiquidity;
   //--------------------------------------------------
   // Future
   //--------------------------------------------------
   double FutureClose5;
   double FutureClose10;
   double FutureClose20;
   //--------------------------------------------------
   // Excursions
   //--------------------------------------------------
   double MaxProfit;
   double MaxLoss;
   //--------------------------------------------------
   // Validation
   //--------------------------------------------------
   ENUM_PHX_SIGNAL_RESULT BuyResult;
   ENUM_PHX_SIGNAL_RESULT SellResult;
   //--------------------------------------------------
   // Reset
   //--------------------------------------------------
   void Reset()
   {

      Header.Reset();

      Open = 0;

      High = 0;

      Low = 0;

      Close = 0;

      EMA20 = 0;

      EMA50 = 0;

      EMA100 = 0;

      EMA200 = 0;
      
      MA2 = 0;
      
      //--------------------------------------------------
      // Entry Timing / Market Phase
      //--------------------------------------------------
      RSIChange = 0.0;
      EMASlope = 0.0;
      EMASlopeChange = 0.0;
      MomentumDirection = 0;
      MomentumScore = 0;   
      M1BullSequence = 0;
      M1BearSequence = 0;

      MarketPhase =
      PHX_PHASE_UNKNOWN;

      Trend = PHX_TREND_UNKNOWN;

      Strength = PHX_TREND_WEAK;

      Score.Reset();

      ATR = 0;

      RSI = 0;

      Volume = 0;

      AverageVolume = 0;
      
      ADX = 0;

      PlusDI = 0;

      MinusDI = 0;

      Spread = 0;

      SessionOpen = false;

      HighLiquidity = false;

      FutureClose5 = 0;

      FutureClose10 = 0;

      FutureClose20 = 0;

      MaxProfit = 0;

      MaxLoss = 0;

      BuyResult = PHX_RESULT_UNKNOWN;

      SellResult = PHX_RESULT_UNKNOWN;

   }

};

#endif