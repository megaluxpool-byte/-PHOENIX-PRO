#ifndef PHX_TREND_SNAPSHOT_BUILDER_MQH
#define PHX_TREND_SNAPSHOT_BUILDER_MQH

//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXTrendStatisticsTypes.mqh"
#include "../Signal/IPHXTrendScoreProvider.mqh"
#include "../Market/IPHXMarketSnapshotProvider.mqh"
#include "../Market/PHXMarketSnapshotProvider.mqh"
#include "../Indicators/IPHXEMAProvider.mqh"
#include "../Indicators/IPHXMarketIndicatorProvider.mqh"
#include "../Market/IPHXMarketStateProvider.mqh"
#include "../Statistics/IPHXFutureProjectionProvider.mqh"

//+------------------------------------------------------------------+
//| Trend Snapshot Builder                                           |
//+------------------------------------------------------------------+
class CPHXTrendSnapshotBuilder
{

private:

   //--------------------------------------------------
   // Current Snapshot
   //--------------------------------------------------

   SPHXTrendSnapshot m_snapshot;
   
   //--------------------------------------------------
// M1 Entry Timing State
//--------------------------------------------------

datetime m_lastM1BarTime;

bool m_dynamicsInitialized;

double m_previousRSI;

double m_previousEMASlope;

double m_currentRSIChange;
double m_currentEMASlope;
double m_currentEMASlopeChange;

int m_currentM1BullSequence;
int m_currentM1BearSequence;


   //--------------------------------------------------
   // Trend Score Service
   //--------------------------------------------------

   IPHXTrendScoreProvider *m_trendScoreProvider;
   
   IPHXMarketSnapshotProvider *m_marketProvider;
   
   IPHXMarketSnapshotProvider *m_marketSnapshotProvider;
         
   IPHXEMAProvider *m_emaProvider;
      
   IPHXMarketIndicatorProvider *m_indicatorProvider;
   
   IPHXMarketStateProvider *m_marketStateProvider;
   
   IPHXFutureProjectionProvider *m_futureProvider;
   
   
      
public:

   //--------------------------------------------------
   // Constructor / Destructor
   //--------------------------------------------------

   CPHXTrendSnapshotBuilder();

   ~CPHXTrendSnapshotBuilder();

  
bool SetMarketSnapshotProvider(
   IPHXMarketSnapshotProvider *provider
);
public:

   //--------------------------------------------------
   // Reset
   //--------------------------------------------------

   void Reset();
   
   void SetTrendScoreProvider(
   IPHXTrendScoreProvider *provider
);

   void SetMarketProvider(
   IPHXMarketSnapshotProvider *provider
);

   void SetEMAProvider(
   IPHXEMAProvider *provider
);

   void SetIndicatorProvider(
   IPHXMarketIndicatorProvider *provider
);

   void SetMarketStateProvider(
   IPHXMarketStateProvider *provider
);

   void SetFutureProjectionProvider(
   IPHXFutureProjectionProvider *provider
);

      
   //--------------------------------------------------
   // Build Snapshot
   //--------------------------------------------------

   bool Build(
      
      SPHXTrendSnapshot &snapshot
   );

};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXTrendSnapshotBuilder::CPHXTrendSnapshotBuilder()
{

   m_trendScoreProvider = NULL;
   m_marketProvider = NULL;
   m_marketSnapshotProvider = NULL;
   m_emaProvider = NULL;
   m_indicatorProvider = NULL;
   m_marketStateProvider = NULL;
   m_futureProvider = NULL;

   m_snapshot.Reset();
   //--------------------------------------------------
// M1 Entry Timing State
//--------------------------------------------------

m_lastM1BarTime =
   0;

m_dynamicsInitialized =
   false;

m_previousRSI =
   0.0;


m_previousEMASlope =
   0.0;

m_currentRSIChange =
   0.0;

m_currentEMASlope =
   0.0;

m_currentEMASlopeChange =
   0.0;

m_currentM1BullSequence =
   0;

m_currentM1BearSequence =
   0;

}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXTrendSnapshotBuilder::~CPHXTrendSnapshotBuilder()
{
   Reset();
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXTrendSnapshotBuilder::Reset()
{
   m_snapshot.Reset();

   //--------------------------------------------------
   // M1 Entry Timing State
   //--------------------------------------------------

   m_lastM1BarTime =
      0;

   m_dynamicsInitialized =
      false;

   m_previousRSI =
      0.0;


   m_previousEMASlope =
      0.0;

   m_currentRSIChange =
      0.0;

   m_currentEMASlope =
      0.0;

   m_currentEMASlopeChange =
      0.0;

   m_currentM1BullSequence =
      0;

   m_currentM1BearSequence =
      0;
}
//+------------------------------------------------------------------+
//| Set Trend Score Provider                                         |
//+------------------------------------------------------------------+
void CPHXTrendSnapshotBuilder::SetTrendScoreProvider(
   IPHXTrendScoreProvider *provider
)
{

   m_trendScoreProvider = provider;

}

//+------------------------------------------------------------------+
//| Set Market Provider                                              |
//+------------------------------------------------------------------+
void CPHXTrendSnapshotBuilder::SetMarketProvider(
   IPHXMarketSnapshotProvider *provider
)
{

   m_marketProvider = provider;

}

//+------------------------------------------------------------------+
//| Set EMA Provider                                                 |
//+------------------------------------------------------------------+
   void CPHXTrendSnapshotBuilder::SetEMAProvider(
   IPHXEMAProvider *provider
)
{

   m_emaProvider = provider;

}

//+------------------------------------------------------------------+
//| Set Indicator Provider                                           |
//+------------------------------------------------------------------+
void CPHXTrendSnapshotBuilder::SetIndicatorProvider(
   IPHXMarketIndicatorProvider *provider
)
{

   m_indicatorProvider = provider;

}

//+------------------------------------------------------------------+
//| Set Market State Provider                                        |
//+------------------------------------------------------------------+
void CPHXTrendSnapshotBuilder::SetMarketStateProvider(
   IPHXMarketStateProvider *provider
)
{

   m_marketStateProvider = provider;

}

//+------------------------------------------------------------------+
//| Set Future Projection Provider                                   |
//+------------------------------------------------------------------+
void CPHXTrendSnapshotBuilder::SetFutureProjectionProvider(
   IPHXFutureProjectionProvider *provider
)
{

   m_futureProvider = provider;

}


//+------------------------------------------------------------------+
//| Set Market Snapshot Provider                                     |
//+------------------------------------------------------------------+
bool CPHXTrendSnapshotBuilder::SetMarketSnapshotProvider(
   IPHXMarketSnapshotProvider *provider
)
{

   if(provider == NULL)
      return false;


   m_marketSnapshotProvider = provider;


   return true;

}

//+------------------------------------------------------------------+
//| Build Snapshot                                                   |
//+------------------------------------------------------------------+
bool CPHXTrendSnapshotBuilder::Build(
   SPHXTrendSnapshot &snapshot
)
{

   //--------------------------------------------------
   // Reset internal snapshot
   //--------------------------------------------------

   m_snapshot.Reset();
   
   //--------------------------------------------------
   // Market Snapshot
   //--------------------------------------------------

   if(m_marketSnapshotProvider == NULL)
   return false;


   snapshot.Open =
   (*m_marketSnapshotProvider).Open();


   snapshot.High =
   (*m_marketSnapshotProvider).High();


   snapshot.Low =
   (*m_marketSnapshotProvider).Low();


   snapshot.Close =
   (*m_marketSnapshotProvider).Close();
   
   //--------------------------------------------------
   // Header
   //--------------------------------------------------

   m_snapshot.Header.Type =
   PHX_STAT_TREND;


   m_snapshot.Header.State =
   PHX_RECORD_COLLECTING;


   m_snapshot.Header.Time =
   TimeCurrent();
   
   //--------------------------------------------------
   // Market OHLC
   //--------------------------------------------------

   if(m_marketProvider != NULL)
{

   m_snapshot.Open =
      (*m_marketProvider).Open();


   m_snapshot.High =
      (*m_marketProvider).High();


   m_snapshot.Low =
      (*m_marketProvider).Low();


   m_snapshot.Close =
      (*m_marketProvider).Close();


   m_snapshot.Header.BarIndex =
      (*m_marketProvider).BarIndex();


   m_snapshot.Header.TickIndex =
      (*m_marketProvider).TickIndex();

}

   //--------------------------------------------------
   // EMA Values
   //--------------------------------------------------

   if(m_emaProvider != NULL)
   {

   m_snapshot.EMA20 =
      (*m_emaProvider).EMA20();


   m_snapshot.EMA50 =
      (*m_emaProvider).EMA50();


   m_snapshot.EMA100 =
      (*m_emaProvider).EMA100();


   m_snapshot.EMA200 =
      (*m_emaProvider).EMA200();

}

   //--------------------------------------------------
   // Market Indicators
   //--------------------------------------------------

   if(m_indicatorProvider != NULL)
{

   m_snapshot.ATR =
      (*m_indicatorProvider).ATR();


   m_snapshot.RSI =
      (*m_indicatorProvider).RSI();


   m_snapshot.Volume =
      (*m_indicatorProvider).Volume();


   m_snapshot.AverageVolume =
      (*m_indicatorProvider).AverageVolume();
      
   //--------------------------------------------------
   // ADX
   //--------------------------------------------------

   m_snapshot.ADX =
   (*m_indicatorProvider).ADX();


   m_snapshot.PlusDI =
   (*m_indicatorProvider).PlusDI();


   m_snapshot.MinusDI =
   (*m_indicatorProvider).MinusDI();

}

   //--------------------------------------------------
   // MA2
   //--------------------------------------------------

   m_snapshot.MA2 =
   (*m_indicatorProvider).MA2();
//--------------------------------------------------
// M1 Entry Timing Dynamics
//--------------------------------------------------

datetime currentM1BarTime =
   iTime(
      _Symbol,
      PERIOD_M1,
      0
   );


if(
   currentM1BarTime > 0 &&
   currentM1BarTime != m_lastM1BarTime
)
{
   //--------------------------------------------------
   // New M1 bar
   //--------------------------------------------------

   m_lastM1BarTime =
      currentM1BarTime;


   //--------------------------------------------------
   // RSI / EMA dynamics
   //--------------------------------------------------

  if(m_dynamicsInitialized)
{
   //--------------------------------------------------
   // RSI dynamics
   //--------------------------------------------------

   m_currentRSIChange =
      m_snapshot.RSI -
      m_previousRSI;


   //--------------------------------------------------
   // EMA20 M1 3-bar slope
   //--------------------------------------------------

   double ema20Current =
      0.0;

   double ema20Shift3 =
      0.0;


   if(
      m_emaProvider != NULL &&
      (*m_emaProvider).EMA20AtShift(
         0,
         ema20Current
      ) &&
      (*m_emaProvider).EMA20AtShift(
         3,
         ema20Shift3
      )
   )
   {
      m_currentEMASlope =
         (
            ema20Current -
            ema20Shift3
         ) /
         3.0;


      m_currentEMASlopeChange =
         m_currentEMASlope -
         m_previousEMASlope;
   }
   else
   {
      m_currentEMASlope =
         0.0;

      m_currentEMASlopeChange =
         0.0;
   }
}
else
{
   m_currentRSIChange =
      0.0;

   m_currentEMASlope =
      0.0;

   m_currentEMASlopeChange =
      0.0;

   m_dynamicsInitialized =
      true;
}

   //--------------------------------------------------
   // Store current values for next M1 bar
   //--------------------------------------------------

   m_previousRSI =
      m_snapshot.RSI;


   

   m_previousEMASlope =
      m_currentEMASlope;


   //--------------------------------------------------
   // Closed M1 candles
   //--------------------------------------------------

   MqlRates m1Rates[5];

   if(
      CopyRates(
         _Symbol,
         PERIOD_M1,
         1,
         5,
         m1Rates
      ) == 5
   )
   {
      //--------------------------------------------------
      // Bullish close sequence
      //--------------------------------------------------

      m_currentM1BullSequence =
         0;


      for(int i = 4; i > 0; i--)
      {
         if(
            m1Rates[i].close >
            m1Rates[i - 1].close
         )
         {
            m_currentM1BullSequence++;
         }
         else
         {
            break;
         }
      }


      //--------------------------------------------------
      // Bearish close sequence
      //--------------------------------------------------

      m_currentM1BearSequence =
         0;


      for(int i = 4; i > 0; i--)
      {
         if(
            m1Rates[i].close <
            m1Rates[i - 1].close
         )
         {
            m_currentM1BearSequence++;
         }
         else
         {
            break;
         }
      }
   }
}
Print(
   "PHX PRESSURE DEBUG: ",
   "ADX=",
   DoubleToString(m_snapshot.ADX,2),

   " PlusDI=",
   DoubleToString(m_snapshot.PlusDI,2),

   " MinusDI=",
   DoubleToString(m_snapshot.MinusDI,2),

   " RSI=",
   DoubleToString(m_snapshot.RSI,2),

   " RSIChange=",
   DoubleToString(m_currentRSIChange,4),

   " EMASlopeChange=",
   DoubleToString(m_currentEMASlopeChange,6),

   " M1Bull=",
   IntegerToString(m_currentM1BullSequence),

   " M1Bear=",
   IntegerToString(m_currentM1BearSequence)
);

//--------------------------------------------------
// Publish current M1 timing state into snapshot
//--------------------------------------------------

m_snapshot.RSIChange =
   m_currentRSIChange;


m_snapshot.EMASlope =
   m_currentEMASlope;


m_snapshot.EMASlopeChange =
   m_currentEMASlopeChange;


m_snapshot.M1BullSequence =
   m_currentM1BullSequence;


m_snapshot.M1BearSequence =
   m_currentM1BearSequence;
   //--------------------------------------------------
   // Market State
   //--------------------------------------------------

   if(m_marketStateProvider != NULL)
{

   m_snapshot.Spread =
      (*m_marketStateProvider).Spread();


   m_snapshot.SessionOpen =
      (*m_marketStateProvider).SessionOpen();


   m_snapshot.HighLiquidity =
      (*m_marketStateProvider).HighLiquidity();

}



   //--------------------------------------------------
   // Future Projection
   //--------------------------------------------------

   if(m_futureProvider != NULL)
{

   m_snapshot.FutureClose5 =
      (*m_futureProvider).FutureClose5();


   m_snapshot.FutureClose10 =
      (*m_futureProvider).FutureClose10();


   m_snapshot.FutureClose20 =
      (*m_futureProvider).FutureClose20();

}


   //--------------------------------------------------
   // Trend Score
   //--------------------------------------------------

   if(m_trendScoreProvider != NULL)
{

   if((*m_trendScoreProvider).Calculate(m_snapshot))
   {

      m_snapshot.Score =
         (*m_trendScoreProvider).GetScore();

   }

}

   //--------------------------------------------------
   // Copy result
   //--------------------------------------------------

   snapshot = m_snapshot;


   return true;

}

#endif // PHX_TREND_SNAPSHOT_BUILDER_MQH