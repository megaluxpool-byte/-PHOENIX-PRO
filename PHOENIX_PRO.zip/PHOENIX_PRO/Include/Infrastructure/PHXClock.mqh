//+------------------------------------------------------------------+
//|                    PHXClock.mqh                                  |
//|              PHOENIX PRO Trading Framework                       |
//+------------------------------------------------------------------+
#ifndef __PHX_CLOCK_MQH__
#define __PHX_CLOCK_MQH__


//+------------------------------------------------------------------+
//| Clock Service                                                    |
//+------------------------------------------------------------------+
class CPHXClock
{

private:

   bool m_initialized;


   datetime m_serverTime;

   datetime m_localTime;

   datetime m_lastTickTime;



public:

   CPHXClock();

   ~CPHXClock();



public:

   bool Initialize();


   void Shutdown();


   void Reset();


   bool IsInitialized() const;



public:

   bool UpdateClock();



public:

   datetime ServerTime() const;


   datetime LocalTime() const;


   datetime LastTickTime() const;

};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXClock::CPHXClock()
{
   m_initialized = false;

   m_serverTime  = 0;

   m_localTime   = 0;

   m_lastTickTime = 0;
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXClock::~CPHXClock()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXClock::Initialize()
{
   if(m_initialized)
      return true;


   Reset();


   m_initialized = true;


   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXClock::Shutdown()
{
   if(!m_initialized)
      return;


   Reset();


   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXClock::Reset()
{
   m_serverTime   = 0;

   m_localTime    = 0;

   m_lastTickTime = 0;
}


//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXClock::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| Update Clock                                                     |
//+------------------------------------------------------------------+
bool CPHXClock::UpdateClock()
{
   if(!m_initialized)
      return false;


   m_serverTime = TimeTradeServer();

   m_localTime = TimeLocal();

   m_lastTickTime = TimeCurrent();


   return true;
}


//+------------------------------------------------------------------+
//| Get Server Time                                                  |
//+------------------------------------------------------------------+
datetime CPHXClock::ServerTime() const
{
   return m_serverTime;
}


//+------------------------------------------------------------------+
//| Get Local Time                                                   |
//+------------------------------------------------------------------+
datetime CPHXClock::LocalTime() const
{
   return m_localTime;
}


//+------------------------------------------------------------------+
//| Get Last Tick Time                                               |
//+------------------------------------------------------------------+
datetime CPHXClock::LastTickTime() const
{
   return m_lastTickTime;
}


#endif // __PHX_CLOCK_MQH__