//+------------------------------------------------------------------+
//|              PHXPerformanceMonitor.mqh                           |
//|             PHOENIX PRO Trading Framework                        |
//+------------------------------------------------------------------+
#ifndef __PHX_PERFORMANCE_MONITOR_MQH__
#define __PHX_PERFORMANCE_MONITOR_MQH__


//+------------------------------------------------------------------+
//| Performance Monitor                                              |
//+------------------------------------------------------------------+
class CPHXPerformanceMonitor
{

private:

   bool m_initialized;


   // Last measurement
   ulong m_lastExecutionTime;


   // Statistics
   ulong m_totalCalls;

   ulong m_totalExecutionTime;



public:

   CPHXPerformanceMonitor();

   ~CPHXPerformanceMonitor();



public:

   bool Initialize();

   void Shutdown();

   void Reset();


   bool IsInitialized() const;



public:

   void StartTimer();


   void StopTimer();



public:

   ulong GetLastExecutionTime() const;


   ulong GetAverageExecutionTime() const;


   ulong GetTotalCalls() const;

};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXPerformanceMonitor::CPHXPerformanceMonitor()
{
   m_initialized          = false;

   m_lastExecutionTime    = 0;

   m_totalCalls           = 0;

   m_totalExecutionTime   = 0;
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXPerformanceMonitor::~CPHXPerformanceMonitor()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXPerformanceMonitor::Initialize()
{
   if(m_initialized)
      return true;


   Reset();


   m_initialized = true;


   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXPerformanceMonitor::Shutdown()
{
   if(!m_initialized)
      return;


   Reset();


   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXPerformanceMonitor::Reset()
{
   m_lastExecutionTime  = 0;

   m_totalCalls         = 0;

   m_totalExecutionTime = 0;
}


//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXPerformanceMonitor::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| Start Timer                                                      |
//+------------------------------------------------------------------+
void CPHXPerformanceMonitor::StartTimer()
{
   if(!m_initialized)
      return;


   m_lastExecutionTime = GetMicrosecondCount();
}


//+------------------------------------------------------------------+
//| Stop Timer                                                       |
//+------------------------------------------------------------------+
void CPHXPerformanceMonitor::StopTimer()
{
   if(!m_initialized)
      return;


   ulong endTime = GetMicrosecondCount();


   if(m_lastExecutionTime == 0)
      return;


   ulong executionTime = endTime - m_lastExecutionTime;


   m_lastExecutionTime = executionTime;


   m_totalExecutionTime += executionTime;


   m_totalCalls++;
}


//+------------------------------------------------------------------+
//| Get Last Execution Time                                          |
//+------------------------------------------------------------------+
ulong CPHXPerformanceMonitor::GetLastExecutionTime() const
{
   return m_lastExecutionTime;
}


//+------------------------------------------------------------------+
//| Get Average Execution Time                                       |
//+------------------------------------------------------------------+
ulong CPHXPerformanceMonitor::GetAverageExecutionTime() const
{
   if(m_totalCalls == 0)
      return 0;


   return m_totalExecutionTime / m_totalCalls;
}


//+------------------------------------------------------------------+
//| Get Total Calls                                                   |
//+------------------------------------------------------------------+
ulong CPHXPerformanceMonitor::GetTotalCalls() const
{
   return m_totalCalls;
}


#endif // __PHX_PERFORMANCE_MONITOR_MQH__