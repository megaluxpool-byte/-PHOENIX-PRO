//+------------------------------------------------------------------+
//|                                           PHXBuildInfo.mqh       |
//|                  PHOENIX PRO Trading Framework                   |
//|                                                                  |
//| Description:                                                     |
//|   Framework build information service                            |
//+------------------------------------------------------------------+
#ifndef __PHX_BUILD_INFO_MQH__
#define __PHX_BUILD_INFO_MQH__


//+------------------------------------------------------------------+
//| Build Information Service                                        |
//+------------------------------------------------------------------+
class CPHXBuildInfo
{
private:

   string m_frameworkName;

   string m_version;

   string m_buildDate;

   string m_buildTime;

   bool   m_initialized;


//------------------------------------------------------------------
// Constructor / Destructor
//------------------------------------------------------------------
public:

   CPHXBuildInfo();

   ~CPHXBuildInfo();


//------------------------------------------------------------------
// Lifecycle
//------------------------------------------------------------------
public:

   bool Initialize();

   void Shutdown();

   void Reset();

   bool IsInitialized() const;


//------------------------------------------------------------------
// Information Access
//------------------------------------------------------------------
public:

   string GetFrameworkName() const;

   string GetVersion() const;

   string GetBuildDate() const;

   string GetBuildTime() const;

};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXBuildInfo::CPHXBuildInfo()
{
   m_frameworkName = "";

   m_version       = "";

   m_buildDate     = "";

   m_buildTime     = "";

   m_initialized   = false;
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXBuildInfo::~CPHXBuildInfo()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXBuildInfo::Initialize()
{
   if(m_initialized)
      return true;


   m_frameworkName = "PHOENIX PRO";

m_version       = "1.0.0";

datetime current_time = TimeLocal();

m_buildDate = TimeToString(
                  current_time,
                  TIME_DATE);

m_buildTime = TimeToString(
                  current_time,
                  TIME_SECONDS);


   m_initialized = true;

   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXBuildInfo::Shutdown()
{
   if(!m_initialized)
      return;


   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXBuildInfo::Reset()
{
   Shutdown();


   m_frameworkName = "";

   m_version       = "";

   m_buildDate     = "";

   m_buildTime     = "";


   Initialize();
}


//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXBuildInfo::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| Get Framework Name                                               |
//+------------------------------------------------------------------+
string CPHXBuildInfo::GetFrameworkName() const
{
   return m_frameworkName;
}


//+------------------------------------------------------------------+
//| Get Version                                                      |
//+------------------------------------------------------------------+
string CPHXBuildInfo::GetVersion() const
{
   return m_version;
}


//+------------------------------------------------------------------+
//| Get Build Date                                                   |
//+------------------------------------------------------------------+
string CPHXBuildInfo::GetBuildDate() const
{
   return m_buildDate;
}


//+------------------------------------------------------------------+
//| Get Build Time                                                   |
//+------------------------------------------------------------------+
string CPHXBuildInfo::GetBuildTime() const
{
   return m_buildTime;
}

#endif // __PHX_BUILD_INFO_MQH__