//+------------------------------------------------------------------+
//|                                            PHXEventBus.mqh       |
//|                  PHOENIX PRO Trading Framework                   |
//|                                                                  |
//| Description:                                                     |
//|   Central event communication service                            |
//+------------------------------------------------------------------+
#ifndef __PHX_EVENT_BUS_MQH__
#define __PHX_EVENT_BUS_MQH__

//+------------------------------------------------------------------+
//| PHX Event Types                                                  |
//+------------------------------------------------------------------+
enum ENUM_PHX_EVENT_TYPE
{
   PHX_EVENT_NONE = 0,
   PHX_EVENT_SYSTEM_START,
   PHX_EVENT_SYSTEM_READY,
   PHX_EVENT_SYSTEM_STOP,
   PHX_EVENT_TICK,
   PHX_EVENT_TIMER,
   PHX_EVENT_ERROR
};
//+------------------------------------------------------------------+
//| Event Data                                                       |
//+------------------------------------------------------------------+
struct SPHXEvent
{
   ENUM_PHX_EVENT_TYPE Type;
   datetime            Time;
   long                Data;
   void Reset()
   {
      Type = PHX_EVENT_NONE;
      Time = 0;
      Data = 0;
   }
};
//+------------------------------------------------------------------+
//| PHX Event Bus                                                    |
//+------------------------------------------------------------------+
class CPHXEventBus
{
private:
   bool m_initialized;
//------------------------------------------------------------------
// Constructor / Destructor
//------------------------------------------------------------------
public:
   CPHXEventBus();
   ~CPHXEventBus();
//------------------------------------------------------------------
// Lifecycle
//------------------------------------------------------------------
public:
   bool Initialize();
   void Shutdown();
   void Reset();
   bool IsInitialized() const;
//------------------------------------------------------------------
// Event Operations
//------------------------------------------------------------------
public:
   bool Publish(
      const SPHXEvent &event);
};
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXEventBus::CPHXEventBus()
{
   m_initialized = false;
}
//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXEventBus::~CPHXEventBus()
{
   Shutdown();
}
//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXEventBus::Initialize()
{
   if(m_initialized)
      return true;
   m_initialized = true;
   return true;
}
//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXEventBus::Shutdown()
{
   if(!m_initialized)
      return;
   m_initialized = false;
}
//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXEventBus::Reset()
{
   Shutdown();
   Initialize();
}
//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXEventBus::IsInitialized() const
{
   return m_initialized;
}
//+------------------------------------------------------------------+
//| Publish Event                                                    |
//+------------------------------------------------------------------+
bool CPHXEventBus::Publish(
   const SPHXEvent &event)
{
   if(!m_initialized)
      return false;
   if(event.Type == PHX_EVENT_NONE)
      return false;
   //---------------------------------------------------------------
   // Event accepted
   //---------------------------------------------------------------
   // В текущей версии EventBus только принимает событие.
   // Реальная маршрутизация будет добавлена после появления
   // системы подписчиков.
   //---------------------------------------------------------------
   return true;
}

#endif // __PHX_EVENT_BUS_MQH__