//+------------------------------------------------------------------+
//|              PHXInfrastructureServices.mqh                      |
//|              PHOENIX PRO Trading Framework                      |
//|                                                                  |
//| Description:                                                     |
//|   Root infrastructure service container                          |
//+------------------------------------------------------------------+
#ifndef __PHX_INFRASTRUCTURE_SERVICES_MQH__
#define __PHX_INFRASTRUCTURE_SERVICES_MQH__


#include <PHOENIX_PRO/Core/PHXConfigManager.mqh>

#include <PHOENIX_PRO/Core/Logger/PHXLogger.mqh>

#include <PHOENIX_PRO/Core/PHXServiceLocator.mqh>

#include <PHOENIX_PRO/Infrastructure/PHXDiagnostics.mqh>
#include <PHOENIX_PRO/Infrastructure/PHXClock.mqh>
#include <PHOENIX_PRO/Infrastructure/PHXStateManager.mqh>
#include <PHOENIX_PRO/Infrastructure/PHXEventBus.mqh>
#include <PHOENIX_PRO/Infrastructure/PHXBuildInfo.mqh>
#include <PHOENIX_PRO/Infrastructure/PHXPerformanceMonitor.mqh>


//+------------------------------------------------------------------+
//| Infrastructure Container                                         |
//+------------------------------------------------------------------+
class CPHXInfrastructureServices
{

private:

   CPHXConfigManager*      m_config;

   CPHXLogger*             m_logger;

   CPHXServiceLocator*     m_locator;

   CPHXClock*              m_clock;

   CPHXStateManager*       m_state;

   CPHXEventBus*           m_eventBus;

   CPHXDiagnostics*        m_diagnostics;

   CPHXBuildInfo*          m_buildInfo;

   CPHXPerformanceMonitor* m_performance;


   bool m_initialized;


//------------------------------------------------------------------
// Constructor / Destructor
//------------------------------------------------------------------
public:

   CPHXInfrastructureServices();

   ~CPHXInfrastructureServices();


//------------------------------------------------------------------
// Lifecycle
//------------------------------------------------------------------
public:

   bool Initialize();

   void Shutdown();

   void Reset();

   bool IsInitialized() const;


//------------------------------------------------------------------
// Access
//------------------------------------------------------------------
public:

   CPHXConfigManager* GetConfigManager();

   CPHXLogger* GetLogger();

   CPHXServiceLocator* GetServiceLocator();

   CPHXClock* GetClock();

   CPHXStateManager* GetStateManager();

   CPHXEventBus* GetEventBus();

   CPHXDiagnostics* GetDiagnostics();

   CPHXBuildInfo* GetBuildInfo();

   CPHXPerformanceMonitor* GetPerformanceMonitor();

};


//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXInfrastructureServices::CPHXInfrastructureServices()
{

   m_config      = NULL;
   m_logger      = NULL;
   m_locator     = NULL;

   m_clock       = NULL;
   m_state       = NULL;
   m_eventBus    = NULL;

   m_diagnostics = NULL;
   m_buildInfo   = NULL;

   m_performance = NULL;


   m_initialized = false;

}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXInfrastructureServices::~CPHXInfrastructureServices()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXInfrastructureServices::Initialize()
{

   if(m_initialized)
      return true;


//---------------------------------------------------------------
// Config Manager
//---------------------------------------------------------------

   m_config = new CPHXConfigManager();

   if(m_config == NULL)
      return false;

   if(!m_config.Initialize())
      return false;


//---------------------------------------------------------------
// Build Info
//---------------------------------------------------------------

   m_buildInfo = new CPHXBuildInfo();

   if(m_buildInfo == NULL)
      return false;

   if(!m_buildInfo.Initialize())
      return false;


//---------------------------------------------------------------
// Logger
//---------------------------------------------------------------

   m_logger = new CPHXLogger();

   if(m_logger == NULL)
      return false;

   if(!m_logger.Initialize(
          m_config.GetLoggerConfig()))
   {
      return false;
   }


//---------------------------------------------------------------
// Clock
//---------------------------------------------------------------

   m_clock = new CPHXClock();

   if(m_clock == NULL)
      return false;

   if(!m_clock.Initialize())
      return false;


//---------------------------------------------------------------
// State
//---------------------------------------------------------------

   m_state = new CPHXStateManager();

   if(m_state == NULL)
      return false;

   if(!m_state.Initialize())
      return false;


//---------------------------------------------------------------
// Event Bus
//---------------------------------------------------------------

   m_eventBus = new CPHXEventBus();

   if(m_eventBus == NULL)
      return false;

   if(!m_eventBus.Initialize())
      return false;


//---------------------------------------------------------------
// Diagnostics
//---------------------------------------------------------------

   m_diagnostics = new CPHXDiagnostics();

   if(m_diagnostics == NULL)
      return false;

   if(!m_diagnostics.Initialize())
      return false;


//---------------------------------------------------------------
// Performance
//---------------------------------------------------------------

   m_performance = new CPHXPerformanceMonitor();

   if(m_performance == NULL)
      return false;

   if(!m_performance.Initialize())
      return false;


//---------------------------------------------------------------
// Service Locator
//---------------------------------------------------------------

   m_locator = new CPHXServiceLocator();

   if(m_locator == NULL)
      return false;


   m_locator.Initialize();


   m_locator.RegisterLogger(m_logger);

   m_locator.RegisterConfigManager(m_config);



   (*m_diagnostics).SetSystemReady(true);


   m_initialized = true;


   return true;

}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXInfrastructureServices::Shutdown()
{

   if(!m_initialized)
      return;



   if(m_locator != NULL)
   {
      m_locator.Shutdown();

      delete m_locator;

      m_locator = NULL;
   }



   if(m_performance != NULL)
   {
      m_performance.Shutdown();

      delete m_performance;

      m_performance = NULL;
   }



   if(m_diagnostics != NULL)
   {
      m_diagnostics.Shutdown();

      delete m_diagnostics;

      m_diagnostics = NULL;
   }



   if(m_eventBus != NULL)
   {
      m_eventBus.Shutdown();

      delete m_eventBus;

      m_eventBus = NULL;
   }



   if(m_state != NULL)
   {
      m_state.Shutdown();

      delete m_state;

      m_state = NULL;
   }



   if(m_clock != NULL)
   {
      m_clock.Shutdown();

      delete m_clock;

      m_clock = NULL;
   }



   if(m_logger != NULL)
   {
      m_logger.Shutdown();

      delete m_logger;

      m_logger = NULL;
   }



   if(m_buildInfo != NULL)
   {
      m_buildInfo.Shutdown();

      delete m_buildInfo;

      m_buildInfo = NULL;
   }



   if(m_config != NULL)
   {
      m_config.Shutdown();

      delete m_config;

      m_config = NULL;
   }



   m_initialized = false;

}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXInfrastructureServices::Reset()
{
   Shutdown();

   Initialize();
}


//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXInfrastructureServices::IsInitialized() const
{
   return m_initialized;
}


//+------------------------------------------------------------------+
//| Access                                                           |
//+------------------------------------------------------------------+

CPHXConfigManager* CPHXInfrastructureServices::GetConfigManager()
{
   return m_config;
}


CPHXLogger* CPHXInfrastructureServices::GetLogger()
{
   return m_logger;
}


CPHXServiceLocator* CPHXInfrastructureServices::GetServiceLocator()
{
   return m_locator;
}


CPHXClock* CPHXInfrastructureServices::GetClock()
{
   return m_clock;
}


CPHXStateManager* CPHXInfrastructureServices::GetStateManager()
{
   return m_state;
}


CPHXEventBus* CPHXInfrastructureServices::GetEventBus()
{
   return m_eventBus;
}


CPHXDiagnostics* CPHXInfrastructureServices::GetDiagnostics()
{
   return m_diagnostics;
}


CPHXBuildInfo* CPHXInfrastructureServices::GetBuildInfo()
{
   return m_buildInfo;
}


CPHXPerformanceMonitor* CPHXInfrastructureServices::GetPerformanceMonitor()
{
   return m_performance;
}


#endif // __PHX_INFRASTRUCTURE_SERVICES_MQH__