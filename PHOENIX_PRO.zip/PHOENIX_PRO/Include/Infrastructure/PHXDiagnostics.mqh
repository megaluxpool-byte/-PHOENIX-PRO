//+------------------------------------------------------------------+
//|                  PHXDiagnostics.mqh                              |
//|             PHOENIX PRO Trading Framework                        |
//+------------------------------------------------------------------+
#ifndef __PHX_DIAGNOSTICS_MQH__
#define __PHX_DIAGNOSTICS_MQH__


//+------------------------------------------------------------------+
//| Diagnostics Service                                              |
//+------------------------------------------------------------------+
class CPHXDiagnostics
{

private:

   bool m_initialized;


   bool m_systemReady;


   ulong m_errorCount;


   ulong m_warningCount;



public:

   CPHXDiagnostics();

   ~CPHXDiagnostics();



public:

   bool Initialize();


   void Shutdown();


   void Reset();


   bool IsInitialized() const;



public:

   void SetSystemReady(bool state);


   bool IsSystemReady() const;



public:

   void AddError();


   void AddWarning();


   ulong GetErrorCount() const;


   ulong GetWarningCount() const;

};


//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXDiagnostics::CPHXDiagnostics()
{
   m_initialized = false;

   m_systemReady = false;

   m_errorCount = 0;

   m_warningCount = 0;
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXDiagnostics::~CPHXDiagnostics()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXDiagnostics::Initialize()
{
   if(m_initialized)
      return true;


   Reset();


   m_initialized = true;


   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXDiagnostics::Shutdown()
{
   if(!m_initialized)
      return;


   Reset();


   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXDiagnostics::Reset()
{
   m_systemReady = false;

   m_errorCount = 0;

   m_warningCount = 0;
}


//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXDiagnostics::IsInitialized() const
{
   return m_initialized;
}


//+------------------------------------------------------------------+
//| Set System Ready                                                 |
//+------------------------------------------------------------------+
void CPHXDiagnostics::SetSystemReady(bool state)
{
   m_systemReady = state;
}


//+------------------------------------------------------------------+
//| Is System Ready                                                  |
//+------------------------------------------------------------------+
bool CPHXDiagnostics::IsSystemReady() const
{
   return m_systemReady;
}


//+------------------------------------------------------------------+
//| Add Error                                                        |
//+------------------------------------------------------------------+
void CPHXDiagnostics::AddError()
{
   m_errorCount++;
}


//+------------------------------------------------------------------+
//| Add Warning                                                      |
//+------------------------------------------------------------------+
void CPHXDiagnostics::AddWarning()
{
   m_warningCount++;
}


//+------------------------------------------------------------------+
//| Get Error Count                                                  |
//+------------------------------------------------------------------+
ulong CPHXDiagnostics::GetErrorCount() const
{
   return m_errorCount;
}


//+------------------------------------------------------------------+
//| Get Warning Count                                                |
//+------------------------------------------------------------------+
ulong CPHXDiagnostics::GetWarningCount() const
{
   return m_warningCount;
}


#endif // __PHX_DIAGNOSTICS_MQH__