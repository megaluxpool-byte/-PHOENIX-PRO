//+------------------------------------------------------------------+
//|                   PHXStateManager.mqh                            |
//|                 PHOENIX PRO Trading Framework                    |
//+------------------------------------------------------------------+
#ifndef __PHX_STATE_MANAGER_MQH__
#define __PHX_STATE_MANAGER_MQH__

//+------------------------------------------------------------------+
//| System State Manager                                             |
//+------------------------------------------------------------------+
class CPHXStateManager
{
private:

   bool m_initialized;
   bool m_started;
   bool m_tradingEnabled;

public:

   CPHXStateManager();
   ~CPHXStateManager();

public:

   bool Initialize();

   void Shutdown();

   void Reset();

   bool IsInitialized() const;

public:

   void SetStarted(bool state);

   bool IsStarted() const;

public:

   void SetTradingEnabled(bool state);

   bool IsTradingEnabled() const;
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXStateManager::CPHXStateManager()
{
   m_initialized     = false;
   m_started         = false;
   m_tradingEnabled  = false;
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXStateManager::~CPHXStateManager()
{
   Shutdown();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXStateManager::Initialize()
{
   if(m_initialized)
      return true;


   Reset();


   m_initialized = true;


   return true;
}


//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXStateManager::Shutdown()
{
   if(!m_initialized)
      return;


   Reset();


   m_initialized = false;
}


//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXStateManager::Reset()
{
   m_started        = false;

   m_tradingEnabled = false;
}


//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+
bool CPHXStateManager::IsInitialized() const
{
   return m_initialized;
}


//+------------------------------------------------------------------+
//| Set Started                                                      |
//+------------------------------------------------------------------+
void CPHXStateManager::SetStarted(bool state)
{
   m_started = state;
}


//+------------------------------------------------------------------+
//| Is Started                                                       |
//+------------------------------------------------------------------+
bool CPHXStateManager::IsStarted() const
{
   return m_started;
}


//+------------------------------------------------------------------+
//| Set Trading Enabled                                              |
//+------------------------------------------------------------------+
void CPHXStateManager::SetTradingEnabled(bool state)
{
   m_tradingEnabled = state;
}


//+------------------------------------------------------------------+
//| Is Trading Enabled                                               |
//+------------------------------------------------------------------+
bool CPHXStateManager::IsTradingEnabled() const
{
   return m_tradingEnabled;
}

#endif // __PHX_STATE_MANAGER_MQH__