#ifndef __PHX_TREND_SCORE_LOGGER_MQH__
#define __PHX_TREND_SCORE_LOGGER_MQH__

#include "PHXDiagnosticsTypes.mqh"
#include "../Signal/PHXTrendScoreTypes.mqh"

//+------------------------------------------------------------------+
//| Trend Score Logger                                               |
//+------------------------------------------------------------------+
class CPHXTrendScoreLogger
{

private:

   SPHXDiagnosticsConfig m_config;

public:

   CPHXTrendScoreLogger()
   {
      m_config.Reset();
   }

   //--------------------------------------------------
   // Configuration
   //--------------------------------------------------

   void SetConfig(
      const SPHXDiagnosticsConfig &config
   )
   {
      m_config = config;
   }

   //--------------------------------------------------
   // Write Trend Score
   //--------------------------------------------------

   void Log(
      const SPHXTrendScore &score
   )
   {

      if(!m_config.EnableJournal)
         return;

      Print("=================================================");
      Print("PHX Trend Score");
      Print("-------------------------------------------------");

      Print("EMA Fan      : ", score.EMA.Fan);
      Print("EMA Slope    : ", score.EMA.Slope);
      Print("EMA Distance : ", score.EMA.Distance);
      Print("EMA Compress : ", score.EMA.Compression);
      Print("EMA Total    : ", score.EMA.Total);

      Print("");

      Print("ATR Total    : ", score.ATR.Total);
      Print("RSI Total    : ", score.RSI.Total);
      Print("Volume Total : ", score.Volume.Total);
      Print("Market Total : ", score.Market.Total);

      Print("");

      Print("TOTAL SCORE  : ", score.Total);

      Print("=================================================");
   }

};

#endif // __PHX_TREND_SCORE_LOGGER_MQH__