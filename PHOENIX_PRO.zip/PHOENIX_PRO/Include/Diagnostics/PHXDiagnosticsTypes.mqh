#ifndef __PHX_DIAGNOSTICS_TYPES_MQH__
#define __PHX_DIAGNOSTICS_TYPES_MQH__

//+------------------------------------------------------------------+
//| Diagnostics Output Mode                                          |
//+------------------------------------------------------------------+
enum ENUM_PHX_DIAGNOSTICS_OUTPUT
{
   PHX_DIAG_NONE      = 0,
   PHX_DIAG_JOURNAL   = 1,
   PHX_DIAG_CHART     = 2,
   PHX_DIAG_CSV       = 4
};

//+------------------------------------------------------------------+
//| Diagnostics Level                                                |
//+------------------------------------------------------------------+
enum ENUM_PHX_DIAGNOSTICS_LEVEL
{
   PHX_DIAG_INFO = 0,
   PHX_DIAG_WARNING,
   PHX_DIAG_ERROR,
   PHX_DIAG_DEBUG
};

//+------------------------------------------------------------------+
//| Diagnostics Category                                             |
//+------------------------------------------------------------------+
enum ENUM_PHX_DIAGNOSTICS_CATEGORY
{
   PHX_DIAG_SYSTEM = 0,
   PHX_DIAG_TREND,
   PHX_DIAG_SIGNAL,
   PHX_DIAG_TRADE,
   PHX_DIAG_RISK,
   PHX_DIAG_MARKET,
   PHX_DIAG_PERFORMANCE
};

//+------------------------------------------------------------------+
//| Diagnostics Configuration                                        |
//+------------------------------------------------------------------+
struct SPHXDiagnosticsConfig
{
   bool EnableJournal;
   bool EnableChart;
   bool EnableCSV;
   bool LogOnlyNewBar;
   ENUM_PHX_DIAGNOSTICS_LEVEL Level;

   void Reset()
   {
      EnableJournal = true;
      EnableChart   = false;
      EnableCSV     = false;
      LogOnlyNewBar = true;
      Level         = PHX_DIAG_INFO;
   }
};

#endif // __PHX_DIAGNOSTICS_TYPES_MQH__