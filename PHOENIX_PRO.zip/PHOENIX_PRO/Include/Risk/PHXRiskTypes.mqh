#ifndef PHX_RISK_TYPES_MQH
#define PHX_RISK_TYPES_MQH


//+------------------------------------------------------------------+
//| Risk Decision Result                                             |
//+------------------------------------------------------------------+
enum ENUM_PHX_RISK_RESULT
{
   PHX_RISK_UNKNOWN = 0,
   PHX_RISK_ALLOWED,
   PHX_RISK_BLOCKED,
   PHX_RISK_EMERGENCY
};
//+------------------------------------------------------------------+
//| Risk Reason                                                      |
//+------------------------------------------------------------------+
enum ENUM_PHX_RISK_REASON
{
   PHX_RISK_REASON_NONE = 0,
   // Equity
   PHX_RISK_REASON_EQUITY_LIMIT,
   // Drawdown
   PHX_RISK_REASON_MAX_DRAWDOWN,
   // Spread
   PHX_RISK_REASON_SPREAD,
   // Volume
   PHX_RISK_REASON_VOLUME,
   // Position count
   PHX_RISK_REASON_POSITION_LIMIT,
   // ATR Stop
   PHX_RISK_REASON_ATR_STOP,
   // All checks passed
   PHX_RISK_REASON_ALL_OK
};
//+------------------------------------------------------------------+
//| Risk Snapshot                                                    |
//+------------------------------------------------------------------+

struct SPHXRiskSnapshot
{
   //--------------------------------------------------
   // Account
   //--------------------------------------------------
   double Equity;
   double Balance;
   double FreeMargin;
   //--------------------------------------------------
   // Risk
   //--------------------------------------------------
   double RiskPercent;
   double Drawdown;
   //--------------------------------------------------
   // Market
   //--------------------------------------------------
   double Spread;
   double ATR;
   double DailyATR;
   double DATR;
   //--------------------------------------------------
   // Position
   //--------------------------------------------------
   int Positions;
   //--------------------------------------------------
   // Reset
   //--------------------------------------------------
   void Reset()
   {
      Equity = 0.0;
      Balance = 0.0;
      FreeMargin = 0.0;
      RiskPercent = 0.0;
      Drawdown = 0.0;
      Spread = 0.0;
      ATR = 0.0;
      DailyATR = 0;
      DATR = 0.0;
      Positions = 0;       
   }
};
//+------------------------------------------------------------------+
//| Risk Result                                                      |
//+------------------------------------------------------------------+
struct SPHXRiskResult
{
   ENUM_PHX_RISK_RESULT Result;
   ENUM_PHX_RISK_REASON Reason;
   double Lot;
   double StopLoss;
   double TakeProfit;
   void Reset()
   {
      Result = PHX_RISK_UNKNOWN;
      Reason = PHX_RISK_REASON_NONE;
      Lot = 0.0;
      StopLoss = 0.0;
      TakeProfit = 0.0;
   }
};
//+------------------------------------------------------------------+
//| Risk Configuration                                               |
//+------------------------------------------------------------------+
struct SPHXRiskConfig
{
   //--------------------------------------------------
   // Drawdown
   //--------------------------------------------------
   double MaxDrawdownPercent;
   //--------------------------------------------------
   // Emergency Protection
   //--------------------------------------------------
   double EmergencyEquityPercent;
   //--------------------------------------------------
   // Market
   //--------------------------------------------------
   double MaxSpread;
   //--------------------------------------------------
   // Position Control
   //--------------------------------------------------
   int MaxPositions;
   //--------------------------------------------------
   // Volume
   //--------------------------------------------------
   double TradeLot;
   //--------------------------------------------------
   // Manual Initial Stop Loss
   //--------------------------------------------------
   double StopLossPoints;
   //--------------------------------------------------
   // ATR Stop Calculation
   //--------------------------------------------------
   double ATRStopMultiplier;
   double ATRStopPointFactor;
   //--------------------------------------------------
   // Trailing Stop
   //--------------------------------------------------
   bool TrailingEnabled;
   double TrailingStopPoints;
   //--------------------------------------------------
   // Breakeven Protection
   //--------------------------------------------------
   bool BreakevenEnabled;
   double BreakevenTriggerATR;
   double BreakevenOffsetATR;
   //--------------------------------------------------
   // Profit Protection Runtime
   //--------------------------------------------------
   double ProfitProtectionTriggerATR;
   double ProfitProtectionLockATR;
   //--------------------------------------------------
   // Profit Protection
   //--------------------------------------------------
   bool ProfitProtectionEnabled;
   double ProtectionTriggerATR;
   double ProtectionLockATR;
   double ProtectionLevel2ATR;
   double ProtectionLevel2LockATR;
   double ProtectionLevel3ATR;
   double ProtectionLevel3LockATR;
   //--------------------------------------------------
   // Trading Time
   //--------------------------------------------------
   bool TradingTimeEnabled;
   int TradingStartHour;
   int TradingStartMinute;
   int TradingEndHour;
   int TradingEndMinute;
   //--------------------------------------------------
   // Reset
   //--------------------------------------------------
   void Reset()
   {
      MaxDrawdownPercent = 0.0;
      EmergencyEquityPercent = 0.0;
      MaxSpread = 0.0;
      MaxPositions = 0;
      TradeLot = 0.01;
   //--------------------------------------------------
   // Manual Initial Stop Loss
   //--------------------------------------------------
   StopLossPoints = 150.0;
   //--------------------------------------------------
   // ATR Stop Calculation
   //--------------------------------------------------
      ATRStopMultiplier = 1.9;
      ATRStopPointFactor = 0.01;
      TrailingEnabled = false;
      TrailingStopPoints = 0.0;
      
   //--------------------------------------------------
   // Breakeven Protection
   //--------------------------------------------------
      BreakevenEnabled = true;
      BreakevenTriggerATR = 1.5;
      BreakevenOffsetATR = 0.05;
   //--------------------------------------------------
   // Profit Protection
   //--------------------------------------------------
      ProfitProtectionEnabled = false;
   //--------------------------------------------------
   // Profit Protection Defaults
   //--------------------------------------------------
      ProfitProtectionTriggerATR = 2.5;
      ProfitProtectionLockATR = 0.5;
      ProtectionTriggerATR = 2.5;
      ProtectionLockATR = 0.5;
      ProtectionLevel2ATR = 3.0;
      ProtectionLevel2LockATR = 2.0;
      ProtectionLevel3ATR = 5.0;
      ProtectionLevel3LockATR = 3.0;
      TradingTimeEnabled = false;
      TradingStartHour = 2;
      TradingStartMinute = 0;
      TradingEndHour = 23;
      TradingEndMinute = 30;
   }
};


#endif // PHX_RISK_TYPES_MQH