#ifndef PHX_RISK_PROVIDER_MQH
#define PHX_RISK_PROVIDER_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXRiskTypes.mqh"


struct SPHXTrendSnapshot;


//+------------------------------------------------------------------+
//| Risk Provider Interface                                          |
//+------------------------------------------------------------------+

class IPHXRiskProvider
{

public:

   //--------------------------------------------------
   // Destructor
   //--------------------------------------------------

   virtual ~IPHXRiskProvider()
   {
   }


public:

   //--------------------------------------------------
   // Calculate Risk
   //--------------------------------------------------

   virtual bool Calculate(
      const SPHXRiskSnapshot &snapshot
   ) = 0;


   //--------------------------------------------------
   // Result
   //--------------------------------------------------

   virtual SPHXRiskResult GetResult() const = 0;
   
   //--------------------------------------------------
   // Trailing Configuration
   //--------------------------------------------------

   virtual bool TrailingEnabled() const = 0;

   virtual double TrailingStopPoints() const = 0;
   
   //--------------------------------------------------
   // ATR Stop Multiplier
   //--------------------------------------------------

   virtual double GetATRStopMultiplier() const = 0;
   
   //--------------------------------------------------
   // BreakEven
   //--------------------------------------------------

   virtual double GetBreakEvenTriggerATR() const = 0;
   
   virtual double GetBreakEvenOffsetATR() const = 0;
   
   //--------------------------------------------------
   // Profit Protection
   //--------------------------------------------------

   virtual double GetProfitProtectionTriggerATR() const = 0;


   virtual double GetProfitProtectionLockATR() const = 0;
   
   //--------------------------------------------------
   // ATR Stop Configuration
   //--------------------------------------------------

   virtual double ATRStopMultiplier() const = 0;

   virtual double ATRStopPointFactor() const = 0;


   //--------------------------------------------------
   // Trading Schedule Configuration
   //--------------------------------------------------

   virtual bool TradingTimeEnabled() const = 0;


   virtual int TradingStartHour() const = 0;


   virtual int TradingStartMinute() const = 0;


   virtual int TradingEndHour() const = 0;


   virtual int TradingEndMinute() const = 0;
};


#endif // PHX_RISK_PROVIDER_MQH