#ifndef PHX_RISK_MANAGER_MQH
#define PHX_RISK_MANAGER_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "IPHXRiskProvider.mqh"
#include "../Indicators/IPHXMarketIndicatorProvider.mqh"
#include "..\Core\PHXConstants.mqh"

//+------------------------------------------------------------------+
//| Risk Manager                                                     |
//+------------------------------------------------------------------+
class CPHXRiskManager :
   public IPHXRiskProvider
{

private:     
   //--------------------------------------------------
   // Configuration
   //--------------------------------------------------
   SPHXRiskConfig m_config;
   //--------------------------------------------------
   // Result
   //--------------------------------------------------
   SPHXRiskResult m_result;
   IPHXMarketIndicatorProvider* m_indicatorProvider; 
   //--------------------------------------------------
   // Checks
   //--------------------------------------------------
   bool CheckEquity(
      const SPHXRiskSnapshot &risk
   );

public:
   //--------------------------------------------------
   // Constructor / Destructor
   //--------------------------------------------------
   CPHXRiskManager();
   ~CPHXRiskManager();
   //--------------------------------------------------
   // Reset
   //--------------------------------------------------
   void Reset();
   //--------------------------------------------------
   // Dependencies
   //--------------------------------------------------
   void SetIndicatorProvider(
   IPHXMarketIndicatorProvider* provider
);
   //--------------------------------------------------
   // Configuration
   //--------------------------------------------------
   void SetConfig(
   const SPHXRiskConfig &config
);
   //--------------------------------------------------
   // Calculate
   //--------------------------------------------------
   bool Calculate(
      const SPHXRiskSnapshot &snapshot
   ) override;
   //--------------------------------------------------
   // Result
   //--------------------------------------------------
   SPHXRiskResult GetResult() const override;
   //--------------------------------------------------
   // Trailing Configuration
   //--------------------------------------------------
   bool TrailingEnabled() const override;
   double TrailingStopPoints() const override;
   
   //--------------------------------------------------
   // ATR Stop Configuration
   //--------------------------------------------------
   double ATRStopMultiplier() const;
   double ATRStopPointFactor() const; 
  
   //--------------------------------------------------
   // Trading Schedule Configuration
   //--------------------------------------------------
   bool TradingTimeEnabled() const override;
   int TradingStartHour() const override;
   int TradingStartMinute() const override;
   int TradingEndHour() const override;
   int TradingEndMinute() const override;
  
   //--------------------------------------------------
   // Risk Parameters
   //--------------------------------------------------
   double GetATRStopMultiplier() const override;
   double GetBreakEvenTriggerATR() const override;
   double GetBreakEvenOffsetATR() const override;
   double GetProfitProtectionTriggerATR() const override;
   double GetProfitProtectionLockATR() const override;
};
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXRiskManager::CPHXRiskManager()
{
   m_indicatorProvider = NULL;
   Reset();
}
//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXRiskManager::~CPHXRiskManager()
{
   Reset();
}
//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
   void CPHXRiskManager::Reset()
{
   m_result.Reset();
}
//+------------------------------------------------------------------+
//| Set Indicator Provider                                           |
//+------------------------------------------------------------------+
   void CPHXRiskManager::SetIndicatorProvider(
   IPHXMarketIndicatorProvider* provider
)
{
   m_indicatorProvider = provider;
}
//+------------------------------------------------------------------+
//| Set Configuration                                                |
//+------------------------------------------------------------------+
void CPHXRiskManager::SetConfig(
   const SPHXRiskConfig &config
)
{
   m_config = config;
if(PHX_VERBOSE_DEBUG)
{   
Print(
"PHX RiskManager Config Lot=",
DoubleToString(m_config.TradeLot,2)
);
}
}
//+------------------------------------------------------------------+
//| Check Equity                                                     |
//+------------------------------------------------------------------+
bool CPHXRiskManager::CheckEquity(
   const SPHXRiskSnapshot &risk
)
{
   if(m_config.EmergencyEquityPercent <= 0.0)
      return false;
   if(risk.Drawdown >= m_config.EmergencyEquityPercent)
   {
      m_result.Result =
         PHX_RISK_EMERGENCY;

      m_result.Reason =
         PHX_RISK_REASON_EQUITY_LIMIT;
      Print(
         "PHX Risk: Emergency Equity Stop. Drawdown=",
         DoubleToString(
            risk.Drawdown,
            2
         ),
         "%"
      );
      return true;
   }
   return false;
}
//+------------------------------------------------------------------+
//| Calculate                                                        |
//+------------------------------------------------------------------+
   bool CPHXRiskManager::Calculate(
   const SPHXRiskSnapshot &snapshot
)
{
   Reset();
   //--------------------------------------------------
   // Basic Risk Approval
   //--------------------------------------------------
   m_result.Result =
      PHX_RISK_ALLOWED;

   m_result.Reason =
      PHX_RISK_REASON_ALL_OK;
   //--------------------------------------------------
   // Default Volume
   //--------------------------------------------------
   m_result.Lot =
   m_config.TradeLot;
if(PHX_VERBOSE_DEBUG)
{ 
   Print(
   "PHX Risk Calculate Lot=",
   DoubleToString(m_result.Lot,2)
);
}
   //--------------------------------------------------
   // Emergency Equity Check
   //--------------------------------------------------
   if(CheckEquity(snapshot))
{
   return true;
}
   //--------------------------------------------------
   // ATR Stop Calculation
   //--------------------------------------------------
   double atr = 0.0;
   if(m_indicatorProvider != NULL)
{
   atr =
   snapshot.DailyATR;
}
   //--------------------------------------------------
   // ATR Diagnostics (real values)
   //--------------------------------------------------
   double atrH4 = 0.0;
   double atrH1 = 0.0;
   
   int handleH4 =
   iATR(
      _Symbol,
      PERIOD_H4,
      14
   );
   int handleH1 =
   iATR(
      _Symbol,
      PERIOD_H1,
      14
   );
   double buffer[];
   ArraySetAsSeries(
   buffer,
   true
);

   // H4
   if(handleH4 != INVALID_HANDLE)
{
   if(CopyBuffer(
      handleH4,
      0,
      0,
      1,
      buffer
   ) > 0)
   {
      atrH4 = buffer[0];
   }

   IndicatorRelease(handleH4);
}
   // H1
   if(handleH1 != INVALID_HANDLE)
{
   if(CopyBuffer(
      handleH1,
      0,
      0,
      1,
      buffer
   ) > 0)
   {
      atrH1 = buffer[0];
   }
   IndicatorRelease(handleH1);
}
if(PHX_VERBOSE_DEBUG)
{ 
Print(
   "PHX ATR Diagnostics: ",
   "D1=",
   DoubleToString(snapshot.DATR,_Digits),
   " H4=",
   DoubleToString(
      atrH4,
      _Digits
   ),
   " H1=",
   DoubleToString(
      atrH1,
      _Digits
   )
);
}
//--------------------------------------------------
// Manual Initial Stop Loss
//--------------------------------------------------

double point =
   SymbolInfoDouble(
      _Symbol,
      SYMBOL_POINT
   );

if(
   point <= 0.0 ||
   m_config.StopLossPoints <= 0.0
)
{
   m_result.StopLoss = 0.0;
}
else
{
   m_result.StopLoss =
      m_config.StopLossPoints *
      point;
}
if(PHX_VERBOSE_DEBUG)
{
Print(
   "PHX Initial SL: ",
   "Points=",
   DoubleToString(
      m_config.StopLossPoints,
      0
   ),
   " Point=",
   DoubleToString(
      point,
      _Digits
   ),
   " Distance=",
   DoubleToString(
      m_result.StopLoss,
      _Digits
   )
);
}
   //--------------------------------------------------
   // Take Profit
   //--------------------------------------------------
   m_result.TakeProfit = 0.0;
   return true;
}
//+------------------------------------------------------------------+
//| Get Result                                                       |
//+------------------------------------------------------------------+
SPHXRiskResult CPHXRiskManager::GetResult() const
{
   return m_result;
}
//+------------------------------------------------------------------+
//| Trailing Enabled                                                 |
//+------------------------------------------------------------------+
bool CPHXRiskManager::TrailingEnabled() const
{
   return m_config.TrailingEnabled;
}
//+------------------------------------------------------------------+
//| Trailing Stop Points                                             |
//+------------------------------------------------------------------+
double CPHXRiskManager::TrailingStopPoints() const
{
   return m_config.TrailingStopPoints;
}
//+------------------------------------------------------------------+
//| ATR Stop Multiplier                                              |
//+------------------------------------------------------------------+
double CPHXRiskManager::ATRStopMultiplier() const
{
   return m_config.ATRStopMultiplier;
}
//+------------------------------------------------------------------+
//| ATR Stop Point Factor                                            |
//+------------------------------------------------------------------+
double CPHXRiskManager::ATRStopPointFactor() const
{
   return m_config.ATRStopPointFactor;
}
//+------------------------------------------------------------------+
//| Trading Time Enabled                                             |
//+------------------------------------------------------------------+
bool CPHXRiskManager::TradingTimeEnabled() const
{
   return m_config.TradingTimeEnabled;
}
//+------------------------------------------------------------------+
//| Trading Start Hour                                               |
//+------------------------------------------------------------------+
int CPHXRiskManager::TradingStartHour() const
{
   return m_config.TradingStartHour;
}
//+------------------------------------------------------------------+
//| Trading Start Minute                                             |
//+------------------------------------------------------------------+
int CPHXRiskManager::TradingStartMinute() const
{
   return m_config.TradingStartMinute;
}
//+------------------------------------------------------------------+
//| Trading End Hour                                                 |
//+------------------------------------------------------------------+
int CPHXRiskManager::TradingEndHour() const
{
   return m_config.TradingEndHour;
}
//+------------------------------------------------------------------+
//| Trading End Minute                                               |
//+------------------------------------------------------------------+
int CPHXRiskManager::TradingEndMinute() const
{
   return m_config.TradingEndMinute;
}
//+------------------------------------------------------------------+
//| Get ATR Stop Multiplier                                          |
//+------------------------------------------------------------------+
double CPHXRiskManager::GetATRStopMultiplier() const
{
   return m_config.ATRStopMultiplier;
}
//+------------------------------------------------------------------+
//| Get BreakEven Trigger ATR                                        |
//+------------------------------------------------------------------+
double CPHXRiskManager::GetBreakEvenTriggerATR() const
{
   return m_config.BreakevenTriggerATR;
}
//+------------------------------------------------------------------+
//| Get BreakEven Offset ATR                                         |
//+------------------------------------------------------------------+
double CPHXRiskManager::GetBreakEvenOffsetATR() const
{
   return m_config.BreakevenOffsetATR;
}
//+------------------------------------------------------------------+
//| Get Profit Protection Trigger ATR                                |
//+------------------------------------------------------------------+
double CPHXRiskManager::GetProfitProtectionTriggerATR() const
{
   return m_config.ProfitProtectionTriggerATR;
}
//+------------------------------------------------------------------+
//| Get Profit Protection Lock ATR                                   |
//+------------------------------------------------------------------+
double CPHXRiskManager::GetProfitProtectionLockATR() const
{
   return m_config.ProfitProtectionLockATR;
}

#endif // PHX_RISK_MANAGER_MQH