#ifndef PHX_RISK_SNAPSHOT_BUILDER_MQH
#define PHX_RISK_SNAPSHOT_BUILDER_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXRiskTypes.mqh"

#include "../Indicators/IPHXMarketIndicatorProvider.mqh"


//+------------------------------------------------------------------+
//| Risk Snapshot Builder                                            |
//+------------------------------------------------------------------+

class CPHXRiskSnapshotBuilder
{

private:

   //--------------------------------------------------
   // Indicator Provider
   //--------------------------------------------------

   IPHXMarketIndicatorProvider* m_indicatorProvider;



public:

   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------

   CPHXRiskSnapshotBuilder();


   //--------------------------------------------------
   // Set Indicator Provider
   //--------------------------------------------------

   void SetIndicatorProvider(
      IPHXMarketIndicatorProvider* provider
   );


   //--------------------------------------------------
   // Build Snapshot
   //--------------------------------------------------

   bool Build(
      SPHXRiskSnapshot &snapshot
   );

};


//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+

CPHXRiskSnapshotBuilder::CPHXRiskSnapshotBuilder()
{

   m_indicatorProvider = NULL;

}


//+------------------------------------------------------------------+
//| Set Indicator Provider                                           |
//+------------------------------------------------------------------+

void CPHXRiskSnapshotBuilder::SetIndicatorProvider(
   IPHXMarketIndicatorProvider* provider
)
{

   m_indicatorProvider = provider;

}


//+------------------------------------------------------------------+
//| Build                                                             |
//+------------------------------------------------------------------+

bool CPHXRiskSnapshotBuilder::Build(
   SPHXRiskSnapshot &snapshot
)
{

   //--------------------------------------------------
   // Reset
   //--------------------------------------------------

   snapshot.Reset();



   //--------------------------------------------------
   // Account
   //--------------------------------------------------

   snapshot.Equity =
      AccountInfoDouble(
         ACCOUNT_EQUITY
      );


   snapshot.Balance =
      AccountInfoDouble(
         ACCOUNT_BALANCE
      );


   snapshot.FreeMargin =
      AccountInfoDouble(
         ACCOUNT_MARGIN_FREE
      );



   //--------------------------------------------------
   // Positions
   //--------------------------------------------------

   snapshot.Positions =
      PositionsTotal();



   //--------------------------------------------------
   // Market
   //--------------------------------------------------

   snapshot.Spread =
      (double)SymbolInfoInteger(
         _Symbol,
         SYMBOL_SPREAD
      );



   //--------------------------------------------------
   // Indicators
   //--------------------------------------------------

   if(m_indicatorProvider != NULL)
   {

      snapshot.ATR =
         (*m_indicatorProvider).ATR();


      snapshot.DailyATR =
         (*m_indicatorProvider).DailyATR();
         
      snapshot.DATR =
         (*m_indicatorProvider).DATR(); 
   //--------------------------------------------------
   // ATR Diagnostic Report
   //--------------------------------------------------
   double difference = 0.0;

   if(snapshot.DATR > 0)
{
   difference =
      ((snapshot.DailyATR - snapshot.DATR)
       /
       snapshot.DATR) * 100.0;
}


   Print(
   "PHX RISK ATR REPORT: ",
   "DATR(14)=",
   DoubleToString(snapshot.DATR,_Digits),
   " DailyATR Adaptive=",
   DoubleToString(snapshot.DailyATR,_Digits),
   " Difference=",
   DoubleToString(difference,2),
   "%"
);
   }
   //--------------------------------------------------
   // Validation
   //--------------------------------------------------
   if(snapshot.Equity <= 0)
      return false;
      return true;
}

#endif // PHX_RISK_SNAPSHOT_BUILDER_MQH