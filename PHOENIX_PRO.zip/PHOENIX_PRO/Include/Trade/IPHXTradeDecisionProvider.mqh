#ifndef PHX_TRADE_DECISION_PROVIDER_MQH
#define PHX_TRADE_DECISION_PROVIDER_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "../Core/PHXStatisticsTypes.mqh"
#include "../Statistics/PHXTrendStatisticsTypes.mqh"
#include "../Core/PHXTradeDirectionTypes.mqh"
#include "../Signal/PHXSignalTypes.mqh"

//+------------------------------------------------------------------+
//| Trade Decision Provider Interface                                |
//+------------------------------------------------------------------+

class IPHXTradeDecisionProvider
{

public:

   virtual ~IPHXTradeDecisionProvider()
   {
   }


public:

   //--------------------------------------------------
   // Calculate Decision
   //--------------------------------------------------

   virtual bool Calculate(
   const SPHXTrendSnapshot &snapshot,
   const SPHXSignal &signal
) = 0;

   //--------------------------------------------------
   // Direction
   //--------------------------------------------------

   virtual ENUM_PHX_TRADE_DIRECTION Direction() const = 0;


};


#endif // PHX_TRADE_DECISION_PROVIDER_MQH