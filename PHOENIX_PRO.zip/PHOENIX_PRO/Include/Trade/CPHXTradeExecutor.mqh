#ifndef PHX_TRADE_EXECUTOR_MQH
#define PHX_TRADE_EXECUTOR_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "IPHXTradeExecutor.mqh"
#include <Trade/Trade.mqh>
#include "../Journal/PHXTradeJournal.mqh"
#include "..\Core\PHXConstants.mqh"

//+------------------------------------------------------------------+
//| Trade Executor                                                   |
//+------------------------------------------------------------------+

class CPHXTradeExecutor :
   public IPHXTradeExecutor
   {

private:

   //--------------------------------------------------
   // State
   //--------------------------------------------------
   
   //--------------------------------------------------
   // Journal
   //--------------------------------------------------

   CPHXTradeJournal m_journal;
   
   private:
   
   CTrade m_trade;
   //--------------------------------------------------
   // Execution Guard
   //--------------------------------------------------

   bool m_initialized;
   
   bool m_tradeLock;

   ulong m_magic;

   string m_symbol;

   SPHXTradeResult m_result;

   public:

   //--------------------------------------------------
   // Constructor / Destructor
   //--------------------------------------------------

   CPHXTradeExecutor();

   ~CPHXTradeExecutor();
 
   //--------------------------------------------------
   // Lifecycle
   //--------------------------------------------------

   bool Initialize();
   
   void ReleaseTradeLock();

   void Shutdown();

   void Reset();

   //--------------------------------------------------
   // Interface
   //--------------------------------------------------

   bool Execute(
      const SPHXTradeRequest &request,
      SPHXTradeResult &result
   ) override;

   bool CloseAll() override;
   
   //--------------------------------------------------
   // Close Position
   //--------------------------------------------------

   bool Close(
   ulong ticket
)  override;


   bool Modify(
      ulong ticket,
      double stopLoss,
      double takeProfit
   ) override;
   
   //--------------------------------------------------
   // State
   //--------------------------------------------------

   bool IsInitialized() const;

};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+

CPHXTradeExecutor::CPHXTradeExecutor()
{
      Reset();
      
      m_journal.Initialize();
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+

CPHXTradeExecutor::~CPHXTradeExecutor()
{
   Shutdown();
}

bool CPHXTradeExecutor::Initialize()
{
   Print(
      "PHX Journal: Initialize started"
   );


   if(m_initialized)
      return true;


   //--------------------------------------------------
   // Initialize Journal
   //--------------------------------------------------

   if(!m_journal.Initialize())
   {
      Print(
         "PHX Journal: Initialize FAILED"
      );

      return false;
   }


   m_magic = 260826;


   m_symbol = _Symbol;


   m_trade.SetExpertMagicNumber(
      m_magic
   );


   m_initialized = true;


   return true;

}
void CPHXTradeExecutor::ReleaseTradeLock()
{
   m_tradeLock = false;
}

//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+

void CPHXTradeExecutor::Shutdown()
{

   Reset();

}
//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+

void CPHXTradeExecutor::Reset()
{

   m_initialized = false;

   m_magic = 0;

   m_symbol = "";
     
   m_tradeLock = false;
}

//+------------------------------------------------------------------+
//| Execute                                                           |
//+------------------------------------------------------------------+
bool CPHXTradeExecutor::Execute(
   const SPHXTradeRequest &request,
   SPHXTradeResult &result
)
{
   result.Reset();

   Print(
      "PHX EXECUTE ENTRY: ",
      "Symbol=",
      request.Symbol,
      " Direction=",
      IntegerToString(request.Direction),
      " Volume=",
      DoubleToString(request.Volume,2),
      " SL=",
      DoubleToString(request.StopLoss,_Digits),
      " TP=",
      DoubleToString(request.TakeProfit,_Digits),
      " Magic=",
      IntegerToString(request.Magic)
   );
   
   //--------------------------------------------------
   // Validate Executor State
   //--------------------------------------------------

   if(!m_initialized)
{
   result.Message =
      "Executor not initialized";
   
   return false;
}
   //--------------------------------------------------
   // Validate Symbol
   //--------------------------------------------------

   if(request.Symbol == "")
{
   result.Message =
      "Empty trade symbol";

   Print(
      "PHX TradeExecutor: Empty symbol"
   );

   return false;
}

   //--------------------------------------------------
   // Validate Magic Number
   //--------------------------------------------------

   if(request.Magic == 0)
{
   result.Message =
      "Invalid magic number";

   Print(
      "PHX TradeExecutor: Invalid magic"
   );

   return false;
}
   //--------------------------------------------------
   // Trade Lock Guard
   //--------------------------------------------------

   if(m_tradeLock)
{
   result.Message =
      "Trade execution locked";
   Print(
      "PHX TradeExecutor: Trade locked"
   );

   return true;
}
   m_tradeLock = true;
   
//--------------------------------------------------
// Validate StopLoss distance
// Protection only - no SL modification
//--------------------------------------------------

if(request.StopLoss > 0)
{

   double point =
      SymbolInfoDouble(
         request.Symbol,
         SYMBOL_POINT
      );

   if(point <= 0)
   {
      result.Message =
         "Invalid symbol point";

      ReleaseTradeLock();

      return false;
   }


   //--------------------------------------------------
   // Broker minimum stop level
   //--------------------------------------------------

   long stopsLevel =
      SymbolInfoInteger(
         request.Symbol,
         SYMBOL_TRADE_STOPS_LEVEL
      );


   double brokerMinimum =
      stopsLevel * point;


   //--------------------------------------------------
   // Current spread
   //--------------------------------------------------

   double ask =
      SymbolInfoDouble(
         request.Symbol,
         SYMBOL_ASK
      );

   double bid =
      SymbolInfoDouble(
         request.Symbol,
         SYMBOL_BID
      );
   double spread =
      MathAbs(
         ask - bid
      );
   //--------------------------------------------------
   // Safety margin
   // SL must be larger than spread
   //--------------------------------------------------
   double minimumAllowed =
      spread * 2.0;

   if(brokerMinimum > minimumAllowed)
      minimumAllowed = brokerMinimum;


   double currentPrice = 0.0;

   if(request.Direction == PHX_DIRECTION_BUY)
   {
      currentPrice =
         bid;
   }
   if(request.Direction == PHX_DIRECTION_SELL)
   {
      currentPrice =
         ask;
   }
   double distance =
      MathAbs(
         currentPrice -
         request.StopLoss
      );
   Print(
      "PHX SL Protection: ",
      "Distance=",
      DoubleToString(
         distance,
         _Digits
      ),
      " Spread=",
      DoubleToString(
         spread,
         _Digits
      ),
      " BrokerMin=",
      DoubleToString(
         brokerMinimum,
         _Digits
      ),
      " Required=",
      DoubleToString(
         minimumAllowed,
         _Digits
      )
   );
   //--------------------------------------------------
   // Reject only
   //--------------------------------------------------
   if(distance < minimumAllowed)
   {

      result.Message =
         "StopLoss too close to spread";

      Print(
         "PHX TRADE BLOCKED: SL too close. ",
         "Distance=",
         DoubleToString(
            distance,
            _Digits
         ),
         " Required=",
         DoubleToString(
            minimumAllowed,
            _Digits
         )
      );
      ReleaseTradeLock();
      return false;
   }

}
//--------------------------------------------------
// Validate Volume
//--------------------------------------------------

double volume = request.Volume;


double volumeMin =
   SymbolInfoDouble(
      request.Symbol,
      SYMBOL_VOLUME_MIN
   );

double volumeMax =
   SymbolInfoDouble(
      request.Symbol,
      SYMBOL_VOLUME_MAX
   );

double volumeStep =
   SymbolInfoDouble(
      request.Symbol,
      SYMBOL_VOLUME_STEP
   );

//--------------------------------------------------
// Check limits
//--------------------------------------------------

if(volume < volumeMin)
{
   volume = volumeMin;
}

if(volume > volumeMax)
{
   volume = volumeMax;
}
//--------------------------------------------------
// Volume Diagnostic
//--------------------------------------------------

if(PHX_VERBOSE_DEBUG)
{
   Print(
      "PHX TradeExecutor Volume Check: ",
      "Requested=",
      DoubleToString(
         request.Volume,
         2
      ),
      " Final=",
      DoubleToString(
         volume,
         2
      ),
      " Min=",
      DoubleToString(
         volumeMin,
         2
      ),
      " Max=",
      DoubleToString(
         volumeMax,
         2
      ),
      " Step=",
      DoubleToString(
         volumeStep,
         2
      )
   );
}
//--------------------------------------------------
// Normalize step
//--------------------------------------------------

if(volumeStep > 0)
{
   volume =
      MathFloor(
         volume / volumeStep
      )
      *
      volumeStep;
}
//--------------------------------------------------
// Final normalize
//--------------------------------------------------
   volume =
   NormalizeDouble(
      volume,
      2
   );
   
   //--------------------------------------------------
   // Volume deviation protection
   //--------------------------------------------------
Print(
   "PHX Volume Info: ",
   "Min=",
   DoubleToString(volumeMin,2),
   " Step=",
   DoubleToString(volumeStep,2),
   " Max=",
   DoubleToString(volumeMax,2)
);

  if(volume != request.Volume)
{
   Print(
      "PHX TradeExecutor: Volume adjusted by broker rules. ",
      "Requested=",
      DoubleToString(request.Volume,2),
      " Final=",
      DoubleToString(volume,2)
   );
}
if(PHX_VERBOSE_DEBUG)
{
Print(
   "PHX TradeExecutor: Volume check ",
   "Requested=",
   DoubleToString(request.Volume,2),
   " Normalized=",
   DoubleToString(volume,2),
   " Min=",
   DoubleToString(volumeMin,2),
   " Step=",
   DoubleToString(volumeStep,3),
   " Max=",
   DoubleToString(volumeMax,2)
);
}
    //--------------------------------------------------
   // Validation only
   //--------------------------------------------------
   if(request.Direction ==
      PHX_DIRECTION_NONE)
   {

      result.Message =
         "No trade direction";

      ReleaseTradeLock();
      return false;
   }
   if(PHX_VERBOSE_DEBUG)
{
   Print(
      "PHX TradeExecutor: Symbol=",
      request.Symbol,
      " Volume=",
      DoubleToString(request.Volume,2),
      " SL=",
      DoubleToString(request.StopLoss,_Digits),
      " TP=",
      DoubleToString(request.TakeProfit,_Digits),
      " Magic=",
      IntegerToString(request.Magic)
   );
}

if(PHX_VERBOSE_DEBUG)
{
   Print(
      "PHX TradeExecutor: Sending order ",
      "Symbol=",
      request.Symbol,
      " Direction=",
      IntegerToString(request.Direction),
      " Volume=",
      DoubleToString(volume,2),
      " SL=",
      DoubleToString(request.StopLoss,_Digits),
      " TP=",
      DoubleToString(request.TakeProfit,_Digits),
      " Magic=",
      IntegerToString(request.Magic)
   );
}

//--------------------------------------------------
// Real Trade Execution
//--------------------------------------------------

Print(
   "PHX FINAL ORDER CHECK: ",
   "Direction=",
   IntegerToString(request.Direction),
   " Price=",
   DoubleToString(
      SymbolInfoDouble(
         request.Symbol,
         SYMBOL_BID
      ),
      _Digits
   ),
   " SL=",
   DoubleToString(
      request.StopLoss,
      _Digits
   ),
   " Distance=",
   DoubleToString(
      MathAbs(
         SymbolInfoDouble(
            request.Symbol,
            SYMBOL_BID
         )
         -
         request.StopLoss
      ),
      _Digits
   )
);

   bool tradeResult = false;
   
double candlePosition = 0.5;
double priceVsCandleHigh = 0.0;  
 
   //--------------------------------------------------
// Final Candle Execution Protection
//--------------------------------------------------
// получить реальную цену исполнения

double executionPrice = 0.0;

if(request.Direction == PHX_DIRECTION_BUY)
{
   executionPrice =
      SymbolInfoDouble(
         request.Symbol,
         SYMBOL_ASK
      );
}

if(request.Direction == PHX_DIRECTION_SELL)
{
   executionPrice =
      SymbolInfoDouble(
         request.Symbol,
         SYMBOL_BID
      );
}
// получить сигнальную свечу

MqlRates executionCandle[];

ArraySetAsSeries(
   executionCandle,
   true
);


if(
   CopyRates(
      request.Symbol,
      PERIOD_CURRENT,
      1,
      1,
      executionCandle
   ) == 1
)
{

   double candleHigh =
      executionCandle[0].high;

   double candleLow =
      executionCandle[0].low;


   double buffer =
   SymbolInfoDouble(
      request.Symbol,
      SYMBOL_POINT
   )
   *
   2.0;

//--------------------------------------------------
// Final Candle Check Diagnostics
//--------------------------------------------------

   Print(
      "PHX FINAL CANDLE CHECK: ",
      "Direction=",
      IntegerToString(request.Direction),
      " ExecPrice=",
      DoubleToString(
         executionPrice,
         _Digits
      ),
      " High=",
      DoubleToString(
         candleHigh,
         _Digits
      ),
      " Low=",
      DoubleToString(
         candleLow,
         _Digits
      ),
      " Buffer=",
      DoubleToString(
         buffer,
         _Digits
      )
   );

   //--------------------------------------------------
   // BUY protection
   //--------------------------------------------------
   if(request.Direction == PHX_DIRECTION_BUY)
   {

      if(
         executionPrice >
         candleHigh + buffer
      )
      {
         Print(
            "PHX ENTRY CANCELLED: BUY exceeded candle high ",
            "Price=",
            DoubleToString(
               executionPrice,
               _Digits
            ),
            " High=",
            DoubleToString(
               candleHigh,
               _Digits
            )
         );
         return false;
      }
   }
   //--------------------------------------------------
   // SELL protection
   //--------------------------------------------------

   if(request.Direction == PHX_DIRECTION_SELL)
   {

      if(
         executionPrice <
         candleLow - buffer
      )
      {
         Print(
            "PHX ENTRY CANCELLED: SELL exceeded candle low ",
            "Price=",
            DoubleToString(
               executionPrice,
               _Digits
            ),
            " Low=",
            DoubleToString(
               candleLow,
               _Digits
            )
         );

         return false;
      }
   }
}

ulong executionStart =
   GetTickCount64();
   
   if(request.Direction == PHX_DIRECTION_BUY)
{
   Print(
      "PHX TradeExecutor: Sending BUY order"
   );
   tradeResult =
      m_trade.Buy(
         volume,
         request.Symbol,
         0,
         request.StopLoss,
         request.TakeProfit
      );

}
   if(request.Direction == PHX_DIRECTION_SELL)
{

   Print(
      "PHX TradeExecutor: Sending SELL order"
   );


   tradeResult =
      m_trade.Sell(
         volume,
         request.Symbol,
         0,
         request.StopLoss,
         request.TakeProfit
      );

}


//--------------------------------------------------
// Check Execution Result
//--------------------------------------------------

   if(!tradeResult)
{

   result.Success = false;


   result.Message =
      "Trade execution failed";


   Print(
      "PHX TradeExecutor: Order failed. Retcode=",
      m_trade.ResultRetcode(),
      " Description=",
      m_trade.ResultRetcodeDescription()
   );


   ReleaseTradeLock();

   return false;
}


//--------------------------------------------------
// Success
//--------------------------------------------------
result.Success = true;

result.Ticket =
   m_trade.ResultOrder();

result.Price =
   m_trade.ResultPrice();
   
result.ExecutionDelayMS =
   GetTickCount64()
   -
   executionStart;


result.Message =
   "Order opened";
   
Print(
   "PHX EXECUTION PRICE: ",
   DoubleToString(
      result.Price,
      _Digits
   )
);
Print(
   "PHX TradeExecutor: Order opened. Ticket=",
   result.Ticket
);

double openPrice = 0.0;

if(PositionSelect(
      request.Symbol
   ))
{
   openPrice =
      PositionGetDouble(
         POSITION_PRICE_OPEN
      );
}

//--------------------------------------------------
// Execution Quality Data
//--------------------------------------------------
if(
   CopyRates(
      request.Symbol,
      PERIOD_CURRENT,
      1,
      1,
      executionCandle
   ) == 1
)
{
   double range =
      executionCandle[0].high -
      executionCandle[0].low;
   if(range > 0)
   {
      candlePosition =
      (
         result.Price -
         executionCandle[0].low
      )
      /
      range;
   }
   priceVsCandleHigh =
      result.Price -
      executionCandle[0].high;
}

//--------------------------------------------------
// Store Execution Quality
//--------------------------------------------------

result.CandlePosition =
   candlePosition;

result.PriceVsCandleHigh =
   priceVsCandleHigh;

Print(
   "PHX EXECUTION QUALITY: ",
   "CandlePosition=",
   DoubleToString(candlePosition,3),
   " PriceVsHigh=",
   DoubleToString(priceVsCandleHigh,_Digits)
);

bool journalWritten =
   m_journal.WriteOpen(
      result.Ticket,
      request.Symbol,
      IntegerToString(request.Direction),
      openPrice,
      request.Volume,
      request.StopLoss,
      request.TakeProfit
      );


Print(
   "PHX Journal OPEN written=",
   journalWritten,
   " Ticket=",
   result.Ticket
);


ReleaseTradeLock();

return true;
}
//+------------------------------------------------------------------+
//| Close All                                                        |
//+------------------------------------------------------------------+

bool CPHXTradeExecutor::CloseAll()
{

   if(!m_initialized)
   {
      Print(
         "PHX TradeExecutor: CloseAll rejected. Executor not initialized"
      );

      return false;
   }


   bool result = true;


   int total =
      PositionsTotal();


  if(PHX_VERBOSE_DEBUG)
{
   Print(
      "PHX TradeExecutor: CloseAll started. Positions=",
      IntegerToString(total)
   );
}


   for(int i = total - 1; i >= 0; i--)
   {

      ulong ticket =
         PositionGetTicket(i);


      if(ticket == 0)
         continue;


      if(!PositionSelectByTicket(ticket))
         continue;


      string symbol =
         PositionGetString(
            POSITION_SYMBOL
         );

      long magic =
         PositionGetInteger(
            POSITION_MAGIC
         );


      //--------------------------------------------------
      // PHX filter
      //--------------------------------------------------

      if(magic != 260826)
         continue;


      if(PHX_VERBOSE_DEBUG)
{
   Print(
      "PHX TradeExecutor: Closing Ticket=",
      IntegerToString(ticket),
      " Symbol=",
      symbol
   );
}

//--------------------------------------------------
// Save close information BEFORE position disappears
//--------------------------------------------------

double closeProfit =
   PositionGetDouble(
      POSITION_PROFIT
   );

string closeSymbol =
   PositionGetString(
      POSITION_SYMBOL
   );


//--------------------------------------------------
// Close position
//--------------------------------------------------

if(!m_trade.PositionClose(ticket))
{

   Print(
      "PHX TradeExecutor: CloseAll failed Ticket=",
      IntegerToString(ticket),
      " Retcode=",
      m_trade.ResultRetcode(),
      " ",
      m_trade.ResultRetcodeDescription()
   );


   result = false;

}
else
{

   Print(
      "PHX TradeExecutor: Closed Ticket=",
      IntegerToString(ticket)
   );


   //--------------------------------------------------
   // Write CLOSE to journal
   //--------------------------------------------------

   bool journalWritten =
      m_journal.WriteClose(
         ticket,
         closeSymbol,
         m_trade.ResultPrice(),
         closeProfit,
         "CLOSE"
      );


   Print(
      "PHX Journal CLOSE written=",
      journalWritten,
      " Ticket=",
      IntegerToString(ticket)
   );

}

   }


   return result;

}

//+------------------------------------------------------------------+
//| Close Position                                                   |
//+------------------------------------------------------------------+

bool CPHXTradeExecutor::Close(
   ulong ticket
)
{

   if(!m_initialized)
   {
      Print(
         "PHX TradeExecutor: Close rejected. Executor not initialized"
      );

      return false;
   }


   if(ticket == 0)
   {
      Print(
         "PHX TradeExecutor: Close rejected. Invalid ticket"
      );

      return false;
   }


   if(!PositionSelectByTicket(ticket))
   {
      Print(
         "PHX TradeExecutor: Position not found Ticket=",
         IntegerToString(ticket)
      );

      return false;
   }

   //==================================================
   // Save position data BEFORE close
   //==================================================


  if(PHX_VERBOSE_DEBUG)
{
   Print(
      "PHX TradeExecutor: Closing position Ticket=",
      IntegerToString(ticket)
   );
}
   
   
   string symbol =
   PositionGetString(
      POSITION_SYMBOL
   );


   double profit =
   PositionGetDouble(
      POSITION_PROFIT
   );
   //==================================================
   // Close
   //================================================== 
   bool result =
      m_trade.PositionClose(
         ticket
      );

   if(!result)
   {
      Print(
         "PHX TradeExecutor: Close failed. Retcode=",
         m_trade.ResultRetcode(),
         " Description=",
         m_trade.ResultRetcodeDescription()
      );

      return false;
   }
   
   Print(
      "PHX TradeExecutor: Position closed Ticket=",
      IntegerToString(ticket)
   );
  //==================================================
   // Journal CLOSE
   //================================================== 
   m_journal.WriteClose(
   ticket,
   symbol,
   m_trade.ResultPrice(),
   profit,
   "CLOSE"
);

   return true;

}

//+------------------------------------------------------------------+
//| Modify Position                                                  |
//+------------------------------------------------------------------+

bool CPHXTradeExecutor::Modify(
   ulong ticket,
   double stopLoss,
   double takeProfit
)
{

   if(!m_initialized)
   {
      ReleaseTradeLock();

      return false;
   }


   if(ticket == 0)
   {
      Print(
         "PHX TradeExecutor: Modify failed. Invalid ticket"
      );

      return false;
   }


   if(!PositionSelectByTicket(ticket))
   {
      Print(
         "PHX TradeExecutor: Modify failed. Position not found Ticket=",
         IntegerToString(ticket)
      );

      return false;
   }


   string symbol =
      PositionGetString(
         POSITION_SYMBOL
      );
double currentSL =
   PositionGetDouble(
      POSITION_SL
   );


ENUM_POSITION_TYPE type =
   (ENUM_POSITION_TYPE)
   PositionGetInteger(
      POSITION_TYPE
   );


//--------------------------------------------------
// Prevent SL downgrade
//--------------------------------------------------

if(currentSL > 0)
{

   if(type == POSITION_TYPE_BUY)
   {

      if(stopLoss < currentSL)
      {
         Print(
            "PHX TradeExecutor: SL downgrade blocked BUY"
         );

         return false;
      }

   }


   if(type == POSITION_TYPE_SELL)
   {

      if(stopLoss > currentSL)
      {
         Print(
            "PHX TradeExecutor: SL downgrade blocked SELL"
         );

         return false;
      }

   }

}
   //--------------------------------------------------
   // Broker Stops Level Guard
   //--------------------------------------------------

   long stopsLevel =
      SymbolInfoInteger(
         symbol,
         SYMBOL_TRADE_STOPS_LEVEL
      );


   double point =
      SymbolInfoDouble(
         symbol,
         SYMBOL_POINT
      );


   double bid =
      SymbolInfoDouble(
         symbol,
         SYMBOL_BID
      );


   double ask =
      SymbolInfoDouble(
         symbol,
         SYMBOL_ASK
      );


   double minStopDistance =
      (double)stopsLevel * point;


   //--------------------------------------------------
   // Validate BUY Stop Loss
   //--------------------------------------------------

   if(
      stopLoss > 0.0 &&
      type == POSITION_TYPE_BUY
   )
   {

      double maxAllowedSL =
         bid - minStopDistance;


      if(stopLoss > maxAllowedSL)
      {

         Print(
            "PHX TradeExecutor: Modify blocked. BUY SL too close. ",
            "SL=",
            DoubleToString(stopLoss,_Digits),
            " Bid=",
            DoubleToString(bid,_Digits),
            " StopsLevel=",
            IntegerToString((int)stopsLevel),
            " MinDistance=",
            DoubleToString(minStopDistance,_Digits)
         );


         return false;

      }

   }

   //--------------------------------------------------
   // Validate SELL Stop Loss
   //--------------------------------------------------

   if(
      stopLoss > 0.0 &&
      type == POSITION_TYPE_SELL
   )
   {

      double minAllowedSL =
         ask + minStopDistance;


      if(stopLoss < minAllowedSL)
      {

         Print(
            "PHX TradeExecutor: Modify blocked. SELL SL too close. ",
            "SL=",
            DoubleToString(stopLoss,_Digits),
            " Ask=",
            DoubleToString(ask,_Digits),
            " StopsLevel=",
            IntegerToString((int)stopsLevel),
            " MinDistance=",
            DoubleToString(minStopDistance,_Digits)
         );


         return false;

      }

   }

//--------------------------------------------------
// Broker Freeze Level Guard
//--------------------------------------------------

long freezeLevel =
   SymbolInfoInteger(
      symbol,
      SYMBOL_TRADE_FREEZE_LEVEL
   );


double freezeDistance =
   (double)freezeLevel * point;


//--------------------------------------------------
// Validate BUY Freeze Level
//--------------------------------------------------

if(
   stopLoss > 0.0 &&
   type == POSITION_TYPE_BUY
)
{

   double maxFreezeSL =
      bid - freezeDistance;


   if(stopLoss > maxFreezeSL)
   {

      Print(
         "PHX TradeExecutor: Modify blocked. BUY SL inside Freeze Level. ",
         "SL=",
         DoubleToString(stopLoss,_Digits),
         " Bid=",
         DoubleToString(bid,_Digits),
         " FreezeLevel=",
         IntegerToString((int)freezeLevel),
         " FreezeDistance=",
         DoubleToString(freezeDistance,_Digits)
      );


      return false;

   }

}


//--------------------------------------------------
// Validate SELL Freeze Level
//--------------------------------------------------

if(
   stopLoss > 0.0 &&
   type == POSITION_TYPE_SELL
)
{

   double minFreezeSL =
      ask + freezeDistance;


   if(stopLoss < minFreezeSL)
   {

      Print(
         "PHX TradeExecutor: Modify blocked. SELL SL inside Freeze Level. ",
         "SL=",
         DoubleToString(stopLoss,_Digits),
         " Ask=",
         DoubleToString(ask,_Digits),
         " FreezeLevel=",
         IntegerToString((int)freezeLevel),
         " FreezeDistance=",
         DoubleToString(freezeDistance,_Digits)
      );


      return false;

   }

}
   if(PHX_VERBOSE_DEBUG)
{
   Print(
      "PHX TradeExecutor: Modify position Ticket=",
      IntegerToString(ticket),
      " SL=",
      DoubleToString(stopLoss,_Digits),
      " TP=",
      DoubleToString(takeProfit,_Digits)
   );
}


   bool result =
      m_trade.PositionModify(
         symbol,
         stopLoss,
         takeProfit
      );


   if(!result)
   {
      Print(
         "PHX TradeExecutor: Modify failed. Retcode=",
         m_trade.ResultRetcode(),
         " ",
         m_trade.ResultRetcodeDescription()
      );

      return false;
   }




   return true;

}



//+------------------------------------------------------------------+
//| Is Initialized                                                   |
//+------------------------------------------------------------------+

bool CPHXTradeExecutor::IsInitialized() const
{

   return m_initialized;

}



#endif // PHX_TRADE_EXECUTOR_MQH