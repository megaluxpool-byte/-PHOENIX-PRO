#ifndef PHX_TRADE_EXECUTOR_PROVIDER_MQH
#define PHX_TRADE_EXECUTOR_PROVIDER_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXTradeTypes.mqh"


//+------------------------------------------------------------------+
//| Trade Executor Provider Interface                                |
//+------------------------------------------------------------------+

class IPHXTradeExecutorProvider
{

public:

   //--------------------------------------------------
   // Destructor
   //--------------------------------------------------

   virtual ~IPHXTradeExecutorProvider()
   {
   }


public:

   //--------------------------------------------------
   // Execute Trade
   //--------------------------------------------------

   virtual bool Execute(
      const SPHXTradeRequest &request
   ) = 0;


   //--------------------------------------------------
   // Last Result
   //--------------------------------------------------

   virtual SPHXTradeResult GetResult() const = 0;


};


#endif // PHX_TRADE_EXECUTOR_PROVIDER_MQH