#ifndef PHX_TRADE_SERVICES_MQH
#define PHX_TRADE_SERVICES_MQH

//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "CPHXTradeExecutor.mqh"
#include "CPHXTradeDecision.mqh"
#include "PHXTradeTypes.mqh"
#include "../Core/PHXTradeDirectionTypes.mqh"

//+------------------------------------------------------------------+
//| PHOENIX PRO Trade Services                                      |
//+------------------------------------------------------------------+
class CPHXTradeServices
{
private:
//--------------------------------------------------
// Trade Components
//--------------------------------------------------
CPHXTradeExecutor* m_executor;
CPHXTradeDecision* m_decision;
//--------------------------------------------------
// State
//--------------------------------------------------
bool m_initialized;
public:
//--------------------------------------------------
// Constructor / Destructor
//--------------------------------------------------
CPHXTradeServices();
~CPHXTradeServices();
//--------------------------------------------------
// Lifecycle
//--------------------------------------------------
bool Initialize();
void Shutdown();
void Reset();
bool IsInitialized() const;
//--------------------------------------------------
// Access
//--------------------------------------------------
CPHXTradeExecutor* GetExecutor();
CPHXTradeDecision* Decision();
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXTradeServices::CPHXTradeServices()
{
   m_executor = NULL;
   m_decision = NULL;
   m_initialized = false;
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXTradeServices::~CPHXTradeServices()
{
Shutdown();
}
//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXTradeServices::Initialize()
{
   if(m_initialized)
      return true;
   //--------------------------------------------------
   // Create Executor
   //--------------------------------------------------
   m_executor = new CPHXTradeExecutor();
   if(m_executor == NULL)
      return false;
   if(!m_executor.Initialize())
   {
      delete m_executor;
      m_executor = NULL;
      return false;
   }
   //--------------------------------------------------
   // Create Decision
   //--------------------------------------------------
   m_decision = new CPHXTradeDecision();

   if(m_decision == NULL)
   {
      delete m_executor;
      m_executor = NULL;
      return false;
   }
   //--------------------------------------------------
   // Ready
   //--------------------------------------------------
   m_initialized = true;

   return true;
}
//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXTradeServices::Shutdown()
{
   if(m_executor != NULL)
   {
      delete m_executor;
      m_executor = NULL;
   }
   if(m_decision != NULL)
   {
      delete m_decision;
      m_decision = NULL;
   }
   m_initialized = false;
}
//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXTradeServices::Reset()
{
   Shutdown();
}
//+------------------------------------------------------------------+
//| State                                                            |
//+------------------------------------------------------------------+
bool CPHXTradeServices::IsInitialized() const
{
return m_initialized;
}
//+------------------------------------------------------------------+
//| Executor                                                         |
//+------------------------------------------------------------------+
CPHXTradeExecutor* CPHXTradeServices::GetExecutor()
{
return m_executor;
}
//+------------------------------------------------------------------+
//| Decision                                                        |
//+------------------------------------------------------------------+
CPHXTradeDecision* CPHXTradeServices::Decision()
{
   return m_decision;
}

#endif // PHX_TRADE_SERVICES_MQH