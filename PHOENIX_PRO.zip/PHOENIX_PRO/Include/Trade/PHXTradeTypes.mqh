#ifndef PHX_TRADE_TYPES_MQH
#define PHX_TRADE_TYPES_MQH

#include "../Core/PHXTradeDirectionTypes.mqh"



//+------------------------------------------------------------------+
//| Trade Action                                                     |
//+------------------------------------------------------------------+

enum ENUM_PHX_TRADE_ACTION
{

   PHX_TRADE_NONE = 0,

   PHX_TRADE_OPEN,

   PHX_TRADE_CLOSE,

   PHX_TRADE_MODIFY

};


//+------------------------------------------------------------------+
//| Trade State                                                      |
//+------------------------------------------------------------------+

enum ENUM_PHX_TRADE_STATE
{

   PHX_TRADE_IDLE = 0,

   PHX_TRADE_PENDING,

   PHX_TRADE_EXECUTED,

   PHX_TRADE_FAILED

};


//+------------------------------------------------------------------+
//| Trade Request                                                    |
//+------------------------------------------------------------------+

struct SPHXTradeRequest
{

   ENUM_PHX_TRADE_DIRECTION Direction;

   ENUM_PHX_TRADE_ACTION Action;


   double Volume;


   double StopLoss;

   double TakeProfit;


   string Reason;

   string Symbol;

   ulong Magic;

   void Reset()
   {

      Direction = PHX_DIRECTION_NONE;

      Action = PHX_TRADE_NONE;


      Volume = 0.0;


      StopLoss = 0.0;

      TakeProfit = 0.0;


      Reason = "";
      
      Symbol = "";

      Magic = 0;

   }

};



//+------------------------------------------------------------------+
//| Trade Result                                                     |
//+------------------------------------------------------------------+

struct SPHXTradeResult
{

   bool Success;


   ulong Ticket;


   double Price;


   string Message;

   //--------------------------------------------------
   // Execution Quality
   //--------------------------------------------------

   double CandlePosition;

   ulong ExecutionDelayMS;

   double PriceVsCandleHigh;

   void Reset()
   {

      Success = false;

      Ticket = 0;

      Price = 0.0;

      Message = "";
      
      //--------------------------------------------------
      // Execution Quality Reset
      //--------------------------------------------------

      CandlePosition = 0.5;

      ExecutionDelayMS = 0;

      PriceVsCandleHigh = 0.0;


   }

};


#endif // PHX_TRADE_TYPES_MQH