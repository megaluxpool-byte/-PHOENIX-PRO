#ifndef PHX_TRADE_EXECUTOR_INTERFACE_MQH
#define PHX_TRADE_EXECUTOR_INTERFACE_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXTradeTypes.mqh"


//+------------------------------------------------------------------+
//| Trade Executor Interface                                        |
//+------------------------------------------------------------------+

class IPHXTradeExecutor
{

public:


   //--------------------------------------------------
   // Destructor
   //--------------------------------------------------

   virtual ~IPHXTradeExecutor()
   {
   }



   //--------------------------------------------------
   // Execute Trade
   //--------------------------------------------------

   virtual bool Execute(
      const SPHXTradeRequest &request,
      SPHXTradeResult &result
   ) = 0;



   //--------------------------------------------------
   // Close All Positions
   //--------------------------------------------------

   virtual bool CloseAll() = 0;

   //--------------------------------------------------
   // Close Position
   //--------------------------------------------------

   virtual bool Close(
   ulong ticket
   ) = 0;

   //--------------------------------------------------
   // Modify Position
   //--------------------------------------------------

   virtual bool Modify(
      ulong ticket,
      double stopLoss,
      double takeProfit
   ) = 0;


};


#endif // PHX_TRADE_EXECUTOR_INTERFACE_MQH