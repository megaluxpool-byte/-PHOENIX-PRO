#ifndef PHX_TRADE_DECISION_MQH
#define PHX_TRADE_DECISION_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "IPHXTradeDecisionProvider.mqh"

//+------------------------------------------------------------------+
//| Trade Decision Engine                                            |
//+------------------------------------------------------------------+
class CPHXTradeDecision :
   public IPHXTradeDecisionProvider
{
private:
   //--------------------------------------------------
   // Direction
   //--------------------------------------------------
   ENUM_PHX_TRADE_DIRECTION m_direction;
public:
   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------
   CPHXTradeDecision();
   //--------------------------------------------------
   // Reset
   //--------------------------------------------------
   void Reset();
   //--------------------------------------------------
   // Calculate
   //--------------------------------------------------
   bool Calculate(
   const SPHXTrendSnapshot &snapshot,
   const SPHXSignal &signal
) override;
   //--------------------------------------------------
   // Direction
   //--------------------------------------------------
   ENUM_PHX_TRADE_DIRECTION Direction() const override;
};
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXTradeDecision::CPHXTradeDecision()
{
   Reset();
}
//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXTradeDecision::Reset()
{
   m_direction = PHX_DIRECTION_NONE;
}
//+------------------------------------------------------------------+
//| Calculate                                                        |
//+------------------------------------------------------------------+
bool CPHXTradeDecision::Calculate(
   const SPHXTrendSnapshot &snapshot,
   const SPHXSignal &signal
)
{
   Reset();
//--------------------------------------------------
// Signal Direction
//--------------------------------------------------
if(signal.signal == PHX_SIGNAL_BUY)
{
   m_direction = PHX_DIRECTION_BUY;
   return true;
}
if(signal.signal == PHX_SIGNAL_SELL)
{
   m_direction = PHX_DIRECTION_SELL;
   return true;
}
   //--------------------------------------------------
   // No Decision
   //--------------------------------------------------
   m_direction = PHX_DIRECTION_NONE;
   return true;
}
//+------------------------------------------------------------------+
//| Direction                                                        |
//+------------------------------------------------------------------+
ENUM_PHX_TRADE_DIRECTION CPHXTradeDecision::Direction() const
{
   return m_direction;
}

#endif // PHX_TRADE_DECISION_MQH