#ifndef PHX_POSITION_MANAGER_PROVIDER_MQH
#define PHX_POSITION_MANAGER_PROVIDER_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXPositionSnapshotTypes.mqh"
#include "PHXPositionDecisionTypes.mqh"

//+------------------------------------------------------------------+
//| Position Manager Provider Interface                              |
//+------------------------------------------------------------------+

class IPHXPositionManagerProvider
{

public:

   //--------------------------------------------------
   // Destructor
   //--------------------------------------------------

   virtual ~IPHXPositionManagerProvider()
   {
   }


public:
   //--------------------------------------------------
   // Position Count
   //--------------------------------------------------

   virtual int PositionsCount() const = 0;
   
   //--------------------------------------------------
   // Get Position Snapshot
   //--------------------------------------------------

   virtual bool Get(
   int index,
   SPHXPositionSnapshot &position
)  const = 0;
   //--------------------------------------------------
   // BreakEven State
   //--------------------------------------------------
   virtual bool IsBreakEvenMoved(
   ulong ticket
)  const = 0;
   //--------------------------------------------------
   // Set BreakEven State
   //--------------------------------------------------
   virtual void SetBreakEvenMoved(
   ulong ticket
) = 0;
   //--------------------------------------------------
   // Profit Protection State
   //--------------------------------------------------
   virtual bool IsProfitProtectionActivated(
   ulong ticket
)  const = 0;

   virtual void SetProfitProtectionActivated(
   ulong ticket
) = 0;
   //--------------------------------------------------
   // Trailing State
   //--------------------------------------------------
   virtual bool IsTrailingStarted(
   ulong ticket
)  const = 0;
   //--------------------------------------------------
   // Set Trailing State
   //--------------------------------------------------
   virtual void SetTrailingStarted(
   ulong ticket
)  = 0;
   //--------------------------------------------------
   // Last Position
   //--------------------------------------------------
   virtual bool GetLastPosition(
   SPHXPositionSnapshot &position
)  const = 0;  
   //--------------------------------------------------
   // Calculate Position Decision
   //--------------------------------------------------
   virtual bool Calculate(
      const SPHXPositionSnapshot &snapshot
   ) = 0;
   //--------------------------------------------------
   // Get Decision
   //--------------------------------------------------
   virtual SPHXPositionDecision GetDecision() const = 0;

};

#endif // PHX_POSITION_MANAGER_PROVIDER_MQH