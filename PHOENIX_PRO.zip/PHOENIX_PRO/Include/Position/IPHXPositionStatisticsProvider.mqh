#ifndef PHX_POSITION_STATISTICS_PROVIDER_MQH
#define PHX_POSITION_STATISTICS_PROVIDER_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXPositionStatisticsTypes.mqh"


//+------------------------------------------------------------------+
//| Position Statistics Provider Interface                           |
//+------------------------------------------------------------------+

class IPHXPositionStatisticsProvider
{

public:

   //--------------------------------------------------
   // Destructor
   //--------------------------------------------------

   virtual ~IPHXPositionStatisticsProvider()
   {
   }


public:

   //--------------------------------------------------
   // Add Position Record
   //--------------------------------------------------

   virtual bool AddRecord(
      const SPHXPositionStatisticsRecord &record
   ) = 0;



   //--------------------------------------------------
   // Get Last Record
   //--------------------------------------------------

   virtual SPHXPositionStatisticsRecord GetLastRecord() const = 0;



   //--------------------------------------------------
   // Total Records
   //--------------------------------------------------

   virtual int TotalRecords() const = 0;


};


#endif // PHX_POSITION_STATISTICS_PROVIDER_MQH