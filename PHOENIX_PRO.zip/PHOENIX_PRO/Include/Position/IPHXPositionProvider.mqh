#ifndef PHX_POSITION_PROVIDER_MQH
#define PHX_POSITION_PROVIDER_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "PHXPositionSnapshotTypes.mqh"


//+------------------------------------------------------------------+
//| Position Provider Interface                                      |
//+------------------------------------------------------------------+

class IPHXPositionProvider
{

public:

   virtual ~IPHXPositionProvider()
   {
   }


   virtual int Total() const = 0;


   virtual bool Get(
      int index,
      SPHXPositionSnapshot &position
   ) const = 0;


};


#endif // PHX_POSITION_PROVIDER_MQH