#ifndef PHX_POSITION_STATISTICS_MQH
#define PHX_POSITION_STATISTICS_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "IPHXPositionStatisticsProvider.mqh"


//+------------------------------------------------------------------+
//| Position Statistics Manager                                      |
//+------------------------------------------------------------------+

class CPHXPositionStatistics :
public IPHXPositionStatisticsProvider
{

private:

   //--------------------------------------------------
   // Storage
   //--------------------------------------------------

   enum
   {
      MAX_RECORDS = 1000
   };


   SPHXPositionStatisticsRecord m_records[MAX_RECORDS];


   int m_count;


public:

   //--------------------------------------------------
   // Constructor / Destructor
   //--------------------------------------------------

   CPHXPositionStatistics();

   ~CPHXPositionStatistics();



   //--------------------------------------------------
   // Reset
   //--------------------------------------------------

   void Reset();



   //--------------------------------------------------
   // Add Record
   //--------------------------------------------------

   bool AddRecord(
      const SPHXPositionStatisticsRecord &record
   ) override;



   //--------------------------------------------------
   // Get Last Record
   //--------------------------------------------------

   SPHXPositionStatisticsRecord GetLastRecord() const override;



   //--------------------------------------------------
   // Total Records
   //--------------------------------------------------

   int TotalRecords() const override;

};



//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+

CPHXPositionStatistics::CPHXPositionStatistics()
{
   Reset();
}



//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+

CPHXPositionStatistics::~CPHXPositionStatistics()
{
   Reset();
}



//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+

void CPHXPositionStatistics::Reset()
{

   m_count = 0;


   for(int i = 0; i < MAX_RECORDS; i++)
   {
      m_records[i].Reset();
   }

}



//+------------------------------------------------------------------+
//| Add Record                                                       |
//+------------------------------------------------------------------+

bool CPHXPositionStatistics::AddRecord(
   const SPHXPositionStatisticsRecord &record
)
{

   if(m_count >= MAX_RECORDS)
      return false;


   m_records[m_count] = record;


   m_count++;


   return true;

}



//+------------------------------------------------------------------+
//| Get Last Record                                                  |
//+------------------------------------------------------------------+

SPHXPositionStatisticsRecord
CPHXPositionStatistics::GetLastRecord() const
{

   SPHXPositionStatisticsRecord result;

   result.Reset();


   if(m_count <= 0)
      return result;


   result = m_records[m_count - 1];


   return result;

}



//+------------------------------------------------------------------+
//| Total Records                                                    |
//+------------------------------------------------------------------+

int CPHXPositionStatistics::TotalRecords() const
{

   return m_count;

}



#endif // PHX_POSITION_STATISTICS_MQH