#ifndef PHX_POSITION_TYPES_MQH
#define PHX_POSITION_TYPES_MQH


//+------------------------------------------------------------------+
//| Position Snapshot                                                |
//+------------------------------------------------------------------+
#include "PHXPositionBaseTypes.mqh"



#endif