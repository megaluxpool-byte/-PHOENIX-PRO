#ifndef PHX_POSITION_MANAGER_MQH
#define PHX_POSITION_MANAGER_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "IPHXPositionProvider.mqh"
#include "IPHXPositionManagerProvider.mqh"
#include "..\Core\PHXConstants.mqh"

//+------------------------------------------------------------------+
//| Position Manager                                                 |
//| PHOENIX PRO Trading Framework                                    |
//+------------------------------------------------------------------+

class CPHXPositionManager :
      public IPHXPositionManagerProvider
{

private:

//--------------------------------------------------
// Configuration
//--------------------------------------------------

ulong  m_magic;

string m_symbol;

//--------------------------------------------------
// Decision State
//--------------------------------------------------

SPHXPositionDecision m_decision;
SPHXPositionState m_state;

//--------------------------------------------------
// Internal helpers
//--------------------------------------------------

bool SelectPosition(
   int index,
   ulong &ticket
) const;



public:

//--------------------------------------------------
// Constructor / Destructor
//--------------------------------------------------

CPHXPositionManager();

~CPHXPositionManager();


//--------------------------------------------------
// Configuration
//--------------------------------------------------

void SetMagic(
   ulong magic
);


void SetSymbol(
   string symbol
);


//--------------------------------------------------
// IPHXPositionProvider
//--------------------------------------------------

int Total() const;


bool Get(
   int index,
   SPHXPositionSnapshot &position
) const;

bool IsBreakEvenMoved(
   ulong ticket
) const override;


void SetBreakEvenMoved(
   ulong ticket
) override;

//--------------------------------------------------
// Trailing State
//--------------------------------------------------

bool IsTrailingStarted(
   ulong ticket
) const override;


void SetTrailingStarted(
   ulong ticket
) override;
//+------------------------------------------------------------------+
//| Profit Protection State                                          |
//+------------------------------------------------------------------+

bool IsProfitProtectionActivated(
   ulong ticket
) const;


void SetProfitProtectionActivated(
   ulong ticket
);

//--------------------------------------------------
// Position Count
//--------------------------------------------------

int PositionsCount() const override;

bool GetLastPosition(
   SPHXPositionSnapshot &position
) const override;
//--------------------------------------------------
// IPHXPositionManagerProvider
//--------------------------------------------------

bool Calculate(
   const SPHXPositionSnapshot &snapshot
) override;


SPHXPositionDecision GetDecision() const override;


};



//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+

CPHXPositionManager::CPHXPositionManager()
{

   m_magic  = 0;

   m_symbol = "";

   m_decision.Reset();
   
   m_state.Reset();

}



//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+

CPHXPositionManager::~CPHXPositionManager()
{

}



//+------------------------------------------------------------------+
//| Set Magic                                                        |
//+------------------------------------------------------------------+

void CPHXPositionManager::SetMagic(
   ulong magic
)
{

   m_magic = magic;

}



//+------------------------------------------------------------------+
//| Set Symbol                                                       |
//+------------------------------------------------------------------+

void CPHXPositionManager::SetSymbol(
   string symbol
)
{

   m_symbol = symbol;

}



//+------------------------------------------------------------------+
//| Select Position                                                  |
//+------------------------------------------------------------------+

bool CPHXPositionManager::SelectPosition(
   int index,
   ulong &ticket
) const
{

   int current = 0;


   for(int i = 0; i < PositionsTotal(); i++)
   {

      ulong currentTicket =
         PositionGetTicket(i);


      if(currentTicket == 0)
         continue;


      if(!PositionSelectByTicket(currentTicket))
         continue;


      //--------------------------------------------------
      // Magic filter
      //--------------------------------------------------

      if(
         PositionGetInteger(POSITION_MAGIC)
         != m_magic
      )
         continue;


      //--------------------------------------------------
      // Symbol filter
      //--------------------------------------------------

      if(
         PositionGetString(POSITION_SYMBOL)
         != m_symbol
      )
         continue;



      if(current != index)
      {
         current++;
         continue;
      }


      ticket = currentTicket;

      return true;

   }


   return false;

}



//+------------------------------------------------------------------+
//| Total Positions                                                  |
//+------------------------------------------------------------------+

int CPHXPositionManager::Total() const
{

   int count = 0;


   for(int i = 0; i < PositionsTotal(); i++)
   {

      ulong ticket =
         PositionGetTicket(i);


      if(ticket == 0)
         continue;


      if(!PositionSelectByTicket(ticket))
         continue;


      if(
         PositionGetInteger(POSITION_MAGIC)
         != m_magic
      )
         continue;


      if(
         PositionGetString(POSITION_SYMBOL)
         != m_symbol
      )
         continue;


      count++;

   }

if(PHX_VERBOSE_DEBUG)
{
   Print(
      "PHX PositionManager: Total=",
      count,
      " Symbol=",
      m_symbol,
      " Magic=",
      m_magic
   );
}
   return count;

}



//+------------------------------------------------------------------+
//| Get Position                                                     |
//+------------------------------------------------------------------+

bool CPHXPositionManager::Get(
   int index,
   SPHXPositionSnapshot &position
) const
{

   position.Reset();


   ulong ticket = 0;


   if(!SelectPosition(index,ticket))
      return false;



   if(!PositionSelectByTicket(ticket))
      return false;



   //--------------------------------------------------
   // Basic data
   //--------------------------------------------------
   position.Ticket =
      ticket;

   position.Symbol =
      PositionGetString(
         POSITION_SYMBOL
      );
   //--------------------------------------------------
   // Direction
   //--------------------------------------------------
   ENUM_POSITION_TYPE type =
      (ENUM_POSITION_TYPE)
      PositionGetInteger(
         POSITION_TYPE
      );

   if(type == POSITION_TYPE_BUY)
   {
      position.Direction =
         PHX_POSITION_BUY;
   }
   else
   if(type == POSITION_TYPE_SELL)
   {
      position.Direction =
         PHX_POSITION_SELL;
   }
   else
   {
      position.Direction =
         PHX_POSITION_NONE;
   }
   //--------------------------------------------------
   // Volume
   //--------------------------------------------------
   position.Volume =
      PositionGetDouble(
         POSITION_VOLUME
      );
   //--------------------------------------------------
   // Price
   //--------------------------------------------------
   position.OpenPrice =
      PositionGetDouble(
         POSITION_PRICE_OPEN
      );

   position.CurrentPrice =
      PositionGetDouble(
         POSITION_PRICE_CURRENT
      );
   //--------------------------------------------------
   // Stops
   //--------------------------------------------------
   position.StopLoss =
      PositionGetDouble(
         POSITION_SL
      );

   position.TakeProfit =
      PositionGetDouble(
         POSITION_TP
      );
   //--------------------------------------------------
   // Profit
   //--------------------------------------------------
   position.Profit =
      PositionGetDouble(
         POSITION_PROFIT
      );
   //--------------------------------------------------
   // Time
   //--------------------------------------------------
   position.OpenTime =
      (datetime)
      PositionGetInteger(
         POSITION_TIME
      );

if(PHX_VERBOSE_DEBUG)
{
   Print(
      "PHX PositionManager: Ticket=",
      position.Ticket,
      " Symbol=",
      position.Symbol,
      " Volume=",
      DoubleToString(position.Volume,2),
      " Direction=",
      position.Direction,
      " Profit=",
      DoubleToString(position.Profit,2)
   );
}
   return true;
}
//+------------------------------------------------------------------+
//| Positions Count                                                  |
//+------------------------------------------------------------------+
int CPHXPositionManager::PositionsCount() const
{
   return Total();
}
//+------------------------------------------------------------------+
//| Get Last Position                                                |
//+------------------------------------------------------------------+
bool CPHXPositionManager::GetLastPosition(
   SPHXPositionSnapshot &position
) const
{
   position.Reset();

   int total =
      Total();

   if(total <= 0)
      return false;

   return Get(
      total - 1,
      position
   );
}
//+------------------------------------------------------------------+
//| Calculate Position Decision                                      |
//+------------------------------------------------------------------+
bool CPHXPositionManager::Calculate(
   const SPHXPositionSnapshot &snapshot
)
{
   //--------------------------------------------------
   // Synchronize Position State
   //--------------------------------------------------
   if(snapshot.Ticket > 0)
{
   if(m_state.Ticket != snapshot.Ticket)
   {
      m_state.Reset();

      m_state.Ticket =
         snapshot.Ticket;
   }
}
   m_decision.Reset();
   //--------------------------------------------------
   // Base state
   //--------------------------------------------------
   m_decision.Action =
      PHX_ACTION_NONE;

   m_decision.Allow =
      true;

   m_decision.Reason =
      "Position Manager ready";

   return true;
}
//+------------------------------------------------------------------+
//| Get Decision                                                     |
//+------------------------------------------------------------------+
   SPHXPositionDecision CPHXPositionManager::GetDecision() const
{
   return m_decision;
}
//+------------------------------------------------------------------+
//| Check BreakEven State                                            |
//+------------------------------------------------------------------+
bool CPHXPositionManager::IsBreakEvenMoved(
   ulong ticket
) const
{
   if(ticket == 0)
      return false;

   if(m_state.Ticket != ticket)
      return false;

   return m_state.BreakEvenMoved;
}
//+------------------------------------------------------------------+
//| Check Trailing State                                             |
//+------------------------------------------------------------------+
bool CPHXPositionManager::IsTrailingStarted(
   ulong ticket
) const
{
   if(ticket == 0)
      return false;

   if(m_state.Ticket != ticket)
      return false;

   return m_state.TrailingStarted;
}
//+------------------------------------------------------------------+
//| Set BreakEven State                                              |
//+------------------------------------------------------------------+
void CPHXPositionManager::SetBreakEvenMoved(
   ulong ticket
)
{
   if(ticket == 0)
      return;

   if(m_state.Ticket != ticket)
   {
      m_state.Reset();

      m_state.Ticket = ticket;
   }
   m_state.BreakEvenMoved = true;
}
//+------------------------------------------------------------------+
//| Is Profit Protection Activated                                   |
//+------------------------------------------------------------------+
bool CPHXPositionManager::IsProfitProtectionActivated(
   ulong ticket
) const
{
   if(m_state.Ticket != ticket)
      return false;

   return m_state.ProfitProtectionActivated;
}
//+------------------------------------------------------------------+
//| Set Profit Protection Activated                                  |
//+------------------------------------------------------------------+
void CPHXPositionManager::SetProfitProtectionActivated(
   ulong ticket
)
{
   if(m_state.Ticket != ticket)
      return;

   m_state.ProfitProtectionActivated = true;
}
//+------------------------------------------------------------------+
//| Set Trailing State                                               |
//+------------------------------------------------------------------+
void CPHXPositionManager::SetTrailingStarted(
   ulong ticket
)
{
   if(ticket == 0)
      return;

   if(m_state.Ticket != ticket)
   {
      m_state.Reset();
      m_state.Ticket = ticket;
   }
   m_state.TrailingStarted = true;
}

#endif // PHX_POSITION_MANAGER_MQH