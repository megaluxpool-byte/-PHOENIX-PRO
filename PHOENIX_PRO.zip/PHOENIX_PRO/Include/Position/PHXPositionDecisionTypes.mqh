#ifndef PHX_POSITION_DECISION_TYPES_MQH
#define PHX_POSITION_DECISION_TYPES_MQH

#include "PHXPositionStatisticsTypes.mqh"
//+------------------------------------------------------------------+
//| Position Decision Types                                          |
//+------------------------------------------------------------------+




//+------------------------------------------------------------------+
//| Position Decision                                                |
//+------------------------------------------------------------------+

struct SPHXPositionDecision
{

   ENUM_PHX_POSITION_ACTION Action;


   bool Allow;


   string Reason;



   void Reset()
   {

      Action = PHX_ACTION_NONE;

      Allow = false;

      Reason = "";

   }

};


#endif // PHX_POSITION_DECISION_TYPES_MQH