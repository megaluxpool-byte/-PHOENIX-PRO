#ifndef PHX_POSITION_BASE_TYPES_MQH
#define PHX_POSITION_BASE_TYPES_MQH


//+------------------------------------------------------------------+
//| Position Direction                                               |
//+------------------------------------------------------------------+

enum ENUM_PHX_POSITION_DIRECTION
{

   PHX_POSITION_NONE = 0,

   PHX_POSITION_BUY,

   PHX_POSITION_SELL

};

//--------------------------------------------------
// Position Management State
//--------------------------------------------------

struct SPHXPositionState
{

   //--------------------------------------------------
   // Ticket
   //--------------------------------------------------

   ulong Ticket;


   //--------------------------------------------------
   // Management Flags
   //--------------------------------------------------

   // BreakEven moved
   bool BreakEvenMoved;


   // Profit Protection activated
   bool ProfitProtectionActivated;


   // Trailing started
   bool TrailingStarted;


   //--------------------------------------------------
   // Reset
   //--------------------------------------------------

   void Reset()
   {

      Ticket = 0;


      BreakEvenMoved = false;


      ProfitProtectionActivated = false;


      TrailingStarted = false;

   }

};

#endif // PHX_POSITION_BASE_TYPES_MQH