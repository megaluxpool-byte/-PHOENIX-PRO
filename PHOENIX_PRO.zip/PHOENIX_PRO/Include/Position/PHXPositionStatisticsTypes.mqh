#ifndef PHX_POSITION_STATISTICS_TYPES_MQH
#define PHX_POSITION_STATISTICS_TYPES_MQH

//--------------------------------------------------
// Position State
//--------------------------------------------------

enum ENUM_PHX_POSITION_STATE
{

   PHX_POSITION_UNKNOWN = 0,

   PHX_POSITION_OPEN,

   PHX_POSITION_CLOSED

};


//--------------------------------------------------
// Position Action
//--------------------------------------------------

enum ENUM_PHX_POSITION_ACTION
{

   PHX_ACTION_NONE = 0,

   PHX_ACTION_OPEN,

   PHX_ACTION_CLOSE,

   PHX_ACTION_MODIFY

};

//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "../Core/PHXStatisticsTypes.mqh"
#include "PHXPositionTypes.mqh"
#include "PHXPositionBaseTypes.mqh"


//+------------------------------------------------------------------+
//| Position Management Statistics Record                            |
//+------------------------------------------------------------------+

struct SPHXPositionStatisticsRecord
{

   //--------------------------------------------------
   // Header
   //--------------------------------------------------

   SPHXStatisticsHeader Header;



   //--------------------------------------------------
   // Position Info
   //--------------------------------------------------

   ulong Ticket;

   string Symbol;


   ENUM_PHX_POSITION_DIRECTION Direction;



   //--------------------------------------------------
   // Decision
   //--------------------------------------------------

   ENUM_PHX_POSITION_STATE State;

   ENUM_PHX_POSITION_ACTION Action;


   double Confidence;


   string Reason;



   //--------------------------------------------------
   // Financial Result
   //--------------------------------------------------

   double OpenPrice;

   double ClosePrice;


   double Profit;

   double ProfitPercent;



   //--------------------------------------------------
   // Timing
   //--------------------------------------------------

   datetime OpenTime;

   datetime CloseTime;


   int HoldingMinutes;



   //--------------------------------------------------
   // Reset
   //--------------------------------------------------

   void Reset()
   {

      Header.Reset();


      Ticket = 0;

      Symbol = "";


      Direction = PHX_POSITION_NONE;


      State = PHX_POSITION_UNKNOWN;

      Action = PHX_ACTION_NONE;


      Confidence = 0.0;


      Reason = "";


      OpenPrice = 0.0;

      ClosePrice = 0.0;


      Profit = 0.0;

      ProfitPercent = 0.0;


      OpenTime = 0;

      CloseTime = 0;


      HoldingMinutes = 0;

   }

};



#endif // PHX_POSITION_STATISTICS_TYPES_MQH