#ifndef PHX_POSITION_SNAPSHOT_TYPES_MQH
#define PHX_POSITION_SNAPSHOT_TYPES_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include "../Signal/PHXTrendTypes.mqh"
#include "PHXPositionTypes.mqh"
#include "PHXPositionBaseTypes.mqh"

//+------------------------------------------------------------------+
//| Position Snapshot                                                |
//+------------------------------------------------------------------+
struct SPHXPositionSnapshot
{

   //--------------------------------------------------
   // Position Info
   //--------------------------------------------------

   ulong Ticket;

   string Symbol;


   ENUM_PHX_POSITION_DIRECTION Direction;


   double Volume;


   //--------------------------------------------------
   // Price
   //--------------------------------------------------

   double OpenPrice;

   double CurrentPrice;


   double StopLoss;

   double TakeProfit;



   //--------------------------------------------------
   // Profit
   //--------------------------------------------------

   double Profit;

   double ProfitPercent;



   //--------------------------------------------------
   // Time
   //--------------------------------------------------

   datetime OpenTime;

   int HoldingMinutes;



   //--------------------------------------------------
   // Trend Context
   //--------------------------------------------------

   ENUM_PHX_TREND DailyTrend;

   ENUM_PHX_TREND H1Trend;

   ENUM_PHX_TREND M15Trend;

   ENUM_PHX_TREND M5Trend;



   //--------------------------------------------------
   // Market
   //--------------------------------------------------

   double ATR;

   double RSI;

   double Spread;



   //--------------------------------------------------
   // Reset
   //--------------------------------------------------

   void Reset()
   {

      Ticket = 0;


      Symbol = "";


      Direction = PHX_POSITION_NONE;


      Volume = 0.0;


      OpenPrice = 0.0;

      CurrentPrice = 0.0;


      StopLoss = 0.0;

      TakeProfit = 0.0;


      Profit = 0.0;

      ProfitPercent = 0.0;


      OpenTime = 0;

      HoldingMinutes = 0;


      DailyTrend = PHX_TREND_UNKNOWN;

      H1Trend = PHX_TREND_UNKNOWN;

      M15Trend = PHX_TREND_UNKNOWN;

      M5Trend = PHX_TREND_UNKNOWN;


      ATR = 0.0;

      RSI = 0.0;

      Spread = 0.0;

   }

};


#endif // PHX_POSITION_SNAPSHOT_TYPES_MQH