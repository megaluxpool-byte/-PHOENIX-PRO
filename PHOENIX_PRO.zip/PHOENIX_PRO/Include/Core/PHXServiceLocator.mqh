//+------------------------------------------------------------------+
//|                                        PHXServiceLocator.mqh     |
//|                  PHOENIX PRO Trading Framework                   |
//|                                                                  |
//| Description:                                                     |
//|   Central Service Locator                                        |
//+------------------------------------------------------------------+
#ifndef __PHX_SERVICE_LOCATOR_MQH__
#define __PHX_SERVICE_LOCATOR_MQH__

#include "Logger/PHXLogger.mqh"
#include "PHXConfigManager.mqh"

//+------------------------------------------------------------------+
//| Service Locator                                                  |
//+------------------------------------------------------------------+
class CPHXServiceLocator
{
private:

   CPHXLogger*         m_logger;

   CPHXConfigManager*  m_configManager;

   bool                m_initialized;

//------------------------------------------------------------------
// Constructor / Destructor
//------------------------------------------------------------------
public:

   CPHXServiceLocator();

   ~CPHXServiceLocator();

//------------------------------------------------------------------
// Initialization
//------------------------------------------------------------------
public:

   bool Initialize();

   void Shutdown();

   void Reset();

   bool IsInitialized() const;

//------------------------------------------------------------------
// Logger
//------------------------------------------------------------------
public:

   void RegisterLogger(CPHXLogger *logger);

   CPHXLogger* GetLogger() const;

//------------------------------------------------------------------
// Configuration Manager
//------------------------------------------------------------------
public:

   void RegisterConfigManager(CPHXConfigManager *configManager);

   CPHXConfigManager* GetConfigManager() const;

};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXServiceLocator::CPHXServiceLocator()
{
   m_logger         = NULL;
   m_configManager  = NULL;

   m_initialized    = false;
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXServiceLocator::~CPHXServiceLocator()
{
   Shutdown();
}

//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXServiceLocator::Initialize()
{
   m_initialized = true;

   return true;
}

//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXServiceLocator::Shutdown()
{
   m_logger        = NULL;
   m_configManager = NULL;

   m_initialized   = false;
}

//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXServiceLocator::Reset()
{
   Shutdown();

   Initialize();
}

//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXServiceLocator::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| Register Logger                                                  |
//+------------------------------------------------------------------+
void CPHXServiceLocator::RegisterLogger(CPHXLogger *logger)
{
   m_logger = logger;
}

//+------------------------------------------------------------------+
//| Get Logger                                                       |
//+------------------------------------------------------------------+
CPHXLogger* CPHXServiceLocator::GetLogger() const
{
   return m_logger;
}

//+------------------------------------------------------------------+
//| Register Config Manager                                          |
//+------------------------------------------------------------------+
void CPHXServiceLocator::RegisterConfigManager(
   CPHXConfigManager *configManager)
{
   m_configManager = configManager;
}

//+------------------------------------------------------------------+
//| Get Config Manager                                               |
//+------------------------------------------------------------------+
CPHXConfigManager*
CPHXServiceLocator::GetConfigManager() const
{
   return m_configManager;
}

#endif // __PHX_SERVICE_LOCATOR_MQH__