#ifndef PHX_TRADE_DIRECTION_TYPES_MQH
#define PHX_TRADE_DIRECTION_TYPES_MQH


//+------------------------------------------------------------------+
//| Trade Direction                                                 |
//+------------------------------------------------------------------+

enum ENUM_PHX_TRADE_DIRECTION
{

   PHX_DIRECTION_NONE = 0,

   PHX_DIRECTION_BUY,

   PHX_DIRECTION_SELL

};


#endif // PHX_TRADE_DIRECTION_TYPES_MQH