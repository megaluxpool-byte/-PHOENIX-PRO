//+------------------------------------------------------------------+
//|                                         PHXConfigManager.mqh     |
//|                  PHOENIX PRO Trading Framework                   |
//|                                                                  |
//| Description:                                                     |
//|   Central configuration manager                                  |
//+------------------------------------------------------------------+
#ifndef __PHX_CONFIG_MANAGER_MQH__
#define __PHX_CONFIG_MANAGER_MQH__

#include "Logger/PHXLoggerConfig.mqh"
#include "PHXConfigTypes.mqh"

//+------------------------------------------------------------------+
//| Configuration Manager                                            |
//+------------------------------------------------------------------+
class CPHXConfigManager
{
private:

   SPHXLoggerConfig   m_loggerConfig;
   
   SPHXDivergenceConfig   m_divergenceConfig;
   
   SPHXMTFAlignmentConfig m_mtfAlignmentConfig;

   bool               m_initialized;

//------------------------------------------------------------------
// Constructor / Destructor
//------------------------------------------------------------------
public:

   CPHXConfigManager();

   ~CPHXConfigManager();

//------------------------------------------------------------------
// Initialization
//------------------------------------------------------------------
public:
   bool Initialize();
   void Shutdown();
   void Reset();
   bool IsInitialized() const;
//------------------------------------------------------------------
// Logger Configuration
//------------------------------------------------------------------
public:
   void SetLoggerConfig(const SPHXLoggerConfig &config);
   SPHXLoggerConfig GetLoggerConfig() const;
//------------------------------------------------------------------
// Divergence Configuration
//------------------------------------------------------------------
public:
   void SetDivergenceConfig(
      const SPHXDivergenceConfig &config
   );
   SPHXDivergenceConfig GetDivergenceConfig() const;
   
   void SetMTFAlignmentConfig(
   const SPHXMTFAlignmentConfig &config
   );
   SPHXMTFAlignmentConfig GetMTFAlignmentConfig() const;
};
//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXConfigManager::CPHXConfigManager()
{
   m_initialized = false;
   m_loggerConfig.Reset();
   m_divergenceConfig.Reset();
   m_mtfAlignmentConfig.Reset();
}
//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXConfigManager::~CPHXConfigManager()
{
   Shutdown();
}
//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXConfigManager::Initialize()
{
   m_loggerConfig.Reset();
   m_divergenceConfig.Reset();
   m_mtfAlignmentConfig.Reset();
   m_initialized = true;
   return true;
}
//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXConfigManager::Shutdown()
{
   m_loggerConfig.Reset();
   m_divergenceConfig.Reset();
   m_mtfAlignmentConfig.Reset();
   m_initialized =
      false;
}
//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXConfigManager::Reset()
{
   Shutdown();

   Initialize();
}
//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXConfigManager::IsInitialized() const
{
   return m_initialized;
}
//+------------------------------------------------------------------+
//| SetLoggerConfig                                                  |
//+------------------------------------------------------------------+
void CPHXConfigManager::SetLoggerConfig(const SPHXLoggerConfig &config)
{
   m_loggerConfig = config;
}
//+------------------------------------------------------------------+
//| GetLoggerConfig                                                  |
//+------------------------------------------------------------------+
SPHXLoggerConfig CPHXConfigManager::GetLoggerConfig() const
{
   return m_loggerConfig;
}

//+------------------------------------------------------------------+
//| SetDivergenceConfig                                              |
//+------------------------------------------------------------------+
void CPHXConfigManager::SetDivergenceConfig(
   const SPHXDivergenceConfig &config
)
{
   m_divergenceConfig =
      config;
}
//+------------------------------------------------------------------+
//| MTF Alignment Configuration                                      |
//+------------------------------------------------------------------+
void CPHXConfigManager::SetMTFAlignmentConfig(
   const SPHXMTFAlignmentConfig &config
)
{
   m_mtfAlignmentConfig = config;
}

SPHXMTFAlignmentConfig CPHXConfigManager::GetMTFAlignmentConfig() const
{
   return m_mtfAlignmentConfig;
}
//+------------------------------------------------------------------+
//| GetDivergenceConfig                                              |
//+------------------------------------------------------------------+
SPHXDivergenceConfig
CPHXConfigManager::GetDivergenceConfig() const
{
   return m_divergenceConfig;
}

#endif // __PHX_CONFIG_MANAGER_MQH__

