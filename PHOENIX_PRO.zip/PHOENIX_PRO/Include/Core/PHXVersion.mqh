//+------------------------------------------------------------------+
//|                                               PHXVersion.mqh     |
//|                   PHOENIX PRO Trading Framework                  |
//+------------------------------------------------------------------+
#ifndef __PHX_VERSION_MQH__
#define __PHX_VERSION_MQH__

#include "PHXConstants.mqh"

class CPHXVersion
{
public:

   static string ProjectName()
   {
      return PHX_PROJECT_NAME;
   }

   static string Version()
   {
      return StringFormat("%d.%d.%d-%s",
                          PHX_VERSION_MAJOR,
                          PHX_VERSION_MINOR,
                          PHX_VERSION_PATCH,
                          PHX_VERSION_STAGE);
   }

   static void PrintBanner()
   {
      Print("=======================================");
      Print(ProjectName());
      Print("Version: ", Version());
      Print("=======================================");
   }
};

#endif // __PHX_VERSION_MQH__