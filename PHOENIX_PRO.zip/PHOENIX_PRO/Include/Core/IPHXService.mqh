//+------------------------------------------------------------------+
//|                                                IPHXService.mqh   |
//|                  PHOENIX PRO Trading Framework                   |
//+------------------------------------------------------------------+
#ifndef __IPHX_SERVICE_MQH__
#define __IPHX_SERVICE_MQH__

class IPHXService
{
public:

   virtual ~IPHXService() {}

   //==============================================================
   // Life cycle
   //==============================================================

   virtual bool Initialize() = 0;

   virtual bool Start() = 0;

   virtual void Tick() = 0;

   virtual void Timer() = 0;

   virtual void Stop() = 0;

   virtual void Shutdown() = 0;
};

#endif // __IPHX_SERVICE_MQH__