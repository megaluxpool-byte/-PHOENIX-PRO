//+------------------------------------------------------------------+
//|                                                PHXTypes.mqh      |
//|                   PHOENIX PRO Trading Framework                  |
//|                        Build 0.1.0-alpha                         |
//+------------------------------------------------------------------+
#ifndef __PHX_TYPES_MQH__
#define __PHX_TYPES_MQH__

//==================================================================
// Log levels
//==================================================================
enum ENUM_PHX_LOG_LEVEL
{
   PHX_LOG_DEBUG = 0,
   PHX_LOG_INFO,
   PHX_LOG_WARNING,
   PHX_LOG_ERROR
};

//==================================================================
// Module states
//==================================================================
enum ENUM_PHX_MODULE_STATE
{
   PHX_STATE_UNINITIALIZED = 0,
   PHX_STATE_INITIALIZING,
   PHX_STATE_READY,
   PHX_STATE_RUNNING,
   PHX_STATE_STOPPED,
   PHX_STATE_ERROR
};

//==================================================================
// Trade direction
//==================================================================
enum ENUM_PHX_TRADE_DIRECTION
{
   PHX_TRADE_NONE = 0,
   PHX_TRADE_BUY,
   PHX_TRADE_SELL
};

//==================================================================
// Generic module information
//==================================================================
struct SPHXModuleInfo
{
   string Name;
   string Version;
   ENUM_PHX_MODULE_STATE State;
};

//==================================================================
// Generic error information
//==================================================================
struct SPHXErrorInfo
{
   int      Code;
   string   Message;
   datetime Time;
};

//==================================================================
// Generic performance statistics
//==================================================================
struct SPHXPerformanceInfo
{
   ulong TickCounter;
   ulong TimerCounter;
   ulong TradeEventCounter;
};

#endif // __PHX_TYPES_MQH__