//+------------------------------------------------------------------+
//| ATR Momentum                                                     |
//+------------------------------------------------------------------+

class CPHXATRMomentum
{

private:

   double m_minGrowth;


public:


   CPHXATRMomentum()
   {
      m_minGrowth = 1.0;
   }



   bool IsMomentumPositive(
      double currentATR,
      double previousATR
   )
   {

      if(previousATR <= 0)
         return false;


      double growth =
         currentATR / previousATR;


      return(
         growth >= m_minGrowth
      );

   }



   void SetMinGrowth(double value)
   {
      m_minGrowth = value;
   }


};