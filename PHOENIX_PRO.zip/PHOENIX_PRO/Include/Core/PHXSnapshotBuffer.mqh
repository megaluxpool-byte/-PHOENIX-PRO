//+------------------------------------------------------------------+
//|                              PHXSnapshotBuffer.mqh               |
//|                  PHOENIX PRO Trading Framework                   |
//|                                                                  |
//+------------------------------------------------------------------+

#ifndef __PHX_SNAPSHOT_BUFFER_MQH__
#define __PHX_SNAPSHOT_BUFFER_MQH__


#include "../Statistics/PHXTrendStatisticsTypes.mqh"

//+------------------------------------------------------------------+
//| Universal Snapshot Ring Buffer                                   |
//+------------------------------------------------------------------+
class CPHXSnapshotBuffer
{
private:

   //--------------------------------------------------
   // Buffer
   //--------------------------------------------------

   SPHXTrendSnapshot m_buffer[];

   //--------------------------------------------------
   // Capacity
   //--------------------------------------------------

   int m_capacity;

   //--------------------------------------------------
   // Current Size
   //--------------------------------------------------

   int m_size;

   //--------------------------------------------------
   // Head Position
   //--------------------------------------------------

   int m_head;

   //--------------------------------------------------
   // Total Push Counter
   //--------------------------------------------------

   ulong m_totalPushes;

public:

   CPHXSnapshotBuffer();

   ~CPHXSnapshotBuffer();

public:

   bool Initialize(
      const int capacity
   );

   void Clear();

public:

    bool Push(
      const SPHXTrendSnapshot &item
   );


   bool Get(
      const int index,
      SPHXTrendSnapshot &item
   ) const;


   bool Last(
   SPHXTrendSnapshot &item
) const;

public:

   int Size() const;

   int Capacity() const;

   ulong TotalPushes() const;

   bool IsFull() const;

   bool IsEmpty() const;
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXSnapshotBuffer::CPHXSnapshotBuffer()
{
   m_capacity    = 0;

   m_size        = 0;

   m_head        = -1;

   m_totalPushes = 0;
}


//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXSnapshotBuffer::~CPHXSnapshotBuffer()
{
   Clear();
}


//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXSnapshotBuffer::Initialize(
   const int capacity
)
{

   if(capacity <= 0)
      return false;


   ArrayResize(
      m_buffer,
      capacity
   );


   m_capacity = capacity;

   m_size = 0;

   m_head = -1;

   m_totalPushes = 0;


   return true;
}


//+------------------------------------------------------------------+
//| Clear                                                             |
//+------------------------------------------------------------------+
void CPHXSnapshotBuffer::Clear()
{

   ArrayFree(
      m_buffer
   );


   m_capacity = 0;

   m_size = 0;

   m_head = -1;

   m_totalPushes = 0;

}

//+------------------------------------------------------------------+
//| Push                                                             |
//+------------------------------------------------------------------+
bool CPHXSnapshotBuffer::Push(
   const SPHXTrendSnapshot &item
)
{

   if(m_capacity <= 0)
      return false;


   //--------------------------------------------------
   // Move head
   //--------------------------------------------------

   m_head++;


   if(m_head >= m_capacity)
      m_head = 0;


   //--------------------------------------------------
   // Store snapshot
   //--------------------------------------------------

   m_buffer[m_head] = item;


   //--------------------------------------------------
   // Size update
   //--------------------------------------------------

   if(m_size < m_capacity)
      m_size++;


   //--------------------------------------------------
   // Statistics
   //--------------------------------------------------

   m_totalPushes++;


   return true;

}

//+------------------------------------------------------------------+
//| Get                                                              |
//+------------------------------------------------------------------+
bool CPHXSnapshotBuffer::Get(
   const int index,
   SPHXTrendSnapshot &item
) const
{

   if(index < 0)
      return false;


   if(index >= m_size)
      return false;


   //--------------------------------------------------
   // Calculate position
   //--------------------------------------------------

   int position = m_head - index;


   if(position < 0)
      position += m_capacity;


   //--------------------------------------------------
   // Copy snapshot
   //--------------------------------------------------

   item = m_buffer[position];


   return true;

}

//+------------------------------------------------------------------+
//| Last                                                             |
//+------------------------------------------------------------------+
bool CPHXSnapshotBuffer::Last(
   SPHXTrendSnapshot &item
) const
{

   if(m_size <= 0)
      return false;


   item = m_buffer[m_head];


   return true;

}

//+------------------------------------------------------------------+
//| Size                                                             |
//+------------------------------------------------------------------+
int CPHXSnapshotBuffer::Size() const
{
   return m_size;
}

//+------------------------------------------------------------------+
//| Capacity                                                         |
//+------------------------------------------------------------------+
int CPHXSnapshotBuffer::Capacity() const
{
   return m_capacity;
}

//+------------------------------------------------------------------+
//| Total Pushes                                                     |
//+------------------------------------------------------------------+
ulong CPHXSnapshotBuffer::TotalPushes() const
{
   return m_totalPushes;
}

//+------------------------------------------------------------------+
//| Is Full                                                          |
//+------------------------------------------------------------------+
bool CPHXSnapshotBuffer::IsFull() const
{
   return (m_size >= m_capacity);
}

//+------------------------------------------------------------------+
//| Is Empty                                                         |
//+------------------------------------------------------------------+
bool CPHXSnapshotBuffer::IsEmpty() const
{
   return (m_size == 0);
}

#endif // __PHX_SNAPSOT_BUFFER_MQH__