//+------------------------------------------------------------------+
//|                                       PHXLogFileWriter.mqh       |
//|                  PHOENIX PRO Trading Framework                   |
//|------------------------------------------------------------------|
//| Description:                                                     |
//|   Log file writer                                                |
//+------------------------------------------------------------------+
#ifndef __PHX_LOG_FILE_WRITER_MQH__
#define __PHX_LOG_FILE_WRITER_MQH__

#include "PHXLoggerConfig.mqh"

//+------------------------------------------------------------------+
//| File Writer                                                      |
//+------------------------------------------------------------------+
class CPHXLogFileWriter
{
private:

   SPHXLoggerConfig  m_config;

   bool              m_initialized;

   int               m_handle;

   string            m_filename;

//------------------------------------------------------------------
// Public
//------------------------------------------------------------------
public:

   CPHXLogFileWriter();
   ~CPHXLogFileWriter();

//------------------------------------------------------------------
// Initialization
//------------------------------------------------------------------
public:

   bool Initialize(const SPHXLoggerConfig &config);

   void Shutdown();

   void Reset();

   bool IsInitialized() const;

//------------------------------------------------------------------
// File operations
//------------------------------------------------------------------
public:

   bool Open();

   void Close();

   bool IsOpen() const;

//------------------------------------------------------------------
// Write
//------------------------------------------------------------------
public:

   bool Write(const string text);

   void Flush();

//------------------------------------------------------------------
// File name
//------------------------------------------------------------------
public:

   void SetFileName(const string filename);

   string GetFileName() const;

//------------------------------------------------------------------
// Configuration
//------------------------------------------------------------------
public:

   void SetConfig(const SPHXLoggerConfig &config);

   SPHXLoggerConfig GetConfig() const;
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXLogFileWriter::CPHXLogFileWriter()
{
   m_initialized = false;
   m_handle      = INVALID_HANDLE;
   m_filename    = "";

   m_config.Reset();
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXLogFileWriter::~CPHXLogFileWriter()
{
   Shutdown();
}

//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXLogFileWriter::Initialize(const SPHXLoggerConfig &config)
{
   m_config      = config;
   m_initialized = true;

   return true;
}

//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXLogFileWriter::Shutdown()
{
   Close();

   m_filename    = "";
   m_initialized = false;

   m_config.Reset();
}

//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXLogFileWriter::Reset()
{
   Shutdown();
}

//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXLogFileWriter::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| SetConfig                                                        |
//+------------------------------------------------------------------+
void CPHXLogFileWriter::SetConfig(const SPHXLoggerConfig &config)
{
   m_config = config;
}

//+------------------------------------------------------------------+
//| GetConfig                                                        |
//+------------------------------------------------------------------+
SPHXLoggerConfig CPHXLogFileWriter::GetConfig() const
{
   return m_config;
}

//+------------------------------------------------------------------+
//| SetFileName                                                      |
//+------------------------------------------------------------------+
void CPHXLogFileWriter::SetFileName(const string filename)
{
   m_filename = filename;
}

//+------------------------------------------------------------------+
//| GetFileName                                                      |
//+------------------------------------------------------------------+
string CPHXLogFileWriter::GetFileName() const
{
   return m_filename;
}

//+------------------------------------------------------------------+
//| Open                                                             |
//+------------------------------------------------------------------+
bool CPHXLogFileWriter::Open()
{
   if(!m_initialized)
      return false;

   if(m_filename == "")
      return false;

   if(IsOpen())
      return true;

   m_handle = FileOpen(
      m_filename,
      FILE_WRITE | FILE_TXT | FILE_ANSI | FILE_SHARE_READ);

   if(m_handle == INVALID_HANDLE)
      return false;

   FileSeek(m_handle, 0, SEEK_END);

   return true;
}

//+------------------------------------------------------------------+
//| Close                                                            |
//+------------------------------------------------------------------+
void CPHXLogFileWriter::Close()
{
   if(m_handle == INVALID_HANDLE)
      return;

   FileFlush(m_handle);
   FileClose(m_handle);

   m_handle = INVALID_HANDLE;
}

//+------------------------------------------------------------------+
//| IsOpen                                                           |
//+------------------------------------------------------------------+
bool CPHXLogFileWriter::IsOpen() const
{
   return (m_handle != INVALID_HANDLE);
}

//+------------------------------------------------------------------+
//| Write                                                            |
//+------------------------------------------------------------------+
bool CPHXLogFileWriter::Write(const string text)
{
   if(!Open())
      return false;

   FileWriteString(m_handle, text + "\r\n");

   return true;
}

//+------------------------------------------------------------------+
//| Flush                                                            |
//+------------------------------------------------------------------+
void CPHXLogFileWriter::Flush()
{
   if(!IsOpen())
      return;

   FileFlush(m_handle);
}

#endif // __PHX_LOG_FILE_WRITER_MQH__