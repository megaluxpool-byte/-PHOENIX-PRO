//+------------------------------------------------------------------+
//|                                          PHXLoggerConfig.mqh     |
//|                  PHOENIX PRO Trading Framework                   |
//|                                                                  |
//| Description:                                                     |
//|   Logger configuration models                                    |
//|                                                                  |
//+------------------------------------------------------------------+
#ifndef __PHX_LOGGER_CONFIG_MQH__
#define __PHX_LOGGER_CONFIG_MQH__

#include "PHXLogTypes.mqh"

//+------------------------------------------------------------------+
//| General Logger Configuration                                     |
//+------------------------------------------------------------------+
struct SPHXLoggerGeneralConfig
{
   bool                 Enabled;
   ENUM_PHX_LOG_LEVEL   Level;
   ENUM_PHX_LOG_TARGET  Target;

   string               ModuleName;
   string               Prefix;

   //---------------------------------------------------------------//
   void Reset()
   {
      Enabled    = true;
      Level      = PHX_LOG_INFO;
      Target     = PHX_LOG_TARGET_BOTH;

      ModuleName = "";
      Prefix     = "";
   }
};

//+------------------------------------------------------------------+
//| MetaTrader Journal Configuration                                |
//+------------------------------------------------------------------+
struct SPHXJournalConfig
{
   bool Enabled;

   bool WriteTimestamp;
   bool WriteLevel;
   bool WriteCategory;

   //---------------------------------------------------------------//
   void Reset()
   {
      Enabled         = true;

      WriteTimestamp  = true;
      WriteLevel      = true;
      WriteCategory   = true;
   }
};

//+------------------------------------------------------------------+
//| File Logging Configuration                                       |
//+------------------------------------------------------------------+
struct SPHXLogFileConfig
{
   bool Enabled;

   string Folder;
   string FileName;

   bool Append;
   bool FlushImmediately;

   //---------------------------------------------------------------//
   void Reset()
   {
      Enabled          = true;

      Folder           = PHX_LOG_DEFAULT_FOLDER;
      FileName         = PHX_LOG_DEFAULT_FILE_NAME;

      Append           = true;
      FlushImmediately = false;
   }
};

//+------------------------------------------------------------------+
//| Log Rotation Configuration                                       |
//+------------------------------------------------------------------+
struct SPHXLogRotationConfig
{
   bool Enabled;

   uint MaxFileSizeMB;
   uint MaxFiles;

   bool DailyRotation;

   //---------------------------------------------------------------//
   void Reset()
   {
      Enabled        = true;

      MaxFileSizeMB  = 25;
      MaxFiles       = 10;

      DailyRotation  = true;
   }
};

//+------------------------------------------------------------------+
//| Memory Buffer Configuration                                      |
//+------------------------------------------------------------------+
struct SPHXLogBufferConfig
{
   bool Enabled;

   uint Capacity;

   bool AutoFlush;

   //---------------------------------------------------------------//
   void Reset()
   {
      Enabled    = true;

      Capacity   = PHX_LOG_DEFAULT_BUFFER_SIZE;

      AutoFlush  = false;
   }
};

//+------------------------------------------------------------------+
//| Debug Information Configuration                                  |
//+------------------------------------------------------------------+
struct SPHXLogDebugConfig
{
   bool WriteModule;
   bool WriteFunction;
   bool WriteLine;
   bool WriteTimestamp;

   //---------------------------------------------------------------//
   void Reset()
   {
      WriteModule     = true;
      WriteFunction   = true;
      WriteLine       = true;
      WriteTimestamp  = true;
   }
};

//+------------------------------------------------------------------+
//| Main Logger Configuration                                        |
//+------------------------------------------------------------------+
struct SPHXLoggerConfig
{
   SPHXLoggerGeneralConfig General;

   SPHXJournalConfig       Journal;

   SPHXLogFileConfig       File;

   SPHXLogRotationConfig   Rotation;

   SPHXLogBufferConfig     Buffer;

   SPHXLogDebugConfig      Debug;

   //---------------------------------------------------------------//
   void Reset()
   {
      General.Reset();

      Journal.Reset();

      File.Reset();

      Rotation.Reset();

      Buffer.Reset();

      Debug.Reset();
   }
};

#endif // __PHX_LOGGER_CONFIG_MQH__