//+------------------------------------------------------------------+
//|                                           PHXLogBuffer.mqh       |
//|                  PHOENIX PRO Trading Framework                   |
//|                                                                  |
//| Description:                                                     |
//|   Ring buffer for logger messages                               |
//+------------------------------------------------------------------+
#ifndef __PHX_LOG_BUFFER_MQH__
#define __PHX_LOG_BUFFER_MQH__

#include "PHXLogTypes.mqh"
#include "PHXLoggerConfig.mqh"

//+------------------------------------------------------------------+
//| Logger Ring Buffer                                               |
//+------------------------------------------------------------------+
class CPHXLogBuffer
{
private:

   SPHXLogMessage m_buffer[];

   uint m_head;
   uint m_tail;
   uint m_count;
   uint m_capacity;

   bool m_initialized;


public:

//-------------------------------------------------------------------
// Constructor
//-------------------------------------------------------------------
   CPHXLogBuffer()
   {
      m_head        = 0;
      m_tail        = 0;
      m_count       = 0;
      m_capacity    = 0;
      m_initialized = false;
   }

//-------------------------------------------------------------------
// Destructor
//-------------------------------------------------------------------
   ~CPHXLogBuffer()
   {
      Shutdown();
   }

//-------------------------------------------------------------------
// Initialize
//-------------------------------------------------------------------
   bool Initialize(const SPHXLogBufferConfig &config)
   {
      Shutdown();

      m_capacity = MathMax((uint)1, config.Capacity);

      ArrayResize(m_buffer, (int)m_capacity);

      m_head  = 0;
      m_tail  = 0;
      m_count = 0;

      m_initialized = true;

      return true;
   }

//-------------------------------------------------------------------
// Shutdown
//-------------------------------------------------------------------
   void Shutdown()
   {
      ArrayResize(m_buffer, 0);

      m_head        = 0;
      m_tail        = 0;
      m_count       = 0;
      m_capacity    = 0;

      m_initialized = false;
   }

//-------------------------------------------------------------------
// Push
//-------------------------------------------------------------------
   bool Push(const SPHXLogMessage &message)
   {
      if(!m_initialized)
         return false;

      //--------------------------------------------------------------
      // Buffer full
      //--------------------------------------------------------------
      if(m_count == m_capacity)
      {
         m_buffer[m_tail] = message;

         m_tail = (m_tail + 1) % m_capacity;

         m_head = m_tail;

         return true;
      }

      //--------------------------------------------------------------
      // Normal write
      //--------------------------------------------------------------
      m_buffer[m_head] = message;

      m_head = (m_head + 1) % m_capacity;

      m_count++;

      return true;
   }

//-------------------------------------------------------------------
// Pop
//-------------------------------------------------------------------
   bool Pop(SPHXLogMessage &message)
   {
      if(Empty())
         return false;

      message = m_buffer[m_tail];

      m_tail = (m_tail + 1) % m_capacity;

      m_count--;

      return true;
   }

//-------------------------------------------------------------------
// Front
//-------------------------------------------------------------------
   bool Front(SPHXLogMessage &message) const
   {
      if(Empty())
         return false;

      message = m_buffer[m_tail];

      return true;
   }

//-------------------------------------------------------------------
// Clear
//-------------------------------------------------------------------
   void Clear()
   {
      m_head  = 0;
      m_tail  = 0;
      m_count = 0;
   }

//-------------------------------------------------------------------
// Empty
//-------------------------------------------------------------------
   bool Empty() const
   {
      return (m_count == 0);
   }

//-------------------------------------------------------------------
// Full
//-------------------------------------------------------------------
   bool Full() const
   {
      return (m_count == m_capacity);
   }

//-------------------------------------------------------------------
// Size
//-------------------------------------------------------------------
   uint Size() const
   {
      return m_count;
   }

//-------------------------------------------------------------------
// Capacity
//-------------------------------------------------------------------
   uint Capacity() const
   {
      return m_capacity;
   }

//-------------------------------------------------------------------
// Initialized
//-------------------------------------------------------------------
   bool IsInitialized() const
   {
      return m_initialized;
   }
};

#endif // __PHX_LOG_BUFFER_MQH__