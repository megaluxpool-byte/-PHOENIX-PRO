//+------------------------------------------------------------------+
//|                                            PHXLogFormatter.mqh   |
//|                     PHOENIX PRO Trading Framework                |
//|------------------------------------------------------------------|
//| Logger message formatter                                        |
//+------------------------------------------------------------------+
#ifndef __PHX_LOG_FORMATTER_MQH__
#define __PHX_LOG_FORMATTER_MQH__

#include "PHXLogTypes.mqh"
#include "PHXLoggerConfig.mqh"

//+------------------------------------------------------------------+
//| Logger Formatter                                                 |
//+------------------------------------------------------------------+
class CPHXLogFormatter
{
private:

   SPHXLoggerConfig m_config;
   bool             m_initialized;

//------------------------------------------------------------------
// Internal helpers
//------------------------------------------------------------------
private:

   string BuildPrefix      (const SPHXLogMessage &message) const;
   string BuildDebugInfo   (const SPHXLogMessage &message) const;

   string FormatTimestamp  (datetime value) const;
   string FormatLevel      (ENUM_PHX_LOG_LEVEL level) const;
   string FormatCategory   (ENUM_PHX_LOG_CATEGORY category) const;

   string FormatModule     (const string module) const;
   string FormatFunction   (const string function) const;
   string FormatLocation   (const SPHXLogMessage &message) const;

   string FormatMessage    (const string text) const;

//------------------------------------------------------------------
// Public
//------------------------------------------------------------------
public:

   CPHXLogFormatter();
   ~CPHXLogFormatter();

   bool Initialize(const SPHXLoggerConfig &config);
   void Shutdown();
   void Reset();

   bool IsInitialized() const;

   string Format(const SPHXLogMessage &message);

   void SetConfig(const SPHXLoggerConfig &config);
   SPHXLoggerConfig GetConfig() const;
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXLogFormatter::CPHXLogFormatter()
{
   m_initialized = false;
   m_config.Reset();
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXLogFormatter::~CPHXLogFormatter()
{
   Shutdown();
}

//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXLogFormatter::Initialize(const SPHXLoggerConfig &config)
{
   m_config = config;
   m_initialized = true;

   return true;
}

//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXLogFormatter::Shutdown()
{
   m_config.Reset();
   m_initialized = false;
}

//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXLogFormatter::Reset()
{
   Shutdown();
}

//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXLogFormatter::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| SetConfig                                                        |
//+------------------------------------------------------------------+
void CPHXLogFormatter::SetConfig(const SPHXLoggerConfig &config)
{
   m_config = config;
}

//+------------------------------------------------------------------+
//| GetConfig                                                        |
//+------------------------------------------------------------------+
SPHXLoggerConfig CPHXLogFormatter::GetConfig() const
{
   return m_config;
}

//+------------------------------------------------------------------+
//| Format                                                           |
//+------------------------------------------------------------------+
string CPHXLogFormatter::Format(const SPHXLogMessage &message)
{
   if(!m_initialized)
      return message.text;

   string record = BuildPrefix(message);

   string debug = BuildDebugInfo(message);

   if(debug != "")
   {
      if(record != "")
         record += " ";

      record += debug;
   }

   string text = FormatMessage(message.text);

   if(text != "")
   {
      if(record != "")
         record += " ";

      record += text;
   }

   return record;
}

//+------------------------------------------------------------------+
//| BuildPrefix                                                      |
//+------------------------------------------------------------------+
string CPHXLogFormatter::BuildPrefix(const SPHXLogMessage &message) const
{
   string prefix = "";

   if(m_config.Journal.WriteTimestamp)
      prefix += "[" + FormatTimestamp(message.timestamp) + "]";

   if(m_config.Journal.WriteLevel)
      prefix += "[" + FormatLevel(message.level) + "]";

   if(m_config.Journal.WriteCategory)
      prefix += "[" + FormatCategory(message.category) + "]";

   return prefix;
}

//+------------------------------------------------------------------+
//| BuildDebugInfo                                                   |
//+------------------------------------------------------------------+
string CPHXLogFormatter::BuildDebugInfo(const SPHXLogMessage &message) const
{
   string result = "";

   string module = FormatModule(message.module);

   if(module != "")
      result += module;

   string function = FormatFunction(message.function);

   if(function != "")
      result += function;

   string location = FormatLocation(message);

   if(location != "")
      result += location;

   return result;
}

//+------------------------------------------------------------------+
//| FormatTimestamp                                                  |
//+------------------------------------------------------------------+
string CPHXLogFormatter::FormatTimestamp(datetime value) const
{
   return TimeToString(value, TIME_DATE | TIME_SECONDS);
}

//+------------------------------------------------------------------+
//| FormatLevel                                                      |
//+------------------------------------------------------------------+
string CPHXLogFormatter::FormatLevel(ENUM_PHX_LOG_LEVEL level) const
{
   return PHXLogLevelToString(level);
}

//+------------------------------------------------------------------+
//| FormatCategory                                                   |
//+------------------------------------------------------------------+
string CPHXLogFormatter::FormatCategory(ENUM_PHX_LOG_CATEGORY category) const
{
   return PHXLogCategoryToString(category);
}

//+------------------------------------------------------------------+
//| FormatModule                                                     |
//+------------------------------------------------------------------+
string CPHXLogFormatter::FormatModule(const string module) const
{
   if(!m_config.Debug.WriteModule)
      return "";

   if(module == "")
      return "";

   return "[" + module + "]";
}

//+------------------------------------------------------------------+
//| FormatFunction                                                   |
//+------------------------------------------------------------------+
string CPHXLogFormatter::FormatFunction(const string function) const
{
   if(!m_config.Debug.WriteFunction)
      return "";

   if(function == "")
      return "";

   return "[" + function + "]";
}

//+------------------------------------------------------------------+
//| FormatLocation                                                   |
//+------------------------------------------------------------------+
string CPHXLogFormatter::FormatLocation(const SPHXLogMessage &message) const
{
   if(!m_config.Debug.WriteLine)
      return "";

   if(message.line <= 0)
      return "";

   return "[Line:" + IntegerToString(message.line) + "]";
}

//+------------------------------------------------------------------+
//| FormatMessage                                                    |
//+------------------------------------------------------------------+
string CPHXLogFormatter::FormatMessage(const string text) const
{
   if(text == "")
      return "";

   string message = text;

   if(StringLen(message) > PHX_LOG_MAX_MESSAGE_LENGTH)
      message = StringSubstr(message, 0, PHX_LOG_MAX_MESSAGE_LENGTH);

   return message;
}

//+------------------------------------------------------------------+
//| End of file                                                      |
//+------------------------------------------------------------------+
#endif // __PHX_LOG_FORMATTER_MQH__