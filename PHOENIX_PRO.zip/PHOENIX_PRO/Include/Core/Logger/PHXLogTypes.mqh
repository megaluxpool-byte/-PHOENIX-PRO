//+------------------------------------------------------------------+
//|                                               PHXLogTypes.mqh    |
//|                   PHOENIX PRO Trading Framework                  |
//|                                                                  |
//| Description:                                                     |
//|   Common logging types, enums and structures                     |
//|                                                                  |
//| Copyright � PHOENIX PRO                                          |
//+------------------------------------------------------------------+
#ifndef __PHX_LOG_TYPES_MQH__
#define __PHX_LOG_TYPES_MQH__

//+------------------------------------------------------------------+
//| Log Levels                                                       |
//+------------------------------------------------------------------+
enum ENUM_PHX_LOG_LEVEL
{
   PHX_LOG_TRACE = 0,      // Very detailed information
   PHX_LOG_DEBUG,          // Debug information
   PHX_LOG_INFO,           // General information
   PHX_LOG_WARNING,        // Warning
   PHX_LOG_ERROR,          // Error
   PHX_LOG_FATAL,          // Fatal error
   PHX_LOG_NONE            // Logging disabled
};

//+------------------------------------------------------------------+
//| Log Output Target                                                 |
//+------------------------------------------------------------------+
enum ENUM_PHX_LOG_TARGET
{
   PHX_LOG_TARGET_NONE     = 0,

   PHX_LOG_TARGET_JOURNAL  = 1,

   PHX_LOG_TARGET_FILE     = 2,

   PHX_LOG_TARGET_BOTH     = 3
};

//+------------------------------------------------------------------+
//| Log Categories                                                    |
//+------------------------------------------------------------------+
enum ENUM_PHX_LOG_CATEGORY
{
   PHX_LOG_CORE = 0,

   PHX_LOG_MARKET,

   PHX_LOG_INDICATOR,

   PHX_LOG_SIGNAL,

   PHX_LOG_RISK,

   PHX_LOG_TRADE,

   PHX_LOG_POSITION,

   PHX_LOG_STATISTICS,

   PHX_LOG_TESTER,

   PHX_LOG_NETWORK,

   PHX_LOG_DATABASE,

   PHX_LOG_CONFIGURATION,

   PHX_LOG_DIAGNOSTICS,

   PHX_LOG_USER
};

//+------------------------------------------------------------------+
//| Log Message                                                       |
//+------------------------------------------------------------------+
struct SPHXLogMessage
{
   datetime                 timestamp;

   ENUM_PHX_LOG_LEVEL       level;

   ENUM_PHX_LOG_CATEGORY    category;

   string                   module;

   string                   function;

   int                      line;

   string                   text;
};

//+------------------------------------------------------------------+
//| Logger Statistics                                                 |
//+------------------------------------------------------------------+
struct SPHXLogStatistics
{
   ulong trace;

   ulong debug;

   ulong info;

   ulong warning;

   ulong error;

   ulong fatal;

   ulong total;

   void Reset()
   {
      trace   = 0;
      debug   = 0;
      info    = 0;
      warning = 0;
      error   = 0;
      fatal   = 0;
      total   = 0;
   }
};

//+------------------------------------------------------------------+
//| Logger State                                                      |
//+------------------------------------------------------------------+
enum ENUM_PHX_LOGGER_STATE
{
   PHX_LOGGER_CREATED = 0,

   PHX_LOGGER_INITIALIZED,

   PHX_LOGGER_RUNNING,

   PHX_LOGGER_STOPPED
};

//+------------------------------------------------------------------+
//| Default Constants                                                 |
//+------------------------------------------------------------------+

#define PHX_LOG_DEFAULT_FILE_NAME       "PHOENIX_PRO.log"

#define PHX_LOG_DEFAULT_FOLDER          "Logs"

#define PHX_LOG_DEFAULT_BUFFER_SIZE     1024

#define PHX_LOG_MAX_MESSAGE_LENGTH      2048

#define PHX_LOG_MAX_MODULE_NAME         64

#define PHX_LOG_MAX_FUNCTION_NAME       128

//+------------------------------------------------------------------+
//| Utility Functions                                                 |
//+------------------------------------------------------------------+

inline string PHXLogLevelToString(const ENUM_PHX_LOG_LEVEL level)
{
   switch(level)
   {
      case PHX_LOG_TRACE:   return "TRACE";
      case PHX_LOG_DEBUG:   return "DEBUG";
      case PHX_LOG_INFO:    return "INFO";
      case PHX_LOG_WARNING: return "WARNING";
      case PHX_LOG_ERROR:   return "ERROR";
      case PHX_LOG_FATAL:   return "FATAL";
      default:              return "UNKNOWN";
   }
}

//+------------------------------------------------------------------+

inline string PHXLogCategoryToString(const ENUM_PHX_LOG_CATEGORY category)
{
   switch(category)
   {
      case PHX_LOG_CORE:          return "CORE";
      case PHX_LOG_MARKET:        return "MARKET";
      case PHX_LOG_INDICATOR:     return "INDICATOR";
      case PHX_LOG_SIGNAL:        return "SIGNAL";
      case PHX_LOG_RISK:          return "RISK";
      case PHX_LOG_TRADE:         return "TRADE";
      case PHX_LOG_POSITION:      return "POSITION";
      case PHX_LOG_STATISTICS:    return "STATISTICS";
      case PHX_LOG_TESTER:        return "TESTER";
      case PHX_LOG_NETWORK:       return "NETWORK";
      case PHX_LOG_DATABASE:      return "DATABASE";
      case PHX_LOG_CONFIGURATION: return "CONFIG";
      case PHX_LOG_DIAGNOSTICS:   return "DIAGNOSTICS";
      case PHX_LOG_USER:          return "USER";
      default:                    return "UNKNOWN";
   }
}

//+------------------------------------------------------------------+

#endif // __PHX_LOG_TYPES_MQH__