//+------------------------------------------------------------------+
//|                                              PHXLogger.mqh       |
//|                  PHOENIX PRO Trading Framework                   |
//|------------------------------------------------------------------|
//| Description:                                                     |
//|   Central logging manager                                        |
//+------------------------------------------------------------------+
#ifndef __PHX_LOGGER_MQH__
#define __PHX_LOGGER_MQH__

#include "PHXLogTypes.mqh"
#include "PHXLoggerConfig.mqh"
#include "PHXLogBuffer.mqh"
#include "PHXLogFormatter.mqh"
#include "PHXJournalWriter.mqh"
#include "PHXLogFileWriter.mqh"

//+------------------------------------------------------------------+
//| Central Logger                                                   |
//+------------------------------------------------------------------+
class CPHXLogger
{
private:

   SPHXLoggerConfig     m_config;

   CPHXLogBuffer        m_buffer;

   CPHXLogFormatter     m_formatter;

   CPHXJournalWriter    m_journal;

   CPHXLogFileWriter    m_file;

   bool                 m_initialized;

//------------------------------------------------------------------
// Initialization
//------------------------------------------------------------------
public:

   CPHXLogger();

   ~CPHXLogger();

   bool Initialize(const SPHXLoggerConfig &config);

   void Shutdown();

   void Reset();

   bool IsInitialized() const;

//------------------------------------------------------------------
// Logging
//------------------------------------------------------------------
public:

   bool Log(const SPHXLogMessage &message);

   void Flush();

//------------------------------------------------------------------
// Configuration
//------------------------------------------------------------------
public:

   void SetConfig(const SPHXLoggerConfig &config);

   SPHXLoggerConfig GetConfig() const;

//------------------------------------------------------------------
// Internal
//------------------------------------------------------------------
private:

   bool InitializeComponents();

   void ShutdownComponents();

   bool DispatchMessage(const SPHXLogMessage &message);
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXLogger::CPHXLogger()
{
   m_initialized = false;
   m_config.Reset();
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXLogger::~CPHXLogger()
{
   Shutdown();
}

//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXLogger::Initialize(const SPHXLoggerConfig &config)
{
   m_config = config;

   if(!InitializeComponents())
      return false;

   m_initialized = true;

   return true;
}

//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXLogger::Shutdown()
{
   ShutdownComponents();

   m_config.Reset();

   m_initialized = false;
}

//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXLogger::Reset()
{
   Shutdown();
}

//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXLogger::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| SetConfig                                                        |
//+------------------------------------------------------------------+
void CPHXLogger::SetConfig(const SPHXLoggerConfig &config)
{
   m_config = config;
}

//+------------------------------------------------------------------+
//| GetConfig                                                        |
//+------------------------------------------------------------------+
SPHXLoggerConfig CPHXLogger::GetConfig() const
{
   return m_config;
}

//+------------------------------------------------------------------+
//| InitializeComponents                                             |
//+------------------------------------------------------------------+
bool CPHXLogger::InitializeComponents()
{
   if(!m_formatter.Initialize(m_config))
      return false;

   if(!m_journal.Initialize(&m_formatter, m_config))
      return false;

   if(!m_file.Initialize(m_config))
      return false;

   return true;
}

//+------------------------------------------------------------------+
//| ShutdownComponents                                               |
//+------------------------------------------------------------------+
void CPHXLogger::ShutdownComponents()
{
   m_file.Shutdown();
   m_journal.Shutdown();
   m_formatter.Shutdown();
}

bool CPHXLogger::DispatchMessage(const SPHXLogMessage &message)
{
   if(!m_config.General.Enabled)
      return false;

   //---------------------------------------------------------------
   // Log Level Filter
   //---------------------------------------------------------------

   if(m_config.General.Level == PHX_LOG_NONE)
      return true;

   if(message.level < m_config.General.Level)
      return true;

   //---------------------------------------------------------------
   // Dispatch
   //---------------------------------------------------------------

   bool result = true;

   if(m_config.Journal.Enabled)
      result &= m_journal.Write(message);

   if(m_config.File.Enabled)
      result &= m_file.Write(m_formatter.Format(message));

   return result;
}

//+------------------------------------------------------------------+
//| Flush                                                            |
//+------------------------------------------------------------------+
void CPHXLogger::Flush()
{
   m_file.Flush();
}

//+------------------------------------------------------------------+
//| Log                                                              |
//+------------------------------------------------------------------+
bool CPHXLogger::Log(const SPHXLogMessage &message)
{
   if(!m_initialized)
      return false;

   return DispatchMessage(message);
}

#endif // __PHX_LOGGER_MQH__