//+------------------------------------------------------------------+
//|                                        PHXJournalWriter.mqh      |
//|                  PHOENIX PRO Trading Framework                   |
//|------------------------------------------------------------------|
//| Description:                                                     |
//|   MetaTrader Journal writer                                      |
//+------------------------------------------------------------------+
#ifndef __PHX_JOURNAL_WRITER_MQH__
#define __PHX_JOURNAL_WRITER_MQH__

#include "PHXLogTypes.mqh"
#include "PHXLoggerConfig.mqh"
#include "PHXLogFormatter.mqh"

//+------------------------------------------------------------------+
//| Journal Writer                                                   |
//+------------------------------------------------------------------+
class CPHXJournalWriter
{
private:

   CPHXLogFormatter *m_formatter;
   SPHXLoggerConfig  m_config;
   bool              m_initialized;

//------------------------------------------------------------------
// Public
//------------------------------------------------------------------
public:

   CPHXJournalWriter();
   ~CPHXJournalWriter();

   bool Initialize(
      CPHXLogFormatter *formatter,
      const SPHXLoggerConfig &config);

   void Shutdown();
   void Reset();

   bool IsInitialized() const;

//------------------------------------------------------------------
// Write message
//------------------------------------------------------------------
public:

   bool Write(const SPHXLogMessage &message);

//------------------------------------------------------------------
// Formatter
//------------------------------------------------------------------
public:

   void SetFormatter(CPHXLogFormatter *formatter);

   CPHXLogFormatter* GetFormatter() const;

//------------------------------------------------------------------
// Configuration
//------------------------------------------------------------------
public:

   void SetConfig(const SPHXLoggerConfig &config);

   SPHXLoggerConfig GetConfig() const;
};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXJournalWriter::CPHXJournalWriter()
{
   m_formatter   = NULL;
   m_initialized = false;

   m_config.Reset();
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXJournalWriter::~CPHXJournalWriter()
{
   Shutdown();
}

//+------------------------------------------------------------------+
//| Initialize                                                       |
//+------------------------------------------------------------------+
bool CPHXJournalWriter::Initialize(
   CPHXLogFormatter *formatter,
   const SPHXLoggerConfig &config)
{
   m_formatter = formatter;
   m_config    = config;

   m_initialized = (m_formatter != NULL);

   return m_initialized;
}

//+------------------------------------------------------------------+
//| Shutdown                                                         |
//+------------------------------------------------------------------+
void CPHXJournalWriter::Shutdown()
{
   m_formatter   = NULL;
   m_initialized = false;

   m_config.Reset();
}

//+------------------------------------------------------------------+
//| Reset                                                            |
//+------------------------------------------------------------------+
void CPHXJournalWriter::Reset()
{
   Shutdown();
}

//+------------------------------------------------------------------+
//| IsInitialized                                                    |
//+------------------------------------------------------------------+
bool CPHXJournalWriter::IsInitialized() const
{
   return m_initialized;
}

//+------------------------------------------------------------------+
//| SetFormatter                                                     |
//+------------------------------------------------------------------+
void CPHXJournalWriter::SetFormatter(CPHXLogFormatter *formatter)
{
   m_formatter = formatter;
}

//+------------------------------------------------------------------+
//| GetFormatter                                                     |
//+------------------------------------------------------------------+
CPHXLogFormatter* CPHXJournalWriter::GetFormatter() const
{
   return m_formatter;
}

//+------------------------------------------------------------------+
//| SetConfig                                                        |
//+------------------------------------------------------------------+
void CPHXJournalWriter::SetConfig(const SPHXLoggerConfig &config)
{
   m_config = config;
}

//+------------------------------------------------------------------+
//| GetConfig                                                        |
//+------------------------------------------------------------------+
SPHXLoggerConfig CPHXJournalWriter::GetConfig() const
{
   return m_config;
}

//+------------------------------------------------------------------+
//| Write                                                            |
//+------------------------------------------------------------------+
bool CPHXJournalWriter::Write(const SPHXLogMessage &message)
{
   if(!m_initialized)
      return false;

   if(m_formatter == NULL)
      return false;

   string text = m_formatter.Format(message);

   if(text == "")
      return false;

   Print(text);

   return true;
}

//+------------------------------------------------------------------+
//| End of file                                                      |
//+------------------------------------------------------------------+

#endif // __PHX_JOURNAL_WRITER_MQH__