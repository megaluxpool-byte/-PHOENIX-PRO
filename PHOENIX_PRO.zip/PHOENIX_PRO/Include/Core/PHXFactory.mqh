//+------------------------------------------------------------------+
//|                                                PHXFactory.mqh    |
//|                  PHOENIX PRO Trading Framework                   |
//|                                                                  |
//| Description:                                                     |
//|   Central object factory                                         |
//+------------------------------------------------------------------+
#ifndef __PHX_FACTORY_MQH__
#define __PHX_FACTORY_MQH__

#include "Logger/PHXLogger.mqh"
#include "PHXConfigManager.mqh"
#include "PHXServiceLocator.mqh"

//+------------------------------------------------------------------+
//| Factory                                                          |
//+------------------------------------------------------------------+
class CPHXFactory
{
public:

   CPHXFactory();

   ~CPHXFactory();

//------------------------------------------------------------------
// Core Services
//------------------------------------------------------------------
public:

   CPHXLogger* CreateLogger();

   CPHXConfigManager* CreateConfigManager();

   CPHXServiceLocator* CreateServiceLocator();

};

//+------------------------------------------------------------------+
//| Constructor                                                      |
//+------------------------------------------------------------------+
CPHXFactory::CPHXFactory()
{
}

//+------------------------------------------------------------------+
//| Destructor                                                       |
//+------------------------------------------------------------------+
CPHXFactory::~CPHXFactory()
{
}

//+------------------------------------------------------------------+
//| Create Logger                                                    |
//+------------------------------------------------------------------+
CPHXLogger* CPHXFactory::CreateLogger()
{
   CPHXLogger *logger = new CPHXLogger();

   return logger;
}

//+------------------------------------------------------------------+
//| Create Configuration Manager                                     |
//+------------------------------------------------------------------+
CPHXConfigManager* CPHXFactory::CreateConfigManager()
{
   CPHXConfigManager *configManager = new CPHXConfigManager();

   return configManager;
}

//+------------------------------------------------------------------+
//| Create Service Locator                                           |
//+------------------------------------------------------------------+
CPHXServiceLocator* CPHXFactory::CreateServiceLocator()
{
   CPHXServiceLocator *serviceLocator = new CPHXServiceLocator();

   return serviceLocator;
}

#endif // __PHX_FACTORY_MQH__