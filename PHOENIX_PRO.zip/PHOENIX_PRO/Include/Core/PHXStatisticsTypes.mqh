#ifndef PHX_STATISTICS_TYPES_MQH
#define PHX_STATISTICS_TYPES_MQH

//+------------------------------------------------------------------+
//| Statistics Object Type                                           |
//+------------------------------------------------------------------+
enum ENUM_PHX_STATISTICS_TYPE
{
   PHX_STAT_UNKNOWN = 0,

   PHX_STAT_TREND,

   PHX_STAT_SIGNAL,

   PHX_STAT_TRADE,

   PHX_STAT_POSITION,

   PHX_STAT_RISK,

   PHX_STAT_MARKET,

   PHX_STAT_PERFORMANCE
};

//+------------------------------------------------------------------+
//| Signal Result                                                    |
//+------------------------------------------------------------------+
enum ENUM_PHX_SIGNAL_RESULT
{
   PHX_RESULT_UNKNOWN = 0,

   PHX_RESULT_TRUE,

   PHX_RESULT_FALSE,

   PHX_RESULT_TIMEOUT
};

//+------------------------------------------------------------------+
//| Trade Direction                                                  |
//+------------------------------------------------------------------+

//+------------------------------------------------------------------+
//| Statistics Record Status                                         |
//+------------------------------------------------------------------+
enum ENUM_PHX_RECORD_STATE
{
   PHX_RECORD_EMPTY = 0,

   PHX_RECORD_COLLECTING,

   PHX_RECORD_FINISHED,

   PHX_RECORD_ARCHIVED
};

//+------------------------------------------------------------------+
//| Base Statistics Record                                           |
//+------------------------------------------------------------------+
struct SPHXStatisticsHeader
{
   ENUM_PHX_STATISTICS_TYPE Type;

   ENUM_PHX_RECORD_STATE    State;

   datetime                 Time;

   long                     BarIndex;

   long                     TickIndex;

   void Reset()
   {
      Type      = PHX_STAT_UNKNOWN;

      State     = PHX_RECORD_EMPTY;

      Time      = 0;

      BarIndex  = 0;

      TickIndex = 0;
   }
};

#endif // PHX_STATISTICS_TYPES_MQH