#ifndef PHX_TRADE_JOURNAL_MQH
#define PHX_TRADE_JOURNAL_MQH


//--------------------------------------------------
// Includes
//--------------------------------------------------

#include <Trade/Trade.mqh>

//+------------------------------------------------------------------+
//| PHX Trade Journal                                                |
//+------------------------------------------------------------------+
class CPHXTradeJournal
{
private:
   //--------------------------------------------------
   // State
   //--------------------------------------------------
   bool m_initialized;
   //--------------------------------------------------
   // File
   //--------------------------------------------------
   string m_fileName;
public:
   //--------------------------------------------------
   // Constructor
   //--------------------------------------------------
   CPHXTradeJournal()
   {
      m_initialized = false;
      m_fileName =
         "PHX_Trades.csv";
   }
   //--------------------------------------------------
   // Initialize
   //--------------------------------------------------
   bool Initialize()
   {
      int handle =
         FileOpen(
            m_fileName,
            FILE_READ|
            FILE_WRITE|
            FILE_CSV|
            FILE_ANSI|
            FILE_SHARE_READ|
            FILE_SHARE_WRITE,
            ';'
         );
      if(handle == INVALID_HANDLE)
      {
         Print(
            "PHX Journal: File open failed"
         );
         return false;
      }
      if(FileSize(handle) == 0)
      {
         FileWrite(
      handle,
      "TIME",
      "EVENT",
      "TICKET",
      "SYMBOL",
      "TYPE",
      "PRICE",
      "VOLUME",
      "OLD_SL",
      "NEW_SL",
      "TP",
      "PROFIT",
      "REASON"
);
      }
      FileClose(handle);
      m_initialized = true;
      Print(
         "PHX Journal: Initialized"
      );
      return true;
   }
   //--------------------------------------------------
   // Write Open
   //--------------------------------------------------
   bool WriteOpen(
      ulong ticket,
      string symbol,
      string type,
      double price,
      double volume,
      double sl,
      double tp
   );
   //--------------------------------------------------
   // Write Close
   //--------------------------------------------------
   bool WriteClose(
      ulong ticket,
      string symbol,
      double price,
      double profit,
      string reason
   );
   //--------------------------------------------------
// Write Modify SL
//--------------------------------------------------
bool WriteModifySL(
   ulong ticket,
   string symbol,
   double price,
   double volume,
   double oldSL,
   double newSL,
   string reason
);
};
//+------------------------------------------------------------------+
//| Write Open                                                       |
//+------------------------------------------------------------------+
bool CPHXTradeJournal::WriteOpen(
   ulong ticket,
   string symbol,
   string type,
   double price,
   double volume,
   double sl,
   double tp
)
{
   if(!m_initialized)
      return false;
   int handle =
      FileOpen(
         m_fileName,
         FILE_READ|
         FILE_WRITE|
         FILE_CSV|
         FILE_ANSI|
         FILE_SHARE_READ|
         FILE_SHARE_WRITE,
         ';'
      );
   if(handle == INVALID_HANDLE)
      return false;
   FileSeek(
      handle,
      0,
      SEEK_END
   );
   FileWrite(
      handle,
      TimeToString(
         TimeCurrent(),
         TIME_DATE|TIME_SECONDS
      ),
      "OPEN",
      ticket,
      symbol,
      type,
      DoubleToString(
         price,
         _Digits
      ),
      DoubleToString(
         volume,
         2
      ),
      0.0,
      DoubleToString(
         sl,
         _Digits
      ),
      DoubleToString(
         tp,
         _Digits
      ),
      0.0,
      "ENTRY"
   );
   FileClose(handle);
   return true;
}
//+------------------------------------------------------------------+
//| Write Close                                                      |
//+------------------------------------------------------------------+

bool CPHXTradeJournal::WriteClose(
   ulong ticket,
   string symbol,
   double price,
   double profit,
   string reason
)
{
   if(!m_initialized)
      return false;


   int handle =
      FileOpen(
         m_fileName,
         FILE_READ|
         FILE_WRITE|
         FILE_CSV|
         FILE_ANSI|
         FILE_SHARE_READ|
         FILE_SHARE_WRITE,
         ';'
      );


   if(handle == INVALID_HANDLE)
      return false;


   FileSeek(
      handle,
      0,
      SEEK_END
   );


   FileWrite(
      handle,

      TimeToString(
         TimeCurrent(),
         TIME_DATE|TIME_SECONDS
      ),

      "CLOSE",

      ticket,

      symbol,

      "",

      DoubleToString(
         price,
         _Digits
      ),

      0.0,

      0.0,

      0.0,

      0.0,

      DoubleToString(
         profit,
         2
      ),

      reason
   );


   FileClose(handle);


   return true;
}
//+------------------------------------------------------------------+
//| Write Modify SL                                                  |
//+------------------------------------------------------------------+
bool CPHXTradeJournal::WriteModifySL(
   ulong ticket,
   string symbol,
   double price,
   double volume,
   double oldSL,
   double newSL,
   string reason
)
{
   if(!m_initialized)
      return false;
   int handle =
      FileOpen(
         m_fileName,
         FILE_READ|
         FILE_WRITE|
         FILE_CSV|
         FILE_ANSI,
         ';'
      );
   if(handle == INVALID_HANDLE)
      return false;
   FileSeek(
      handle,
      0,
      SEEK_END
   );
   FileWrite(
      handle,
      TimeToString(
         TimeCurrent(),
         TIME_DATE|TIME_SECONDS
      ),
      "MODIFY_SL",
      ticket,
      symbol,
      "",
      DoubleToString(
         price,
         _Digits
      ),
      DoubleToString(
         volume,
         2
      ),
      DoubleToString(
         oldSL,
         _Digits
      ),
      DoubleToString(
         newSL,
         _Digits
      ),
      0.0,
      reason
   );
   FileClose(handle);
   return true;
}
#endif