//+------------------------------------------------------------------+
//|                                                    PhoenixPro.mq5|
//|                      PHOENIX PRO Trading Framework               |
//|                         Build 0.1.0-alpha                        |
//+------------------------------------------------------------------+
#property copyright "PHOENIX PRO Project"
#property version "1.000"
#property strict

#include <PHOENIX_PRO/Core/PHXKernel.mqh>

//+------------------------------------------------------------------+
//| PHOENIX PRO Inputs                                               |
//+------------------------------------------------------------------+
input double InpTradeLot = 0.10;
//--------------------------------------------------
// Initial Stop Loss
//--------------------------------------------------
input double InpStopLossPoints = 150.0;
//--------------------------------------------------
// Trading Schedule
//--------------------------------------------------
input bool InpTradingTimeEnabled = true;
input int InpTradingStartHour = 2;
input int InpTradingStartMinute = 0;
input int InpTradingEndHour = 23;
input int InpTradingEndMinute = 30;
//--------------------------------------------------
// Trailing
//--------------------------------------------------
input bool   InpTrailingEnabled = true;
input double InpTrailingStopPoints = 150.0;
//--------------------------------------------------
// Profit Protection
//--------------------------------------------------
input bool   InpProfitProtectionEnabled = true;
input double InpProtectionTriggerATR = 2.0;
input double InpProtectionLockATR = 1.2;
input double InpProtectionLevel2ATR = 3.0;
input double InpProtectionLevel2LockATR = 2.0;
input double InpProtectionLevel3ATR = 5.0;
input double InpProtectionLevel3LockATR = 3.0;
//-------------------------------------------------------------------
// Глобальный экземпляр ядра
//-------------------------------------------------------------------
CPHXKernel g_Kernel;
//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   Print("==================================================");
   Print("        PHOENIX PRO Build 0.1.0-alpha");
   Print("==================================================");
   
   //--------------------------------------------------
   // Initialize Kernel
   //--------------------------------------------------

   if(!g_Kernel.Initialize())
   {
      Print(
         "ERROR : Kernel initialization failed."
      );

      return(INIT_FAILED);
   }

  //--------------------------------------------------
// Configure Risk Inputs
//--------------------------------------------------

CPHXServices* services = 
   g_Kernel.Services();


if(services != NULL)
{

   services.ConfigureRisk(
      InpTradeLot,
      InpStopLossPoints,
      InpTrailingEnabled,
      InpTrailingStopPoints,
      InpTradingTimeEnabled,
      InpTradingStartHour,
      InpTradingStartMinute,
      InpTradingEndHour,
      InpTradingEndMinute
   );

  services.PrintConfiguration();

   }
   else
   {

      Print(
         "ERROR : Services container unavailable."
      );

      return(INIT_FAILED);

   }


   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
   g_Kernel.ProcessTick();
}

//+------------------------------------------------------------------+
//| Timer event                                                      |
//+------------------------------------------------------------------+
void OnTimer()
{
   g_Kernel.ProcessTimer();
}

//+------------------------------------------------------------------+
//| Trade transaction                                                |
//+------------------------------------------------------------------+
void OnTradeTransaction(const MqlTradeTransaction &trans,
                        const MqlTradeRequest &request,
                        const MqlTradeResult &result)
{
   g_Kernel.ProcessTradeTransaction(trans, request, result);
}

//+------------------------------------------------------------------+
//| Tester                                                           |
//+------------------------------------------------------------------+
double OnTester()
{
   return(g_Kernel.OnTester());
}

//+------------------------------------------------------------------+
//| Expert deinitialization                                          |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   g_Kernel.Shutdown(reason);

   Print("PHOENIX PRO stopped.");
}